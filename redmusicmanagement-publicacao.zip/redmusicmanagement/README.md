# Red Music — ambiente de testes

Sistema de gestão de voluntários, escalas e repertório para o ministério de louvor.

Veja [PUBLICACAO.md](PUBLICACAO.md) para a implantação no Render Free com MongoDB
Atlas Free, as configurações necessárias e as limitações conhecidas.

Esta pasta é uma cópia preparada para implantação. O serviço só estará publicado
depois da criação e configuração dos recursos nas contas do proprietário.
