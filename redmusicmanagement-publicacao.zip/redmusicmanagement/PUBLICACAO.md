# Publicação de testes — Render + MongoDB Atlas

Esta cópia foi preparada para um único Web Service Docker no plano Free do Render,
com React e FastAPI no mesmo endereço, e banco no MongoDB Atlas Free.
O arquivo original enviado pelo usuário não foi alterado.

## Estado

Os arquivos de implantação estão preparados. Isso não significa que o serviço já
esteja hospedado: ainda é necessário conectar as contas, criar o banco, enviar o
repositório e concluir a implantação. Não há segredos neste guia ou no render.yaml.

Validação local em 19/10/2026: compilação de produção do React concluída e seis
testes de publicação aprovados usando banco em memória. A compilação apresenta
avisos de dependências de hooks já existentes. A imagem Docker ainda não foi
executada; conexão com Atlas e funcionamento no Render dependem da implantação.

## Contas

1. Crie uma conta em https://dashboard.render.com/register e em
   https://www.mongodb.com/cloud/atlas/register.
2. Conecte MongoDB Atlas, Render e GitHub à conversa quando solicitado.
3. Não envie senhas pelo chat. Use os campos seguros dos serviços.

## Banco

- Crie um projeto exclusivo para testes e escolha o cluster **Free**. Não selecione
  Flex, Dedicated ou uma avaliação de plano pago.
- Crie um usuário do banco com acesso de leitura e escrita somente ao banco
  `redmusic_testes`.
- Copie a URI de conexão do driver Python para a variável secreta `MONGO_URL` no Render.
  Se preencher a URI manualmente, codifique caracteres especiais da senha na URL.
- Configure a lista de acesso do Atlas com os intervalos de saída exibidos no painel
  do serviço Render. Evite liberar `0.0.0.0/0`.
- O banco será novo e vazio: este pacote não contém uma exportação dos dados do Emergent.

## Repositório e Render

Envie esta pasta para um repositório **privado** do GitHub, respeitando o `.gitignore`.
Não envie `.env`, senhas, URI do banco, `node_modules` ou a pasta `frontend/build`.

No Render, conecte o repositório. A raiz deste projeto deve ser a raiz do serviço.
Crie um Web Service com runtime Docker, Dockerfile `./Dockerfile` e plano **Free**.
Alternativamente use o Blueprint `render.yaml`, que especifica explicitamente
`plan: free` para impedir o uso do plano pago padrão de novos serviços.
Não crie um banco Postgres: este sistema usa MongoDB Atlas.

Configure:

| Variável | Valor |
| --- | --- |
| `MONGO_URL` | URI secreta do Atlas |
| `DB_NAME` | `redmusic_testes` |
| `JWT_SECRET` | Segredo aleatório com pelo menos 32 caracteres; Blueprint gera automaticamente |
| `COOKIE_SECURE` | `true` |
| `ADMIN_EMAIL` | E-mail escolhido pelo proprietário |
| `ADMIN_PASSWORD` | Senha forte exclusiva, de 12 a 72 bytes UTF-8 |

`ADMIN_EMAIL` e `ADMIN_PASSWORD` criam o primeiro administrador somente quando a
conta ainda não existe. Não redefinem a senha de uma conta existente. Depois da
primeira criação, retire `ADMIN_PASSWORD` do painel: o cadastro permanece no Atlas.
Não há recuperação de senha implementada nesta versão; guarde a senha no seu gerenciador.

O contêiner compila o React, instala as dependências de execução do backend e inicia
`uvicorn backend.server:app --host 0.0.0.0 --port $PORT`.
A verificação de saúde é `GET /api/health`, que retorna 200 quando o banco responde.

## Verificação depois de publicar

1. Verifique logs e `/api/health` sem copiar segredos para a conversa.
2. Entre com o administrador, crie uma escala e uma música fictícias.
3. Recarregue uma rota interna para verificar o roteamento do React.
4. Abra pelo celular e teste o cadastro como voluntário; não deve conceder liderança.
5. Reinicie o serviço e confira que os dados e a senha continuam funcionando.

## Ajustes incluídos

- Cadastro público sempre cria perfil Voluntário; liderança exige perfil reconhecido.
- Removidos credenciais padrão, redefinição de senha no startup e gravação de senha em arquivo.
- Cookies Secure por padrão; use `COOKIE_SECURE=false` apenas em desenvolvimento HTTP local.
- Interface e API no mesmo endereço; frontend usa `/api` sem URL externa obrigatória.
- Roteamento para páginas React, arquivos estáticos e endpoint de saúde com verificação do banco.
- Imagem Docker com usuário sem privilégios e dependências de backend reduzidas.
- Removidos os scripts de telemetria e de edição do Emergent da página publicada.
- Testes isolados para os ajustes de acesso, bootstrap e roteamento.

## Limites e pendências

O Render Free entra em repouso após inatividade; o próximo acesso pode demorar.
O filesystem do contêiner é temporário; cadastros e fotos desta versão ficam no MongoDB.
As fotos em base64 devem ser pequenas para não consumir rapidamente os 512 MB gratuitos.
Sem cartão no Render, os limites podem interromper o serviço ou novas builds.

Esta é uma versão de testes, sem a implementação das demais melhorias da análise:
confirmação pelo voluntário, permissões de leitura
de dados pessoais, chat e indicadores ainda têm as limitações identificadas.
Use inicialmente um grupo pequeno e dados fictícios.
SMS não está implementado; e-mail depende de configuração adicional do provedor.

Os testes antigos em `backend_test.py` acessam um endereço externo e NÃO devem ser
executados automaticamente. Os testes de publicação em `backend/tests/test_deploy.py`
usam banco em memória. Para executá-los após compilar o frontend:

```text
python -m pip install -r backend/requirements-test.txt
python -m pytest backend/tests/test_deploy.py -q
```

## Referências

- https://render.com/docs/free
- https://render.com/docs/docker
- https://render.com/docs/blueprint-spec
- https://www.mongodb.com/docs/atlas/security/ip-access-list/

## Visibilidade pública das escalas

Somente escalas com status Validado ou Fechada aparecem nos links públicos individuais e mensais. Rascunhos e escalas em preparação ficam disponíveis na área autenticada. Use Marcar como Validado para disponibilizar uma escala; voltar para Rascunho bloqueia novamente o acesso público, inclusive por links já copiados.
