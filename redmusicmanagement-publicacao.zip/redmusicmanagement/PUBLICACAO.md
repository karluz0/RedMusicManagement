# Publicação de testes — Render + MongoDB Atlas

Esta cópia foi preparada para um único Web Service Docker no plano Free do Render,
com React e FastAPI no mesmo endereço, e banco no MongoDB Atlas Free.
O arquivo original enviado pelo usuário não foi alterado.

## Estado

Os arquivos de implantação estão preparados. Isso não significa que o serviço já
esteja hospedado: ainda é necessário conectar as contas, criar o banco, enviar o
repositório e concluir a implantação. Não há segredos neste guia ou no render.yaml.

Validação local em 19/10/2026: compilação de produção do React concluída e seis
testes de publicação aprovados usando banco em memória. A compilação apresenta
avisos de dependências de hooks já existentes. A imagem Docker ainda não foi
executada; conexão com Atlas e funcionamento no Render dependem da implantação.

## Contas

1. Crie uma conta em https://dashboard.render.com/register e em
   https://www.mongodb.com/cloud/atlas/register.
2. Conecte MongoDB Atlas, Render e GitHub à conversa quando solicitado.
3. Não envie senhas pelo chat. Use os campos seguros dos serviços.

## Banco

- Crie um projeto exclusivo para testes e escolha o cluster **Free**. Não selecione
  Flex, Dedicated ou uma avaliação de plano pago.
- Crie um usuário do banco com acesso de leitura e escrita somente ao banco
  `redmusic_testes`.
- Copie a URI de conexão do driver Python para a variável secreta `MONGO_URL` no Render.
  Se preencher a URI manualmente, codifique caracteres especiais da senha na URL.
- Configure a lista de acesso do Atlas com os intervalos de saída exibidos no painel
  do serviço Render. Evite liberar `0.0.0.0/0`.
- O banco será novo e vazio: este pacote não contém uma exportação dos dados do Emergent.

## Repositório e Render

Envie esta pasta para um repositório **privado** do GitHub, respeitando o `.gitignore`.
Não envie `.env`, senhas, URI do banco, `node_modules` ou a pasta `frontend/build`.

No Render, conecte o repositório. A raiz deste projeto deve ser a raiz do serviço.
Crie um Web Service com runtime Docker, Dockerfile `./Dockerfile` e plano **Free**.
Alternativamente use o Blueprint `render.yaml`, que especifica explicitamente
`plan: free` para impedir o uso do plano pago padrão de novos serviços.
Não crie um banco Postgres: este sistema usa MongoDB Atlas.

Configure:

| Variável | Valor |
| --- | --- |
| `MONGO_URL` | URI secreta do Atlas |
| `DB_NAME` | `redmusic_testes` |
| `JWT_SECRET` | Segredo aleatório com pelo menos 32 caracteres; Blueprint gera automaticamente |
| `COOKIE_SECURE` | `true` |
| `ADMIN_EMAIL` | E-mail escolhido pelo proprietário |
| `ADMIN_PASSWORD` | Senha forte exclusiva, de 12 a 72 bytes UTF-8 |

`ADMIN_EMAIL` e `ADMIN_PASSWORD` criam o primeiro administrador somente quando a
conta ainda não existe. Não redefinem a senha de uma conta existente. Depois da
primeira criação, retire `ADMIN_PASSWORD` do painel: o cadastro permanece no Atlas.
Não há recuperação de senha implementada nesta versão; guarde a senha no seu gerenciador.

O contêiner compila o React, instala as dependências de execução do backend e inicia
`uvicorn backend.server:app --host 0.0.0.0 --port $PORT`.
A verificação de saúde é `GET /api/health`, que retorna 200 quando o banco responde.

## Verificação depois de publicar

1. Verifique logs e `/api/health` sem copiar segredos para a conversa.
2. Entre com o administrador, crie uma escala e uma música fictícias.
3. Recarregue uma rota interna para verificar o roteamento do React.
4. Abra pelo celular e teste o cadastro como voluntário; não deve conceder liderança.
5. Reinicie o serviço e confira que os dados e a senha continuam funcionando.

## Ajustes incluídos

- Cadastro público sempre cria perfil Voluntário; liderança exige perfil reconhecido.
- Removidos credenciais padrão, redefinição de senha no startup e gravação de senha em arquivo.
- Cookies Secure por padrão; use `COOKIE_SECURE=false` apenas em desenvolvimento HTTP local.
- Interface e API no mesmo endereço; frontend usa `/api` sem URL externa obrigatória.
- Roteamento para páginas React, arquivos estáticos e endpoint de saúde com verificação do banco.
- Imagem Docker com usuário sem privilégios e dependências de backend reduzidas.
- Removidos os scripts de telemetria e de edição do Emergent da página publicada.
- Testes isolados para os ajustes de acesso, bootstrap e roteamento.

## Limites e pendências

O Render Free entra em repouso após inatividade; o próximo acesso pode demorar.
O filesystem do contêiner é temporário; cadastros e fotos desta versão ficam no MongoDB.
As fotos em base64 devem ser pequenas para não consumir rapidamente os 512 MB gratuitos.
Sem cartão no Render, os limites podem interromper o serviço ou novas builds.

Esta é uma versão de testes, sem a implementação das demais melhorias da análise:
os indicadores ainda têm as limitações identificadas.
Use inicialmente um grupo pequeno e dados fictícios.
SMS não está implementado; e-mail depende de configuração adicional do provedor.

Os testes antigos em `backend_test.py` acessam um endereço externo e NÃO devem ser
executados automaticamente. Os testes de publicação em `backend/tests/test_deploy.py`
usam banco em memória. Para executá-los após compilar o frontend:

```text
python -m pip install -r backend/requirements-test.txt
python -m pytest backend/tests/test_deploy.py -q
```

## Referências

- https://render.com/docs/free
- https://render.com/docs/docker
- https://render.com/docs/blueprint-spec
- https://www.mongodb.com/docs/atlas/security/ip-access-list/

## Visibilidade pública das escalas

Somente escalas com status Validado ou Fechada aparecem nos links públicos individuais e mensais. Rascunhos ficam restritos à liderança. Voluntários liberados podem consultar Disponibilidade, Em Validação, Validado e Fechada. Use Marcar como Validado para disponibilizar uma escala; voltar para Rascunho bloqueia novamente o acesso público, inclusive por links já copiados.

## Confirmação pelo voluntário

A liderança deve abrir o perfil do voluntário e usar Liberação de acesso da conta para vincular o e-mail de uma conta já criada, após conferir a identidade com a pessoa. Não há vínculo automático por coincidência de e-mail. Cada conta e cada voluntário podem ter um único vínculo. Remover vínculo revoga a permissão; o vínculo também é removido quando o cadastro do voluntário é excluído.

Ao entrar em sua conta e abrir uma escala, o voluntário ativo pode alterar apenas sua própria participação para Pendente, Confirmado ou Preciso de Substituto. A liderança continua podendo ajustar as confirmações da equipe. Contas sem vínculo, voluntários inativos ou afastados e perfis desconhecidos não podem responder em nome de outras pessoas.

## Acesso aos dados pessoais

Somente Administrador e Líder podem consultar a lista de cadastros, perfis completos, voluntários disponíveis, histórico individual e contagem mensal por voluntário. Essa autorização é verificada na API, inclusive para contas vinculadas a um voluntário. As respostas dessas rotas usam Cache-Control: no-store.

A tela de escala de um voluntário consulta apenas os dados da escala e do repertório, sem buscar os cadastros pessoais ou a lista de disponibilidade da equipe. Nomes, funções e confirmações continuam disponíveis na escala; a confirmação da própria participação continua funcionando. Os menus e as rotas de gestão também exigem um perfil explícito de liderança.

## Mensagens internas

O chat usa os identificadores das contas de acesso, sem confundir com os identificadores dos cadastros de voluntários. A liderança pode conversar com outras contas de liderança e com voluntários ativos que tenham conta vinculada. Voluntários ativos com vínculo podem conversar com a liderança. Contas sem vínculo ou perfis desconhecidos não têm acesso. Os contatos mostram apenas identificador, nome e função de acesso; nenhum cadastro completo, telefone ou e-mail é entregue pela lista de contatos.

Cada usuário só consulta conversas das quais participa. A validação é repetida na leitura e no envio, incluindo revogação do vínculo ou inativação. Mensagens vazias são recusadas; o limite é de 2000 caracteres. A tela mostra as 100 mensagens mais recentes em ordem cronológica, atualiza a cada 5 segundos enquanto a conversa está aberta e permite tentar novamente em caso de erro. Ao trocar contato, requisições anteriores são canceladas e não atualizam a nova conversa.

Mensagens antigas endereçadas ao identificador de um cadastro de voluntário permanecem preservadas no banco, mas não são reassociadas automaticamente a contas atuais, para evitar entrega à pessoa errada. Não há envio de e-mail, SMS ou WhatsApp por este chat, nem confirmação de leitura implementada.

## Contagem mensal de escalas

A contagem por voluntário e a lista de disponíveis usam uma única regra: incluir escalas Em Validação, Validado e Fechada pela data do evento no mês informado. Rascunho, Disponibilidade e status desconhecidos ficam fora. Cada escala conta uma vez por pessoa, mesmo que haja mais de uma função ou registros repetidos. Eventos distintos na mesma data contam separadamente; participações nos diferentes ministérios são somadas.

O número representa alocações em escalas, não comprovação de presença. Uma pessoa que pediu substituição continua alocada até a liderança removê-la da equipe. A lista exibe inclusive zero e uma participação; o destaque amarelo continua a partir de duas escalas no mês. Alterações de status e exclusões são refletidas na próxima consulta, sem um contador acumulado separado. O alerta de participações consecutivas é um indicador distinto, descrito abaixo.

## Sequência de escalas

O painel Atenção à sequência de escalas considera quatro ou mais eventos seguidos na sequência mais recente de um mesmo ministério. Conta apenas Em Validação, Validado e Fechada. A ordem é por data e horário; ausência em uma programação interrompe a sequência, assim como intervalo superior a sete dias entre eventos. Funções ou registros repetidos no mesmo evento contam uma vez. Participações de ministérios diferentes não são somadas para formar uma sequência.

Somente voluntários ativos aparecem. A última programação precisa estar nos últimos sete dias ou no futuro (referência de data UTC); sequências antigas não geram destaque. Em caso de sequências em mais de um ministério, aparece uma linha por pessoa com a maior sequência; no empate, a que termina mais tarde. O painel informa ministério, quantidade e período. É uma informação de planejamento de alocações e não uma comprovação de presença nem avaliação de saúde.

## Uso das músicas em escalas passadas

O ranking e as datas no repertório são derivados dos repertórios atuais, sem confiar nos contadores antigos. São incluídas escalas Validado e Fechada com data anterior ao dia atual no fuso America/Sao_Paulo. Eventos de hoje e futuros, rascunhos e escalas Em Validação ficam fora. Cada música conta uma vez por evento, mesmo quando aparece repetida ou há repertórios duplicados. A última data é a data do evento, sem conversão que desloque o dia na tela.

O painel mostra até dez músicas com uso positivo; empates são ordenados pelo nome. A exclusão de uma escala ou de um item do repertório, bem como a mudança de status, afeta a próxima consulta. Os nomes dos campos da API foram preservados por compatibilidade, mas as telas dizem uso em escalas passadas e última escala passada: não há confirmação de execução real da música. O cálculo também é aplicado aos dados completos das músicas nos links públicos. Nenhum contador antigo é apagado ou regravado automaticamente.

## Inclusão de membros sem duplicação

Cada pessoa pode ser incluída uma vez por função em cada escala. A função é validada e padronizada, inclusive diferenças de maiúsculas, espaços e acentos. A API detecta registros antigos equivalentes e responde com conflito sem alterar confirmações existentes. Novas inclusões usam identidade interna determinística por escala, pessoa e função, protegida pela unicidade nativa do MongoDB, para impedir duas gravações simultâneas da mesma participação. Não é necessária migração ou exclusão dos dados antigos.

A tela bloqueia novos cliques e a troca de função enquanto a inclusão está em andamento, aguarda a atualização da equipe e sinaliza quando a pessoa já está escalada. Funções diferentes permanecem permitidas; remover uma participação permite incluí-la novamente. Os limites de vagas e a autorização da liderança continuam sendo verificados. Esta proteção trata duplicações da mesma participação; não altera as regras de confirmação ou a contagem mensal.

## Aprovação de cadastro e acesso interno

O cadastro público de voluntário começa com status Pendente. A conta pode entrar e sair, mas só vê a tela Aguardando liberação, sem acesso às APIs internas. No perfil do voluntário, a liderança confere o e-mail e usa Vincular e aprovar cadastro: o vínculo explícito é criado e o perfil Pendente passa a Ativo. Inativos e Afastados não são reativados por essa ação.

Contas criadas pelo formulário simples também precisam de um perfil de voluntário ativo e do vínculo autorizado pela liderança. Perfis antigos não são aprovados por coincidência de e-mail. Vínculos existentes com voluntários ativos continuam válidos; Administrador e Líder continuam com acesso de gestão.

A autorização consulta o banco em cada requisição. Remover vínculo, excluir o perfil ou mudar seu status para Pendente, Inativo ou Afastado bloqueia o acesso interno, mesmo com um token ainda válido. O usuário pode usar Verificar liberação ou entrar novamente para atualizar a tela. A checagem também cobre repertórios e vocais por acesso direto; rascunhos e status desconhecidos são restritos à liderança. Links públicos de escalas publicadas mantêm o comportamento documentado acima.

## Disponibilidade por evento

A resposta de disponibilidade usa exclusivamente users.volunteer_id, conferido pela liderança, e exige que o voluntário esteja Ativo. Coincidência de e-mail não autoriza responder por um perfil. O identificador da escala vem da URL; um schedule_id legado no corpo só é aceito se coincidir. Valores que não sejam booleanos e campos extras são recusados.

O voluntário abre a escala e usa Sua disponibilidade para informar Estou disponível ou Estou indisponível, podendo alterar a resposta. Sem resposta aparece até a primeira declaração. Essa resposta não inclui o voluntário na equipe nem muda sua confirmação de presença. A consulta retorna apenas a resposta da própria conta.

Na seleção de membros, a liderança vê Disponível para quem respondeu sim e Sem resposta para quem ainda precisa ser consultado. Quem respondeu não fica fora, mesmo quando ninguém respondeu sim. A chegada da primeira resposta sim não remove os demais sem resposta. Bloqueios de data prevalecem sobre respostas sim; voluntários que não estejam Ativos também ficam fora. Os registros anteriores são preservados.

## Limite de vagas sob inclusões simultâneas

A inclusão de membros usa uma transação MongoDB com leitura snapshot e gravação majority. Cada tentativa grava uma revisão interna na escala antes de contar a equipe, fazendo inclusões concorrentes disputarem o mesmo documento, inclusive em processos diferentes. O driver repete transações com conflitos transitórios; a nova tentativa consulta a contagem atual. Não existe alternativa sem transação caso o banco falhe: a API responde 503 e pede atualização antes de tentar novamente.

A transação também grava uma revisão do perfil Ativo para conciliar a inclusão com alterações concorrentes no cadastro. Pendente, Inativo, Afastado e status ausente são recusados, mesmo por chamada direta à API. A regra vale para novas inclusões; participações existentes são preservadas.

Vocal e Backing Vocal compartilham o limite de Vocal. A contagem reconhece maiúsculas, espaços e acentos em funções antigas. Para escalas antigas sem configuração completa, aplicam-se os limites padrão exibidos na interface: Vocal 6; Violão, Guitarra e Teclado 2; Baixo, Bateria e Percussão 1. Funções técnicas permanecem sem limite numérico. Escalas já acima do limite não perdem membros, mas recusam novas inclusões naquela função.

O teste de integração backend/tests/test_assignment_transactions.py exige um replica set local descartável codex-local-test em 127.0.0.1:27019. Ele usa clientes independentes, executa oito disputas pela última vaga, verifica rollback após falha injetada, recusa perfis inativos e verifica reutilização de vaga após remoção. Não usa credenciais Atlas. O ambiente publicado requer suporte a transações, como o replica set do Atlas já configurado.

Para executar o teste de integração, defina RUN_MONGO_TRANSACTION_TESTS=1 e rode pytest backend/tests/test_assignment_transactions.py; sem essa variável ele é pulado para não exigir MongoDB local nos testes comuns.
