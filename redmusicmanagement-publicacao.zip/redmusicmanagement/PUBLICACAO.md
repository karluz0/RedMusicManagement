# Publicação de testes — Render + MongoDB Atlas

Esta cópia foi preparada para um único Web Service Docker no plano Free do Render,
com React e FastAPI no mesmo endereço, e banco no MongoDB Atlas Free.
O arquivo original enviado pelo usuário não foi alterado.

## Estado

Os arquivos de implantação estão preparados. Isso não significa que o serviço já
esteja hospedado: ainda é necessário conectar as contas, criar o banco, enviar o
repositório e concluir a implantação. Não há segredos neste guia ou no render.yaml.

Validação local em 19/10/2026: compilação de produção do React concluída e seis
testes de publicação aprovados usando banco em memória. A compilação apresenta
avisos de dependências de hooks já existentes. A imagem Docker ainda não foi
executada; conexão com Atlas e funcionamento no Render dependem da implantação.

## Contas

1. Crie uma conta em https://dashboard.render.com/register e em
   https://www.mongodb.com/cloud/atlas/register.
2. Conecte MongoDB Atlas, Render e GitHub à conversa quando solicitado.
3. Não envie senhas pelo chat. Use os campos seguros dos serviços.

## Banco

- Crie um projeto exclusivo para testes e escolha o cluster **Free**. Não selecione
  Flex, Dedicated ou uma avaliação de plano pago.
- Crie um usuário do banco com acesso de leitura e escrita somente ao banco
  `redmusic_testes`.
- Copie a URI de conexão do driver Python para a variável secreta `MONGO_URL` no Render.
  Se preencher a URI manualmente, codifique caracteres especiais da senha na URL.
- Configure a lista de acesso do Atlas com os intervalos de saída exibidos no painel
  do serviço Render. Evite liberar `0.0.0.0/0`.
- O banco será novo e vazio: este pacote não contém uma exportação dos dados do Emergent.

## Repositório e Render

Envie esta pasta para um repositório **privado** do GitHub, respeitando o `.gitignore`.
Não envie `.env`, senhas, URI do banco, `node_modules` ou a pasta `frontend/build`.

No Render, conecte o repositório. A raiz deste projeto deve ser a raiz do serviço.
Crie um Web Service com runtime Docker, Dockerfile `./Dockerfile` e plano **Free**.
Alternativamente use o Blueprint `render.yaml`, que especifica explicitamente
`plan: free` para impedir o uso do plano pago padrão de novos serviços.
Não crie um banco Postgres: este sistema usa MongoDB Atlas.

Configure:

| Variável | Valor |
| --- | --- |
| `MONGO_URL` | URI secreta do Atlas |
| `DB_NAME` | `redmusic_testes` |
| `JWT_SECRET` | Segredo aleatório com pelo menos 32 caracteres; Blueprint gera automaticamente |
| `COOKIE_SECURE` | `true` |
| `ADMIN_EMAIL` | E-mail escolhido pelo proprietário |
| `ADMIN_PASSWORD` | Senha forte exclusiva, de 12 a 72 bytes UTF-8 |

`ADMIN_EMAIL` e `ADMIN_PASSWORD` criam o primeiro administrador somente quando a
conta ainda não existe. Não redefinem a senha de uma conta existente. Depois da
primeira criação, retire `ADMIN_PASSWORD` do painel: o cadastro permanece no Atlas.
Não há recuperação de senha implementada nesta versão; guarde a senha no seu gerenciador.

O contêiner compila o React, instala as dependências de execução do backend e inicia
`uvicorn backend.server:app --host 0.0.0.0 --port $PORT`.
A verificação de saúde é `GET /api/health`, que retorna 200 quando o banco responde.

## Verificação depois de publicar

1. Verifique logs e `/api/health` sem copiar segredos para a conversa.
2. Entre com o administrador, crie uma escala e uma música fictícias.
3. Recarregue uma rota interna para verificar o roteamento do React.
4. Abra pelo celular e teste o cadastro como voluntário; não deve conceder liderança.
5. Reinicie o serviço e confira que os dados e a senha continuam funcionando.

## Ajustes incluídos

- Cadastro público sempre cria perfil Voluntário; liderança exige perfil reconhecido.
- Removidos credenciais padrão, redefinição de senha no startup e gravação de senha em arquivo.
- Cookies Secure por padrão; use `COOKIE_SECURE=false` apenas em desenvolvimento HTTP local.
- Interface e API no mesmo endereço; frontend usa `/api` sem URL externa obrigatória.
- Roteamento para páginas React, arquivos estáticos e endpoint de saúde com verificação do banco.
- Imagem Docker com usuário sem privilégios e dependências de backend reduzidas.
- Removidos os scripts de telemetria e de edição do Emergent da página publicada.
- Testes isolados para os ajustes de acesso, bootstrap e roteamento.

## Limites e pendências

O Render Free entra em repouso após inatividade; o próximo acesso pode demorar.
O filesystem do contêiner é temporário; cadastros e fotos desta versão ficam no MongoDB.
As fotos em base64 devem ser pequenas para não consumir rapidamente os 512 MB gratuitos.
Sem cartão no Render, os limites podem interromper o serviço ou novas builds.

Esta é uma versão de testes, sem a implementação das demais melhorias da análise:
os indicadores ainda têm as limitações identificadas.
Use inicialmente um grupo pequeno e dados fictícios.
SMS não está implementado; e-mail depende de configuração adicional do provedor.

Os testes antigos em `backend_test.py` acessam um endereço externo e NÃO devem ser
executados automaticamente. Os testes de publicação em `backend/tests/test_deploy.py`
usam banco em memória. Para executá-los após compilar o frontend:

```text
python -m pip install -r backend/requirements-test.txt
python -m pytest backend/tests/test_deploy.py -q
```

## Referências

- https://render.com/docs/free
- https://render.com/docs/docker
- https://render.com/docs/blueprint-spec
- https://www.mongodb.com/docs/atlas/security/ip-access-list/

## Visibilidade pública das escalas

Somente escalas com status Validado ou Fechada aparecem nos links públicos individuais e mensais. Rascunhos ficam restritos à liderança. Voluntários liberados podem consultar Disponibilidade, Em Validação, Validado e Fechada. Use Marcar como Validado para disponibilizar uma escala; voltar para Rascunho bloqueia novamente o acesso público, inclusive por links já copiados.

## Confirmação pelo voluntário

A liderança deve abrir o perfil do voluntário e usar Liberação de acesso da conta para vincular o e-mail de uma conta já criada, após conferir a identidade com a pessoa. Não há vínculo automático por coincidência de e-mail. Cada conta e cada voluntário podem ter um único vínculo. Remover vínculo revoga a permissão; o vínculo também é removido quando o cadastro do voluntário é excluído.

Ao entrar em sua conta e abrir uma escala, o voluntário ativo pode alterar apenas sua própria participação para Pendente, Confirmado ou Preciso de Substituto. A liderança continua podendo ajustar as confirmações da equipe. Contas sem vínculo, voluntários inativos ou afastados e perfis desconhecidos não podem responder em nome de outras pessoas.

## Acesso aos dados pessoais

Somente Administrador e Líder podem consultar a lista de cadastros, perfis completos, voluntários disponíveis, histórico individual e contagem mensal por voluntário. Essa autorização é verificada na API, inclusive para contas vinculadas a um voluntário. As respostas dessas rotas usam Cache-Control: no-store.

A tela de escala de um voluntário consulta apenas os dados da escala e do repertório, sem buscar os cadastros pessoais ou a lista de disponibilidade da equipe. Nomes, funções e confirmações continuam disponíveis na escala; a confirmação da própria participação continua funcionando. Os menus e as rotas de gestão também exigem um perfil explícito de liderança.

## Mensagens internas

O chat usa os identificadores das contas de acesso, sem confundir com os identificadores dos cadastros de voluntários. A liderança pode conversar com outras contas de liderança e com voluntários ativos que tenham conta vinculada. Voluntários ativos com vínculo podem conversar com a liderança. Contas sem vínculo ou perfis desconhecidos não têm acesso. Os contatos mostram apenas identificador, nome e função de acesso; nenhum cadastro completo, telefone ou e-mail é entregue pela lista de contatos.

Cada usuário só consulta conversas das quais participa. A validação é repetida na leitura e no envio, incluindo revogação do vínculo ou inativação. Mensagens vazias são recusadas; o limite é de 2000 caracteres. A tela mostra as 100 mensagens mais recentes em ordem cronológica, atualiza a cada 5 segundos enquanto a conversa está aberta e permite tentar novamente em caso de erro. Ao trocar contato, requisições anteriores são canceladas e não atualizam a nova conversa.

Mensagens antigas endereçadas ao identificador de um cadastro de voluntário permanecem preservadas no banco, mas não são reassociadas automaticamente a contas atuais, para evitar entrega à pessoa errada. Não há envio de e-mail, SMS ou WhatsApp por este chat, nem confirmação de leitura implementada.

## Contagem mensal de escalas

A contagem por voluntário e a lista de disponíveis usam uma única regra: incluir escalas Em Validação, Validado e Fechada pela data do evento no mês informado. Rascunho, Disponibilidade e status desconhecidos ficam fora. Cada escala conta uma vez por pessoa, mesmo que haja mais de uma função ou registros repetidos. Eventos distintos na mesma data contam separadamente; participações nos diferentes ministérios são somadas.

O número representa alocações em escalas, não comprovação de presença. Uma pessoa que pediu substituição continua alocada até a liderança removê-la da equipe. A lista exibe inclusive zero e uma participação; o destaque amarelo continua a partir de duas escalas no mês. Alterações de status e exclusões são refletidas na próxima consulta, sem um contador acumulado separado. O alerta de participações consecutivas é um indicador distinto, descrito abaixo.

## Sequência de escalas

O painel Atenção à sequência de escalas considera quatro ou mais eventos seguidos na sequência mais recente de um mesmo ministério. Conta apenas Em Validação, Validado e Fechada. A ordem é por data e horário; ausência em uma programação interrompe a sequência, assim como intervalo superior a sete dias entre eventos. Funções ou registros repetidos no mesmo evento contam uma vez. Participações de ministérios diferentes não são somadas para formar uma sequência.

Somente voluntários ativos aparecem. A última programação precisa estar nos últimos sete dias ou no futuro (referência de data UTC); sequências antigas não geram destaque. Em caso de sequências em mais de um ministério, aparece uma linha por pessoa com a maior sequência; no empate, a que termina mais tarde. O painel informa ministério, quantidade e período. É uma informação de planejamento de alocações e não uma comprovação de presença nem avaliação de saúde.

## Uso das músicas em escalas passadas

O ranking e as datas no repertório são derivados dos repertórios atuais, sem confiar nos contadores antigos. São incluídas escalas Validado e Fechada com data anterior ao dia atual no fuso America/Sao_Paulo. Eventos de hoje e futuros, rascunhos e escalas Em Validação ficam fora. Cada música conta uma vez por evento, mesmo quando aparece repetida ou há repertórios duplicados. A última data é a data do evento, sem conversão que desloque o dia na tela.

O painel mostra até dez músicas com uso positivo; empates são ordenados pelo nome. A exclusão de uma escala ou de um item do repertório, bem como a mudança de status, afeta a próxima consulta. Os nomes dos campos da API foram preservados por compatibilidade, mas as telas dizem uso em escalas passadas e última escala passada: não há confirmação de execução real da música. O cálculo também é aplicado aos dados completos das músicas nos links públicos. Nenhum contador antigo é apagado ou regravado automaticamente.

## Inclusão de membros sem duplicação

Cada pessoa pode ser incluída uma vez por função em cada escala. A função é validada e padronizada, inclusive diferenças de maiúsculas, espaços e acentos. A API detecta registros antigos equivalentes e responde com conflito sem alterar confirmações existentes. Novas inclusões usam identidade interna determinística por escala, pessoa e função, protegida pela unicidade nativa do MongoDB, para impedir duas gravações simultâneas da mesma participação. Não é necessária migração ou exclusão dos dados antigos.

A tela bloqueia novos cliques e a troca de função enquanto a inclusão está em andamento, aguarda a atualização da equipe e sinaliza quando a pessoa já está escalada. Funções diferentes permanecem permitidas; remover uma participação permite incluí-la novamente. Os limites de vagas e a autorização da liderança continuam sendo verificados. Esta proteção trata duplicações da mesma participação; não altera as regras de confirmação ou a contagem mensal.

## Aprovação de cadastro e acesso interno

O cadastro público de voluntário começa com status Pendente. A conta pode entrar e sair, mas só vê a tela Aguardando liberação, sem acesso às APIs internas. No perfil do voluntário, a liderança confere o e-mail e usa Vincular e aprovar cadastro: o vínculo explícito é criado e o perfil Pendente passa a Ativo. Inativos e Afastados não são reativados por essa ação.

Contas criadas pelo formulário simples também precisam de um perfil de voluntário ativo e do vínculo autorizado pela liderança. Perfis antigos não são aprovados por coincidência de e-mail. Vínculos existentes com voluntários ativos continuam válidos; Administrador e Líder continuam com acesso de gestão.

A autorização consulta o banco em cada requisição. Remover vínculo, excluir o perfil ou mudar seu status para Pendente, Inativo ou Afastado bloqueia o acesso interno, mesmo com um token ainda válido. O usuário pode usar Verificar liberação ou entrar novamente para atualizar a tela. A checagem também cobre repertórios e vocais por acesso direto; rascunhos e status desconhecidos são restritos à liderança. Links públicos de escalas publicadas mantêm o comportamento documentado acima.

## Disponibilidade por evento

A resposta de disponibilidade usa exclusivamente users.volunteer_id, conferido pela liderança, e exige que o voluntário esteja Ativo. Coincidência de e-mail não autoriza responder por um perfil. O identificador da escala vem da URL; um schedule_id legado no corpo só é aceito se coincidir. Valores que não sejam booleanos e campos extras são recusados.

O voluntário abre a escala e usa Sua disponibilidade para informar Estou disponível ou Estou indisponível, podendo alterar a resposta. Sem resposta aparece até a primeira declaração. Essa resposta não inclui o voluntário na equipe nem muda sua confirmação de presença. A consulta retorna apenas a resposta da própria conta.

Na seleção de membros, a liderança vê Disponível para quem respondeu sim e Sem resposta para quem ainda precisa ser consultado. Quem respondeu não fica fora, mesmo quando ninguém respondeu sim. A chegada da primeira resposta sim não remove os demais sem resposta. Bloqueios de data prevalecem sobre respostas sim; voluntários que não estejam Ativos também ficam fora. Os registros anteriores são preservados.

## Limite de vagas sob inclusões simultâneas

A inclusão de membros usa uma transação MongoDB com leitura snapshot e gravação majority. Cada tentativa grava uma revisão interna na escala antes de contar a equipe, fazendo inclusões concorrentes disputarem o mesmo documento, inclusive em processos diferentes. O driver repete transações com conflitos transitórios; a nova tentativa consulta a contagem atual. Não existe alternativa sem transação caso o banco falhe: a API responde 503 e pede atualização antes de tentar novamente.

A transação também grava uma revisão do perfil Ativo para conciliar a inclusão com alterações concorrentes no cadastro. Pendente, Inativo, Afastado e status ausente são recusados, mesmo por chamada direta à API. A regra vale para novas inclusões; participações existentes são preservadas.

Vocal e Backing Vocal compartilham o limite de Vocal. A contagem reconhece maiúsculas, espaços e acentos em funções antigas. Para escalas antigas sem configuração completa, aplicam-se os limites padrão exibidos na interface: Vocal 6; Violão, Guitarra e Teclado 2; Baixo, Bateria e Percussão 1. Funções técnicas permanecem sem limite numérico. Escalas já acima do limite não perdem membros, mas recusam novas inclusões naquela função.

O teste de integração backend/tests/test_assignment_transactions.py exige um replica set local descartável codex-local-test em 127.0.0.1:27019. Ele usa clientes independentes, executa oito disputas pela última vaga, verifica rollback após falha injetada, recusa perfis inativos e verifica reutilização de vaga após remoção. Não usa credenciais Atlas. O ambiente publicado requer suporte a transações, como o replica set do Atlas já configurado.

Para executar o teste de integração, defina RUN_MONGO_TRANSACTION_TESTS=1 e rode pytest backend/tests/test_assignment_transactions.py; sem essa variável ele é pulado para não exigir MongoDB local nos testes comuns.

## Renovação da sessão

O acesso continua com duração de 15 minutos. Quando uma chamada protegida recebe 401, a interface usa o cookie HttpOnly de renovação para obter novo acesso e repete a chamada uma única vez. Pedidos simultâneos compartilham a renovação. Login incorreto, recusas 403, rotas públicas e chamadas externas não acionam esse mecanismo. Falhas transitórias de rede durante a renovação não encerram deliberadamente uma sessão já aberta.

Cada login ou cadastro de conta cria uma sessão independente em auth_sessions, com identificador aleatório, hash do token de renovação e expiração fixa de sete dias. A renovação não prorroga esse prazo. O banco possui índice TTL, mas a API também verifica a expiração em cada consulta. Os tokens permanecem em cookies HttpOnly, Secure em produção e SameSite=Lax; não são expostos ao JavaScript nem enviados no corpo da resposta.

A renovação consulta o usuário e suas permissões atuais. Uma conta pendente pode continuar autenticada na tela de espera, sem acesso interno. Inativação, remoção de vínculo, exclusão e mudanças de função continuam valendo imediatamente. O botão Sair revoga a sessão atual no banco e limpa os cookies, mesmo sem acesso válido; os acessos emitidos por essa sessão também deixam de funcionar. Outros logins independentes da mesma pessoa permanecem válidos.

A interface aguarda renovações em andamento antes de concluir login ou logout e não repete pedidos antigos com outra sessão. Se o token de renovação vencer ou a sessão for revogada, será necessário entrar novamente. Contas que já estavam abertas antes desta atualização precisam entrar novamente uma vez, pois os tokens antigos não possuem registro de sessão renovável.

Validação: 125 testes de servidor e seis testes de interface, incluindo expiração, tokens inválidos, revogação, isolamento de logins, origem não autorizada, simultaneidade e prevenção de repetição infinita. Teste visual local simula a primeira expiração em dois segundos; a versão publicada mantém os 15 minutos.

## Validação de datas, horários e estados

Criação e alteração de escalas aceitam apenas datas reais no formato AAAA-MM-DD e horários entre 00:00 e 23:59 em HH:mm. Datas de nascimento, inclusive no cadastro público, também exigem formato e calendário válidos e não podem estar no futuro. O cálculo de idade passa a considerar o aniversário, com a data atual de America/Sao_Paulo. Novos bloqueios de indisponibilidade exigem datas reais.

Status de escala são restritos a Disponibilidade, Rascunho, Em Validação, Validado e Fechada. Status de voluntário são Pendente, Ativo, Inativo e Afastado; fases são Em Teste e Efetivado. Confirmação de participação mantém sua validação já existente. Estados desconhecidos são recusados com 422, sem alterar o registro anterior.

Lotes exigem ao menos uma data e são validados integralmente antes da execução. Uma data inválida recusa o pedido inteiro; datas válidas já passadas continuam sendo informadas como ignoradas, agora usando o dia de São Paulo. A criação individual de eventos passados continua permitida para histórico. Consultas mensais públicas e privadas exigem AAAA-MM, impedindo expressões regulares no parâmetro.

Os formulários afetados mostram mensagens de validação com o nome do campo, incluindo a posição da data em um lote. O formulário público converte a lista de erros da API em texto, evitando falhas de renderização. Registros antigos não são reescritos automaticamente, e a remoção de bloqueios antigos continua aceitando o valor armazenado para permitir limpeza de dados legados.

Validação: 163 testes do servidor e dez testes de interface. Incluem ausência de gravações parciais em requisições inválidas, formatos ambíguos, anos bissextos, limites do relógio, estados conhecidos, cálculo de idade e virada de data em São Paulo.

## Reordenação segura do repertório

PUT /api/setlists/{schedule_id}/reorder aceita somente song_entry_ids (nova ordem dos identificadores das entradas) e expected_entry_ids (ordem vista antes da alteração). Ambos exigem identificadores únicos. Nenhum nome, tom, vocal ou outro metadado é aceito nesse pedido; o servidor reconstrói a lista usando os registros que já possui e atualiza apenas a posição order.

A nova lista deve conter exatamente todas as entradas atuais, uma vez cada. Repetir a mesma música continua permitido quando cada ocorrência tem seu próprio identificador de entrada. Omissões, inclusões inventadas ou identificadores de outra escala são recusados sem gravar. Escala ou repertório inexistente retorna 404. A autorização permanece restrita à liderança.

A ordem esperada deve coincidir com a atual. Além disso, a gravação usa uma comparação atômica com o conteúdo completo lido do banco. Se outra pessoa incluir, remover, reordenar ou alterar dados entre a leitura e a gravação, a API responde 409 e a tela recarrega a versão atual, preservando essa alteração concorrente. Repertórios antigos sem identificadores válidos e únicos são preservados e não são reescritos automaticamente.

Durante o salvamento, a interface bloqueia novas reordenações e as ações de incluir ou remover músicas. O pedido envia somente identificadores, e a tela consulta a versão salva ao terminar. Pedidos no formato antigo, com objetos completos em songs, são recusados; atualize a página se ela já estava aberta antes do deploy.

Validação desta correção: 183 testes do servidor e dez de interface, incluindo entradas omitidas, repetidas, inventadas ou de outra escala, preservação integral de metadados, pedidos antigos, permissões e quatro alterações injetadas entre leitura e gravação. Conferência visual local verifica troca de posição e persistência após recarregar, com tom e vocal preservados.

## Fotos validadas e com tamanho limitado

Novas fotos aceitam JPEG, PNG ou WebP estáticos, até 3 MiB (3.145.728 bytes) e 16 milhões de pixels. O servidor decodifica e verifica o conteúdo real, independentemente do nome ou MIME informado no upload. Arquivos vazios, danificados, SVG, GIF e animações são recusados. Fotos válidas são orientadas conforme o EXIF, reduzidas proporcionalmente a no máximo 1024 × 1024 e regravadas como JPEG de qualidade 85. Transparência recebe fundo branco. A regravação exclui EXIF/GPS e conteúdo adicional do arquivo original.

A mesma validação vale para cadastro público, criação e atualização de voluntários por JSON. Novas URLs externas e outros esquemas não são aceitos como fotos. Fotos legadas permanecem intactas: uma edição que reenvie exatamente o valor antigo preserva esse campo; uma substituição exige imagem válida. A remoção por valor vazio continua disponível. Falhas não alteram a foto anterior nem criam cadastros parciais por foto inválida.

Um middleware conta os bytes efetivamente recebidos antes da análise do formulário/JSON, sem depender de Content-Length, e interrompe corpos acima do teto de base64 de 3 MiB mais 64 KiB para o restante do formulário. O upload também lê no máximo o limite do arquivo mais um byte e fecha o arquivo em todos os casos. Processamento de imagem ocorre em thread para evitar bloquear o ciclo assíncrono. A rota exige liderança e perfil existente; tentativas com perfil ausente retornam 404.

As duas telas informam os limites e formatos; a tela de gestão mostra os erros específicos retornados pelo servidor e permite selecionar novamente o mesmo arquivo. As imagens compactadas continuam armazenadas no MongoDB, sem contratar armazenamento adicional. Esta correção limita o tamanho por imagem; cotas totais de armazenamento e limitação de frequência são trabalhos separados.

Validação: 205 testes do servidor (22 específicos de fotos) e dez testes de interface. Cobrem os três formatos, tipo declarado falso, ausência de gravação em falhas, limite exato e excedido, excesso de pixels, animação, arquivo truncado, metadados, conteúdo adicional, rotas JSON, preservação legada, permissões, perfil inexistente e interrupção de fluxo sem Content-Length. Conferência visual usa somente dados fictícios locais.

## Proteção de login, cadastros e novas senhas

Login aceita dez pedidos por endereço de e-mail em cada janela de 15 minutos. O serviço inteiro tem teto de 60 pedidos de login por minuto. Os dois cadastros públicos compartilham cinco pedidos por e-mail em 15 minutos, dez pedidos gerais por minuto e 30 por hora. São janelas fixas em UTC: a virada de uma janela inicia nova cota. Pedidos bem-sucedidos também contam; a renovação de sessão, logout e navegação autenticada não usam essas cotas.

Os limites gerais são aplicados antes da interpretação do JSON, incluindo corpos malformados. Formulários de login e criação simples de conta têm teto de 16 KiB recebido, sem depender de Content-Length. Cadastro com foto mantém o limite documentado acima. Não usamos IP nem confiamos em X-Forwarded-For: a proteção por e-mail permanece igual se o cabeçalho for alterado. Os tetos gerais são compartilhados por todos os usuários e protegem o serviço gratuito contra tentativas que alternem e-mails.

Contadores ficam na coleção auth_attempts do próprio MongoDB, com incrementos condicionais atômicos e identidade única. São compartilhados entre processos e sobrevivem a reinícios. O identificador é um HMAC com a chave estável JWT_SECRET; não armazenamos e-mail, senha ou IP no contador. O índice TTL em expires_at limpa dados expirados; a liberação de nova janela independe da velocidade dessa limpeza. Excesso retorna 429, Retry-After e mensagem com segundos de espera. Falha no banco recusa novas tentativas com 503 e Retry-After, sem liberar acesso nem expor detalhes internos. Nenhum serviço pago adicional é necessário.

Novas senhas, nos dois cadastros e na criação inicial de administrador, exigem pelo menos 15 caracteres, no máximo 72 bytes UTF-8, e não podem ser inteiramente espaços nem conter caractere nulo. Frases com espaços, acentos e emojis são permitidas dentro desses limites. O teto de bytes impede truncamento silencioso do bcrypt. A regra de tamanho mínimo segue a orientação OWASP para aplicações sem MFA; não representa uma verificação contra todas as senhas vazadas. Senhas existentes continuam funcionando e não são regravadas. Bootstrap não altera credenciais de uma conta já existente.

Hash e verificação bcrypt rodam em thread. Contas inexistentes também executam uma verificação com hash fictício, reduzindo a diferença de tempo em relação a uma senha errada. Ambas retornam a mesma mensagem de credenciais inválidas. Respostas de validação omitem input e ctx para não ecoar senhas ou valores do formulário. As telas de cadastro mostram a nova orientação e validam comprimento Unicode e bytes; login não aplica o mínimo dos novos cadastros às contas antigas.

Validação: 235 testes de regressão do servidor, uma integração com MongoDB real e dois clientes independentes, e 22 testes de interface. A integração disputa 40 pedidos por cota em cinco rodadas: exatamente dez aceitos e 30 recusados em cada rodada; um terceiro processo continua bloqueado. Incluem Unicode e limites de bytes, rejeição antes de criar registros, senha legada curta, cotas compartilhadas, normalização de e-mail, troca de cabeçalhos, JSON inválido, virada de janela, ausência de vazamento de valores, TTL e falha do banco. Conferência visual usa dados fictícios locais.

Referências: https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html e https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html.

## Planejamento mensal e eventos individuais autônomos

A navegação inclui Planejamento mensal para líderes e voluntários. O Dashboard do voluntário passa a ser a página inicial e reúne disponibilidade por dia, participações enviadas para validação, observações e soluções da liderança. O painel da liderança oferece atalhos para os meses e contagens de pendências/ajustes. A página do mês e o painel atualizam respostas a cada 30 segundos enquanto visíveis, ao recuperar foco e pelo botão Atualizar respostas. O menu móvel também permite sair da sessão.

### Abertura e coleta

POST /api/monthly-plans recebe year_month, ministry, dates e availability_deadline opcional. Datas devem ser reais, únicas, dentro do mês e não passadas; o prazo, se informado, fica entre hoje e a primeira data. A criação de todo o mês é transacional. Existe um planejamento por mês e ministério, com identidade determinística que também impede duplicação concorrente. Red Music gera duas equipes em cada data selecionada (Indaiatuba e Itu); Pulse Music gera uma equipe por data. As equipes são escalas normais com plan_id e validation_required=true; os repertórios e links públicos existentes continuam aproveitados. A montagem começa em Coleta, com as equipes ainda como Rascunho e sem exposição pública.

Voluntários possuem ministries, aceitando Red Music, Pulse Music ou ambos. O campo aparece no cadastro público, na criação administrativa e na edição do perfil pela liderança. Os vínculos de conta e a aprovação de acesso continuam obrigatórios. Perfis antigos sem ministries são tratados como Red Music até conferência da liderança, sem reescrever cadastros nem deduzir ministério pelo e-mail. As permissões de gestão não são concedidas por essa seleção.

PUT /api/daily-availability salva respostas estritamente booleanas por voluntário e data, em transação e com identidade/índice únicos. Uma única resposta do dia é compartilhada entre Red e Pulse, sem ser repetida no painel. A operação só aceita datas de planejamentos abertos dos ministérios do voluntário, dentro do prazo, e recusa o lote inteiro se uma data não puder ser respondida. PUT /api/monthly-plans/{id}/availability oferece a mesma resposta para datas daquele mês. A rota antiga de disponibilidade delega à nova regra quando a escala pertence a um planejamento. A ausência de resposta permanece diferente de não; a liderança pode consultar todas as respostas em tabela.

### Montagem das equipes

POST /api/monthly-plans/{id}/stage com montar inicia Montagem. Respostas ainda podem ser atualizadas durante essa etapa, respeitando o prazo, até o envio para validação. A grade mensal é editável por função: adiciona ou remove pessoas, mostra confirmações, exceções e problemas de vínculo. Os detalhes de cada culto continuam disponíveis para repertório e exportação.

A lista padrão de candidatos exige disponibilidade positiva, perfil ativo, vínculo com o ministério, ausência de bloqueio de data e ausência de outra equipe no mesmo dia. include_exceptions=true permite consultar também indisponíveis e pessoas sem resposta. A inclusão nesses casos exige exception_reason não vazio; a resposta original não é alterada. Perfis inativos e de outro ministério não são liberados por essa exceção. O histórico conserva inclusões, remoções, respostas e soluções; as cem entradas mais recentes são exibidas para a liderança.

Toda nova inclusão, inclusive em eventos individuais e escalas antigas, impede que uma pessoa ocupe duas equipes no mesmo dia, independentemente de horário, cidade ou ministério. Várias funções na mesma equipe são permitidas e correspondem a uma única participação para validação. A proteção usa transações e escrita no documento do voluntário para serializar inclusões entre equipes e processos independentes. Mudar a data de uma escala individual com pessoas também verifica conflitos em transação. Duplicidades antigas não são removidas automaticamente.

### Validação, ajustes e conclusão

validar envia o mês completo e muda as equipes para Em Validação. Exige ao menos uma pessoa em cada equipe e uma conta autorizada vinculada a cada perfil ativo escalado. O painel de cada pessoa mostra somente suas próprias participações e observações; cada participação reúne todas as suas funções naquela equipe. Confirmar todas as pendentes envia um lote atômico, sem modificar participações já confirmadas.

PUT /api/monthly-plans/{id}/responses aceita confirmações ou pedidos de ajuste com observação obrigatória. Os pedidos enviam expected_version; uma aba antiga não pode sobrescrever uma participação alterada ou uma resposta mais recente. A autoria deriva do vínculo da conta, nunca de um identificador de voluntário enviado pelo cliente. Líderes que também possuem perfil vinculado respondem às próprias participações pelo Dashboard. A rota antiga de confirmação de membros não permite contornar o fluxo mensal.

reabrir volta o mês à Montagem para o líder corrigir a grade ou registrar uma solução em PUT /api/monthly-plans/{id}/resolve. Alterar funções, incluir ou remover uma função de uma pessoa invalida a confirmação apenas daquela participação; resolver uma observação também pede nova confirmação. Confirmações das outras participações são preservadas no reenvio. Ao remover totalmente uma pessoa, a inclusão da substituta cria uma nova participação pendente; o histórico anterior permanece registrado.

publicar conclui somente quando todas as participações estiverem confirmadas, sem ajustes ou respostas pendentes, e publica as equipes como Fechada. Respostas, montagem e publicação usam a mesma trava transacional do planejamento, impedindo conclusão concorrente com uma nova pendência. Reabrir um mês concluído retira suas equipes da visualização pública enquanto são alteradas. Atualizações de status e exclusões isoladas das equipes pelo CRUD antigo são recusadas para impedir desvio desse controle.

Observações, justificativas, soluções e versões de validação não são expostas nos links públicos nem na leitura de participações de terceiros por outros voluntários. A liderança tem acesso ao acompanhamento completo. Respostas de planejamentos e disponibilidade usam Cache-Control: no-store. Disponibilidades alteradas continuam aparecendo para a liderança sem remover automaticamente pessoas das equipes.

### Fluxo individual preservado

Escalas → Nova escala individual permanece disponível. POST /api/schedules cria um evento independente com validation_required=false; a liderança pode montar e publicar diretamente, sem esperar respostas. Suas participações mostram Dispensada e não geram exigência de validação ao voluntário. Lote avulso também cria eventos independentes sem validação obrigatória. Escalas e lotes anteriores não são convertidos em planejamentos; continuam acessíveis com seus dados, repertórios e links.

Novas coleções: monthly_plans, daily_availability e planning_events. O startup cria seus índices e índices de plan_id nas coleções existentes. Não há nova variável secreta, provedor de mensagens, serviço pago ou contratação. Os avisos deste fluxo aparecem dentro do sistema. Horários não determinam disponibilidade nem conflitos do planejamento; a interface mensal identifica as equipes pelas cidades.

Validação: 257 testes de regressão do servidor, três integrações com MongoDB real e 25 testes de interface (285 no total). Incluem criação e rollback do mês, duplicidade de planejamento, respostas compartilhadas, prazos e lotes inválidos, autorização, exceções justificadas, conflitos entre cidades/ministérios, múltiplas funções, privacidade de observações, versões antigas, solução de ajustes, confirmação em lote, revalidação restrita à participação alterada e publicação individual direta. A integração mensal disputa inclusões do mesmo voluntário entre Red e Pulse em cinco datas, injeta falha após gravação para verificar rollback integral e disputa publicação com pedido de ajuste. Teste visual completo, usando banco local descartável e contas fictícias, percorre criação, coleta, montagem, ajuste, solução, confirmações e conclusão, além de criação/publicação/inclusão em evento individual com validação dispensada.
