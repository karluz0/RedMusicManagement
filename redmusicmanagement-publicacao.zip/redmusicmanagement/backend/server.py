from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, File, UploadFile, status
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import re
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Literal
from pymongo.errors import DuplicateKeyError
import uuid
from datetime import date, datetime, timezone, timedelta
from dateutil.tz import gettz
import bcrypt
import jwt
from bson import ObjectId
import asyncio
import resend
from io import BytesIO
import base64

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")
PUBLIC_SCHEDULE_STATUSES = ("Validado", "Fechada")
PARTICIPATION_SCHEDULE_STATUSES = ("Em Validação", "Validado", "Fechada")

JWT_ALGORITHM = "HS256"
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").lower() == "true"

def get_jwt_secret() -> str:
    secret = os.environ["JWT_SECRET"]
    if len(secret) < 32:
        raise RuntimeError("JWT_SECRET deve ter pelo menos 32 caracteres")
    return secret

def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode("utf-8"), salt)
    return hashed.decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))

def create_access_token(user_id: str, email: str, role: str) -> str:
    payload = {"sub": user_id, "email": email, "role": role, "exp": datetime.now(timezone.utc) + timedelta(minutes=15), "type": "access"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: str) -> str:
    payload = {"sub": user_id, "exp": datetime.now(timezone.utc) + timedelta(days=7), "type": "refresh"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        user["_id"] = str(user["_id"])
        user["id"] = user["_id"]
        user.pop("password_hash", None)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_admin(current_user: dict = Depends(get_current_user)) -> dict:
    if current_user.get("role") not in ("Administrador", "Líder"):
        raise HTTPException(status_code=403, detail="Acesso restrito à liderança")
    return current_user

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: Optional[str] = "Voluntário"

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class VolunteerCreate(BaseModel):
    name: str
    birth_date: str
    email: EmailStr
    phone: str
    photo_url: Optional[str] = ""
    instruments: List[str] = []
    functions: List[str] = []
    phase: str = "Em Teste"
    status: str = "Ativo"
    tags: List[str] = []

class VolunteerUpdate(BaseModel):
    name: Optional[str] = None
    birth_date: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    photo_url: Optional[str] = None
    instruments: Optional[List[str]] = None
    functions: Optional[List[str]] = None
    phase: Optional[str] = None
    status: Optional[str] = None
    tags: Optional[List[str]] = None

class UnavailabilityDate(BaseModel):
    date: str
    reason: Optional[str] = ""

class SongCreate(BaseModel):
    name: str
    artist: Optional[str] = ""
    original_key: str
    bpm: Optional[int] = None
    tempo: str = "4/4"
    tags: List[str] = []
    link_original: Optional[str] = ""
    link_pt_br: Optional[str] = ""
    link_intro_arrangement: Optional[str] = ""
    sheet_music_url: Optional[str] = ""
    notes: Optional[str] = ""

class SongUpdate(BaseModel):
    name: Optional[str] = None
    artist: Optional[str] = None
    original_key: Optional[str] = None
    bpm: Optional[int] = None
    tempo: Optional[str] = None
    tags: Optional[List[str]] = None
    link_original: Optional[str] = None
    link_pt_br: Optional[str] = None
    link_intro_arrangement: Optional[str] = None
    sheet_music_url: Optional[str] = None
    notes: Optional[str] = None

class ScheduleCreate(BaseModel):
    name: str
    date: str
    time: str
    event_type: str = "Domingo"
    ministry: str = "Red Music"
    has_choir: bool = False
    has_orchestra: bool = False
    status: str = "Rascunho"

class ScheduleBatchCreate(BaseModel):
    dates: List[str]
    time: str = "19:00"
    event_type: str = "Domingo"
    ministry: str = "Red Music"
    name_prefix: str = "Culto"
    has_choir: bool = False
    has_orchestra: bool = False

class AvailabilityMark(BaseModel):
    schedule_id: str
    available: bool

class ScheduleUpdate(BaseModel):
    name: Optional[str] = None
    date: Optional[str] = None
    time: Optional[str] = None
    event_type: Optional[str] = None
    ministry: Optional[str] = None
    has_choir: Optional[bool] = None
    has_orchestra: Optional[bool] = None
    status: Optional[str] = None

class ScheduleMemberAdd(BaseModel):
    volunteer_id: str
    function: str

class ScheduleMemberUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirmation_status: Literal["Pendente", "Confirmado", "Preciso de Substituto"]

class VolunteerAccountLink(BaseModel):
    email: EmailStr

class SetlistSongAdd(BaseModel):
    song_id: str
    key_for_this_event: Optional[str] = ""
    main_vocal_volunteer_id: Optional[str] = ""
    order: int

class NotificationRequest(BaseModel):
    recipient_email: Optional[EmailStr] = None
    recipient_phone: Optional[str] = None
    subject: str
    message: str
    channel: str

class ChatMessageCreate(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    to_user_id: str = Field(min_length=1, max_length=24)
    message: str = Field(min_length=1, max_length=2000)

@api_router.post("/auth/register")
async def register(request: RegisterRequest, response: Response):
    email_lower = request.email.lower()
    existing = await db.users.find_one({"email": email_lower})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # SEGURANÇA: Bloqueia autocadastro como Administrador via endpoint público
    safe_role = "Voluntário"
    
    hashed = hash_password(request.password)
    user_doc = {
        "email": email_lower,
        "password_hash": hashed,
        "name": request.name,
        "role": safe_role,
        "created_at": datetime.now(timezone.utc)
    }
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    access_token = create_access_token(user_id, email_lower, safe_role)
    refresh_token = create_refresh_token(user_id)
    
    response.set_cookie(key="access_token", value=access_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=900, path="/")
    response.set_cookie(key="refresh_token", value=refresh_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=604800, path="/")
    
    return {"id": user_id, "email": email_lower, "name": request.name, "role": safe_role}

class PublicVolunteerRegister(BaseModel):
    name: str
    birth_date: str
    email: EmailStr
    phone: str
    photo_url: Optional[str] = ""
    instruments: List[str] = []
    password: str

@api_router.post("/public/volunteers/register")
async def public_volunteer_register(data: PublicVolunteerRegister):
    email_lower = data.email.lower()
    existing_user = await db.users.find_one({"email": email_lower})
    if existing_user:
        raise HTTPException(status_code=400, detail="E-mail já cadastrado")
    
    from dateutil import parser
    birth_date_obj = parser.parse(data.birth_date)
    if birth_date_obj.tzinfo is None:
        birth_date_obj = birth_date_obj.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - birth_date_obj).days // 365
    
    # Cria voluntário
    vol_doc = {
        "id": str(uuid.uuid4()),
        "name": data.name,
        "birth_date": data.birth_date,
        "email": email_lower,
        "phone": data.phone,
        "photo_url": data.photo_url or "",
        "instruments": data.instruments,
        "functions": [],
        "phase": "Em Teste",
        "status": "Ativo",
        "tags": [],
        "age": age,
        "unavailability_dates": [],
        "created_at": datetime.now(timezone.utc)
    }
    await db.volunteers.insert_one(vol_doc)
    
    # Cria user vinculado com role Voluntário (nunca admin)
    hashed = hash_password(data.password)
    await db.users.insert_one({
        "email": email_lower,
        "password_hash": hashed,
        "name": data.name,
        "role": "Voluntário",
        "created_at": datetime.now(timezone.utc)
    })
    
    return {"message": "Cadastro realizado com sucesso! Aguarde aprovação da liderança.", "volunteer_id": vol_doc["id"]}

@api_router.get("/public/monthly/{ministry}/{year_month}")
async def get_public_monthly(ministry: str, year_month: str, response: Response):
    """Retorna apenas escalas publicadas do ministério no mês."""
    response.headers["Cache-Control"] = "no-store"
    schedules = await db.schedules.find({
        "ministry": ministry,
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES},
        "date": {"$regex": f"^{year_month}"}
    }, {"_id": 0}).to_list(1000)
    
    if not schedules:
        return {"ministry": ministry, "year_month": year_month, "schedules": []}
    
    schedules.sort(key=lambda s: s.get("date", ""))
    song_usage = await get_song_usage()
    
    for schedule in schedules:
        members = await db.schedule_members.find({"schedule_id": schedule["id"]}, {"_id": 0}).to_list(1000)
        schedule["members"] = members
        
        setlist = await db.setlists.find_one({"schedule_id": schedule["id"]}, {"_id": 0})
        schedule["setlist"] = setlist.get("songs", []) if setlist else []
        
        # Enriquecer setlist
        for entry in schedule["setlist"]:
            song = await db.songs.find_one({"id": entry.get("song_id")}, {"_id": 0})
            if song:
                entry["song_full"] = with_song_usage(song, song_usage)
    
    return {"ministry": ministry, "year_month": year_month, "schedules": schedules}

@api_router.post("/auth/login")
async def login(request: LoginRequest, response: Response):
    email_lower = request.email.lower()
    user = await db.users.find_one({"email": email_lower})
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not verify_password(request.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    user_id = str(user["_id"])
    access_token = create_access_token(user_id, email_lower, user.get("role", "Voluntário"))
    refresh_token = create_refresh_token(user_id)
    
    response.set_cookie(key="access_token", value=access_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=900, path="/")
    response.set_cookie(key="refresh_token", value=refresh_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=604800, path="/")
    
    return {"id": user_id, "email": email_lower, "name": user.get("name", ""), "role": user.get("role", "Voluntário")}

@api_router.post("/auth/logout")
async def logout(response: Response, current_user: dict = Depends(get_current_user)):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"message": "Logged out successfully"}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return current_user

@api_router.post("/volunteers")
async def create_volunteer(volunteer: VolunteerCreate, current_user: dict = Depends(require_admin)):
    from dateutil import parser
    birth_date_obj = parser.parse(volunteer.birth_date)
    if birth_date_obj.tzinfo is None:
        birth_date_obj = birth_date_obj.replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - birth_date_obj).days // 365
    
    vol_doc = volunteer.model_dump()
    vol_doc["id"] = str(uuid.uuid4())
    vol_doc["age"] = age
    vol_doc["unavailability_dates"] = []
    vol_doc["created_at"] = datetime.now(timezone.utc)
    
    result = await db.volunteers.insert_one(vol_doc)
    vol_doc.pop("_id", None)
    return vol_doc

@api_router.get("/volunteers")
async def get_volunteers(current_user: dict = Depends(require_admin)):
    volunteers = await db.volunteers.find({}).to_list(1000)
    result = []
    for vol in volunteers:
        vol_id = vol.get("id")
        if not vol_id:
            vol_id = str(vol.get("_id", uuid.uuid4()))
            await db.volunteers.update_one({"_id": vol["_id"]}, {"$set": {"id": vol_id}})
            vol["id"] = vol_id
        vol.pop("_id", None)
        result.append(vol)
    return result

@api_router.get("/volunteers/{volunteer_id}")
async def get_volunteer(volunteer_id: str, current_user: dict = Depends(require_admin)):
    volunteer = await db.volunteers.find_one({"id": volunteer_id}, {"_id": 0})
    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")
    return volunteer

@api_router.put("/volunteers/{volunteer_id}")
async def update_volunteer(volunteer_id: str, updates: VolunteerUpdate, current_user: dict = Depends(require_admin)):
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    
    if "birth_date" in update_data:
        from dateutil import parser
        birth_date_obj = parser.parse(update_data["birth_date"])
        if birth_date_obj.tzinfo is None:
            birth_date_obj = birth_date_obj.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - birth_date_obj).days // 365
        update_data["age"] = age
    
    if update_data:
        await db.volunteers.update_one({"id": volunteer_id}, {"$set": update_data})
    
    updated = await db.volunteers.find_one({"id": volunteer_id}, {"_id": 0})
    return updated

@api_router.get("/volunteers/{volunteer_id}/account")
async def get_volunteer_account(volunteer_id: str, current_user: dict = Depends(require_admin)):
    account = await db.users.find_one({"volunteer_id": volunteer_id}, {"_id": 0, "email": 1})
    return {"email": account["email"] if account else None}

@api_router.put("/volunteers/{volunteer_id}/account")
async def link_volunteer_account(volunteer_id: str, data: VolunteerAccountLink, current_user: dict = Depends(require_admin)):
    if not await db.volunteers.find_one({"id": volunteer_id}):
        raise HTTPException(status_code=404, detail="Voluntário não encontrado")
    account = await db.users.find_one({"email": data.email.lower()})
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada. O voluntário precisa criar sua conta primeiro.")
    if account.get("volunteer_id") not in (None, volunteer_id):
        raise HTTPException(status_code=409, detail="Esta conta já está vinculada a outro voluntário")
    try:
        result = await db.users.update_one(
            {"_id": account["_id"], "$or": [{"volunteer_id": {"$exists": False}}, {"volunteer_id": volunteer_id}]},
            {"$set": {"volunteer_id": volunteer_id}},
        )
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Este voluntário já possui uma conta vinculada")
    if result.matched_count == 0:
        raise HTTPException(status_code=409, detail="O vínculo foi alterado. Atualize a página e tente novamente.")
    return {"email": account["email"]}

@api_router.delete("/volunteers/{volunteer_id}/account")
async def unlink_volunteer_account(volunteer_id: str, current_user: dict = Depends(require_admin)):
    await db.users.update_one({"volunteer_id": volunteer_id}, {"$unset": {"volunteer_id": ""}})
    return {"email": None}

@api_router.delete("/volunteers/{volunteer_id}")
async def delete_volunteer(volunteer_id: str, current_user: dict = Depends(require_admin)):
    result = await db.volunteers.delete_one({"id": volunteer_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Volunteer not found")
    await db.users.update_one({"volunteer_id": volunteer_id}, {"$unset": {"volunteer_id": ""}})
    return {"message": "Volunteer deleted successfully"}

@api_router.post("/volunteers/{volunteer_id}/unavailability")
async def add_unavailability(volunteer_id: str, unavail: UnavailabilityDate, current_user: dict = Depends(require_admin)):
    await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$push": {"unavailability_dates": unavail.model_dump()}}
    )
    return {"message": "Unavailability added"}

@api_router.delete("/volunteers/{volunteer_id}/unavailability/{date}")
async def remove_unavailability(volunteer_id: str, date: str, current_user: dict = Depends(require_admin)):
    await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$pull": {"unavailability_dates": {"date": date}}}
    )
    return {"message": "Unavailability removed"}

@api_router.post("/songs")
async def create_song(song: SongCreate, current_user: dict = Depends(require_admin)):
    song_doc = song.model_dump()
    song_doc["id"] = str(uuid.uuid4())
    song_doc["last_played_date"] = None
    song_doc["play_count"] = 0
    song_doc["created_at"] = datetime.now(timezone.utc)
    
    await db.songs.insert_one(song_doc)
    song_doc.pop("_id", None)
    return song_doc

async def get_song_usage():
    ministry_timezone = gettz("America/Sao_Paulo")
    if ministry_timezone is None:
        raise RuntimeError("Fuso horário do ministério indisponível")
    today = datetime.now(timezone.utc).astimezone(ministry_timezone).date().isoformat()
    schedules = await db.schedules.find({
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES}, "date": {"$lt": today},
    }, {"_id": 0, "id": 1, "date": 1}).to_list(None)
    event_dates = {}
    for schedule in schedules:
        try:
            event_date = date.fromisoformat(schedule.get("date", ""))
        except (TypeError, ValueError):
            continue
        if schedule.get("id") and event_date.isoformat() == schedule["date"]:
            event_dates[schedule["id"]] = schedule["date"]
    if not event_dates:
        return {}
    setlists = await db.setlists.find({"schedule_id": {"$in": list(event_dates)}}, {
        "_id": 0, "schedule_id": 1, "songs.song_id": 1,
    }).to_list(None)
    used_in = {}
    for setlist in setlists:
        for entry in setlist.get("songs", []):
            if entry.get("song_id"):
                used_in.setdefault(entry["song_id"], set()).add(setlist["schedule_id"])
    return {song_id: {"play_count": len(events), "last_played_date": max(event_dates[event] for event in events)}
            for song_id, events in used_in.items()}

def with_song_usage(song: dict, usage: dict):
    return {**song, **usage.get(song.get("id"), {"play_count": 0, "last_played_date": None})}

@api_router.get("/songs")
async def get_songs(current_user: dict = Depends(get_current_user)):
    songs = await db.songs.find({}, {"_id": 0}).to_list(1000)
    usage = await get_song_usage()
    return [with_song_usage(song, usage) for song in songs]

@api_router.get("/songs/{song_id}")
async def get_song(song_id: str, current_user: dict = Depends(get_current_user)):
    song = await db.songs.find_one({"id": song_id}, {"_id": 0})
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")
    return with_song_usage(song, await get_song_usage())

@api_router.put("/songs/{song_id}")
async def update_song(song_id: str, updates: SongUpdate, current_user: dict = Depends(require_admin)):
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    if update_data:
        await db.songs.update_one({"id": song_id}, {"$set": update_data})
    updated = await db.songs.find_one({"id": song_id}, {"_id": 0})
    if not updated:
        raise HTTPException(status_code=404, detail="Song not found")
    return with_song_usage(updated, await get_song_usage())

@api_router.delete("/songs/{song_id}")
async def delete_song(song_id: str, current_user: dict = Depends(require_admin)):
    result = await db.songs.delete_one({"id": song_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Song not found")
    return {"message": "Song deleted successfully"}

@api_router.post("/schedules")
async def create_schedule(schedule: ScheduleCreate, current_user: dict = Depends(require_admin)):
    schedule_doc = schedule.model_dump()
    schedule_doc["id"] = str(uuid.uuid4())
    schedule_doc["share_token"] = str(uuid.uuid4())
    schedule_doc["created_at"] = datetime.now(timezone.utc)
    schedule_doc["created_by"] = current_user["_id"]
    schedule_doc["team_slots"] = {
        "Vocal": 6, "Violão": 2, "Guitarra": 2, "Teclado": 2,
        "Baixo": 1, "Bateria": 1, "Percussão": 1
    }
    
    await db.schedules.insert_one(schedule_doc)
    schedule_doc.pop("_id", None)
    return schedule_doc

@api_router.post("/schedules/batch")
async def create_schedules_batch(batch: ScheduleBatchCreate, current_user: dict = Depends(require_admin)):
    from dateutil import parser as dateparser
    today = datetime.now(timezone.utc).date()
    created = []
    skipped = []
    
    for date_str in batch.dates:
        try:
            date_obj = dateparser.parse(date_str).date()
        except Exception:
            skipped.append({"date": date_str, "reason": "invalid_date"})
            continue
        
        if date_obj < today:
            skipped.append({"date": date_str, "reason": "past_date"})
            continue
        
        weekday_names_pt = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
        weekday = weekday_names_pt[date_obj.weekday()]
        
        schedule_doc = {
            "id": str(uuid.uuid4()),
            "share_token": str(uuid.uuid4()),
            "name": f"{batch.name_prefix} - {date_obj.strftime('%d/%m/%Y')}",
            "date": date_obj.isoformat(),
            "time": batch.time,
            "event_type": batch.event_type,
            "ministry": batch.ministry,
            "has_choir": batch.has_choir,
            "has_orchestra": batch.has_orchestra,
            "status": "Rascunho",
            "created_at": datetime.now(timezone.utc),
            "created_by": current_user["_id"],
            "team_slots": {
                "Vocal": 6, "Violão": 2, "Guitarra": 2, "Teclado": 2,
                "Baixo": 1, "Bateria": 1, "Percussão": 1
            }
        }
        await db.schedules.insert_one(schedule_doc)
        schedule_doc.pop("_id", None)
        created.append(schedule_doc)
    
    return {"created": created, "skipped": skipped, "total_created": len(created)}

@api_router.post("/schedules/{schedule_id}/availability")
async def mark_availability(schedule_id: str, mark: AvailabilityMark, current_user: dict = Depends(get_current_user)):
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    # Encontrar o voluntário associado a este usuário (por email)
    volunteer = await db.volunteers.find_one({"email": current_user["email"]}, {"_id": 0})
    if not volunteer:
        raise HTTPException(status_code=404, detail="Voluntário não encontrado para este usuário")
    
    await db.availability.update_one(
        {"schedule_id": schedule_id, "volunteer_id": volunteer["id"]},
        {"$set": {
            "schedule_id": schedule_id,
            "volunteer_id": volunteer["id"],
            "volunteer_name": volunteer["name"],
            "available": mark.available,
            "marked_at": datetime.now(timezone.utc)
        }},
        upsert=True
    )
    return {"message": "Disponibilidade registrada"}

async def get_monthly_participation_counts(year_month: str, volunteer_id: Optional[str] = None):
    """Count each person's distinct assigned schedules, rather than member rows."""
    if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", year_month):
        return {}
    schedules = await db.schedules.find({
        "date": {"$regex": f"^{year_month}-"},
        "status": {"$in": PARTICIPATION_SCHEDULE_STATUSES},
    }, {"_id": 0, "id": 1}).to_list(None)
    schedule_ids = [schedule["id"] for schedule in schedules if schedule.get("id")]
    if not schedule_ids:
        return {}
    member_query = {"schedule_id": {"$in": schedule_ids}}
    if volunteer_id is not None:
        member_query["volunteer_id"] = volunteer_id
    members = await db.schedule_members.find(
        member_query, {"_id": 0, "volunteer_id": 1, "schedule_id": 1}
    ).to_list(None)
    participation = {}
    for member in members:
        if member.get("volunteer_id"):
            participation.setdefault(member["volunteer_id"], set()).add(member["schedule_id"])
    return {person: len(assigned_schedules) for person, assigned_schedules in participation.items()}

@api_router.get("/schedules/{schedule_id}/available-volunteers")
async def get_available_volunteers_for_schedule(schedule_id: str, current_user: dict = Depends(require_admin)):
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    schedule_date = schedule.get("date", "")
    
    availabilities = await db.availability.find({"schedule_id": schedule_id, "available": True}, {"_id": 0}).to_list(1000)
    available_ids = [a["volunteer_id"] for a in availabilities]
    
    all_volunteers = await db.volunteers.find({"status": "Ativo"}).to_list(1000)
    monthly_counts = await get_monthly_participation_counts(schedule_date[:7])
    
    result = []
    for vol in all_volunteers:
        # Backfill: ensure 'id' field exists (legacy documents may only have _id)
        vol_id = vol.get("id")
        if not vol_id:
            vol_id = str(vol.get("_id", uuid.uuid4()))
            await db.volunteers.update_one({"_id": vol["_id"]}, {"$set": {"id": vol_id}})
            vol["id"] = vol_id
        vol.pop("_id", None)
        
        is_unavailable = any(u.get("date") == schedule_date for u in vol.get("unavailability_dates", []))
        if is_unavailable:
            continue
        
        has_availability_records = len(availabilities) > 0
        if has_availability_records and vol_id not in available_ids:
            continue
        
        monthly_count = monthly_counts.get(vol_id, 0)
        
        vol["monthly_schedule_count"] = monthly_count
        vol["is_exhausted"] = monthly_count >= 2
        vol["explicitly_available"] = vol_id in available_ids
        result.append(vol)
    
    return result

@api_router.get("/volunteers/{volunteer_id}/monthly-count/{year_month}")
async def get_volunteer_monthly_count(volunteer_id: str, year_month: str, current_user: dict = Depends(require_admin)):
    if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", year_month):
        raise HTTPException(status_code=422, detail="Informe o mês no formato AAAA-MM")
    counts = await get_monthly_participation_counts(year_month, volunteer_id)
    count = counts.get(volunteer_id, 0)
    return {"volunteer_id": volunteer_id, "year_month": year_month, "count": count}

@api_router.get("/schedules")
async def get_schedules(current_user: dict = Depends(get_current_user)):
    schedules = await db.schedules.find({}, {"_id": 0}).to_list(1000)
    # Backfill share_token para escalas antigas
    for s in schedules:
        if not s.get("share_token"):
            token = str(uuid.uuid4())
            await db.schedules.update_one({"id": s["id"]}, {"$set": {"share_token": token}})
            s["share_token"] = token
        if not s.get("ministry"):
            await db.schedules.update_one({"id": s["id"]}, {"$set": {"ministry": "Red Music"}})
            s["ministry"] = "Red Music"
    return schedules

@api_router.get("/public/schedules/{share_token}")
async def get_public_schedule(share_token: str, response: Response):
    response.headers["Cache-Control"] = "no-store"
    schedule = await db.schedules.find_one({
        "share_token": share_token,
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES},
    }, {"_id": 0})
    if not schedule:
        raise HTTPException(
            status_code=404,
            detail="Escala não encontrada ou indisponível para visualização pública",
            headers={"Cache-Control": "no-store"},
        )
    
    members = await db.schedule_members.find({"schedule_id": schedule["id"]}, {"_id": 0}).to_list(1000)
    schedule["members"] = members
    
    setlist = await db.setlists.find_one({"schedule_id": schedule["id"]}, {"_id": 0})
    schedule["setlist"] = setlist.get("songs", []) if setlist else []
    
    # Enriquecer setlist com dados completos das músicas
    song_usage = await get_song_usage()
    for entry in schedule["setlist"]:
        song = await db.songs.find_one({"id": entry.get("song_id")}, {"_id": 0})
        if song:
            entry["song_full"] = with_song_usage(song, song_usage)
    
    return schedule

@api_router.get("/schedules/{schedule_id}")
async def get_schedule(schedule_id: str, current_user: dict = Depends(get_current_user)):
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    members = await db.schedule_members.find({"schedule_id": schedule_id}, {"_id": 0}).to_list(1000)
    own_volunteer = await db.volunteers.find_one({"id": current_user.get("volunteer_id"), "status": "Ativo"})
    for member in members:
        member["can_confirm"] = bool(
            current_user.get("role") == "Voluntário" and own_volunteer
            and member["volunteer_id"] == own_volunteer["id"]
        )
    schedule["members"] = members
    
    setlist = await db.setlists.find_one({"schedule_id": schedule_id}, {"_id": 0})
    schedule["setlist"] = setlist.get("songs", []) if setlist else []
    
    return schedule

@api_router.put("/schedules/{schedule_id}")
async def update_schedule(schedule_id: str, updates: ScheduleUpdate, current_user: dict = Depends(require_admin)):
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    if update_data:
        await db.schedules.update_one({"id": schedule_id}, {"$set": update_data})
    updated = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    return updated

@api_router.delete("/schedules/{schedule_id}")
async def delete_schedule(schedule_id: str, current_user: dict = Depends(require_admin)):
    await db.schedules.delete_one({"id": schedule_id})
    await db.schedule_members.delete_many({"schedule_id": schedule_id})
    await db.setlists.delete_one({"schedule_id": schedule_id})
    return {"message": "Schedule deleted successfully"}

@api_router.post("/schedules/{schedule_id}/members")
async def add_schedule_member(schedule_id: str, member: ScheduleMemberAdd, current_user: dict = Depends(require_admin)):
    volunteer = await db.volunteers.find_one({"id": member.volunteer_id}, {"_id": 0})
    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")
    
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    
    # Verificar indisponibilidade
    schedule_date = schedule.get("date", "")
    unavail_dates = volunteer.get("unavailability_dates", [])
    for unavail in unavail_dates:
        if unavail.get("date") == schedule_date:
            return {"warning": f"Voluntário {volunteer['name']} está indisponível nesta data: {unavail.get('reason', 'Sem motivo especificado')}"}
    
    # Verificar limite de vagas
    team_slots = schedule.get("team_slots", {})
    function_normalized = "Vocal" if "vocal" in member.function.lower() else member.function
    
    if function_normalized in team_slots:
        limit = team_slots[function_normalized]
        current_count = await db.schedule_members.count_documents({
            "schedule_id": schedule_id,
            "function": {"$regex": f"^{function_normalized.replace('ã', '[ãa]').replace('ç', '[çc]')}", "$options": "i"} if function_normalized == "Vocal" else function_normalized
        })
        
        # Contagem mais simples: apenas mesma função exata
        if function_normalized == "Vocal":
            current_count = await db.schedule_members.count_documents({
                "schedule_id": schedule_id,
                "function": {"$in": ["Vocal", "Backing Vocal"]}
            })
        else:
            current_count = await db.schedule_members.count_documents({
                "schedule_id": schedule_id,
                "function": function_normalized
            })
        
        if current_count >= limit:
            raise HTTPException(
                status_code=400, 
                detail=f"Limite de {limit} vaga(s) para {function_normalized} já atingido"
            )
    
    member_doc = {
        "id": str(uuid.uuid4()),
        "schedule_id": schedule_id,
        "volunteer_id": member.volunteer_id,
        "volunteer_name": volunteer["name"],
        "function": member.function,
        "confirmation_status": "Pendente",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.schedule_members.insert_one(member_doc)
    member_doc.pop("_id", None)
    return member_doc
    
    member_doc = {
        "id": str(uuid.uuid4()),
        "schedule_id": schedule_id,
        "volunteer_id": member.volunteer_id,
        "volunteer_name": volunteer["name"],
        "function": member.function,
        "confirmation_status": "Pendente",
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.schedule_members.insert_one(member_doc)
    member_doc.pop("_id", None)
    return member_doc

@api_router.put("/schedules/{schedule_id}/members/{member_id}")
async def update_schedule_member(schedule_id: str, member_id: str, updates: ScheduleMemberUpdate, current_user: dict = Depends(get_current_user)):
    member_query = {"id": member_id, "schedule_id": schedule_id}
    member = await db.schedule_members.find_one(member_query, {"_id": 0})
    if not member or not await db.schedules.find_one({"id": schedule_id}):
        raise HTTPException(status_code=404, detail="Participação não encontrada nesta escala")
    if current_user.get("role") not in ("Administrador", "Líder"):
        volunteer = await db.volunteers.find_one({"id": current_user.get("volunteer_id"), "status": "Ativo"})
        if (current_user.get("role") != "Voluntário" or not volunteer
                or member["volunteer_id"] != volunteer["id"]):
            raise HTTPException(status_code=403, detail="Você só pode responder pela sua própria participação")
    await db.schedule_members.update_one(
        member_query,
        {"$set": {"confirmation_status": updates.confirmation_status}}
    )
    updated = await db.schedule_members.find_one(member_query, {"_id": 0})
    return updated

@api_router.delete("/schedules/{schedule_id}/members/{member_id}")
async def delete_schedule_member(schedule_id: str, member_id: str, current_user: dict = Depends(require_admin)):
    result = await db.schedule_members.delete_one({"id": member_id, "schedule_id": schedule_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Member not found")
    return {"message": "Member removed from schedule"}

@api_router.post("/setlists/{schedule_id}/songs")
async def add_setlist_song(schedule_id: str, song_data: SetlistSongAdd, current_user: dict = Depends(require_admin)):
    if not await db.schedules.find_one({"id": schedule_id}, {"_id": 1}):
        raise HTTPException(status_code=404, detail="Schedule not found")
    song = await db.songs.find_one({"id": song_data.song_id}, {"_id": 0})
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")
    
    setlist = await db.setlists.find_one({"schedule_id": schedule_id})
    
    song_entry = {
        "id": str(uuid.uuid4()),
        "song_id": song_data.song_id,
        "song_name": song["name"],
        "original_key": song["original_key"],
        "key_for_this_event": song_data.key_for_this_event or song["original_key"],
        "main_vocal_volunteer_id": song_data.main_vocal_volunteer_id,
        "order": song_data.order
    }
    
    if setlist:
        await db.setlists.update_one(
            {"schedule_id": schedule_id},
            {"$push": {"songs": song_entry}}
        )
    else:
        setlist_doc = {
            "schedule_id": schedule_id,
            "songs": [song_entry],
            "created_at": datetime.now(timezone.utc)
        }
        await db.setlists.insert_one(setlist_doc)
    
    return song_entry

@api_router.get("/setlists/{schedule_id}")
async def get_setlist(schedule_id: str, current_user: dict = Depends(get_current_user)):
    setlist = await db.setlists.find_one({"schedule_id": schedule_id}, {"_id": 0})
    if not setlist:
        return {"schedule_id": schedule_id, "songs": []}
    return setlist

@api_router.delete("/setlists/{schedule_id}/songs/{song_entry_id}")
async def remove_setlist_song(schedule_id: str, song_entry_id: str, current_user: dict = Depends(require_admin)):
    await db.setlists.update_one(
        {"schedule_id": schedule_id},
        {"$pull": {"songs": {"id": song_entry_id}}}
    )
    return {"message": "Song removed from setlist"}

class SetlistReorder(BaseModel):
    songs: List[dict]

@api_router.put("/setlists/{schedule_id}/reorder")
async def reorder_setlist(schedule_id: str, data: SetlistReorder, current_user: dict = Depends(require_admin)):
    await db.setlists.update_one(
        {"schedule_id": schedule_id},
        {"$set": {"songs": data.songs}}
    )
    return {"message": "Setlist reordered successfully"}

@api_router.get("/schedules/{schedule_id}/vocals")
async def get_schedule_vocals(schedule_id: str, current_user: dict = Depends(get_current_user)):
    members = await db.schedule_members.find(
        {"schedule_id": schedule_id, "function": {"$regex": "vocal", "$options": "i"}},
        {"_id": 0}
    ).to_list(1000)
    return members

@api_router.get("/volunteers/{volunteer_id}/participation-history")
async def get_volunteer_participation(volunteer_id: str, current_user: dict = Depends(require_admin)):
    schedules = await db.schedules.find({}, {"_id": 0}).to_list(1000)
    
    participation = []
    for schedule in schedules:
        members = await db.schedule_members.find(
            {"schedule_id": schedule["id"], "volunteer_id": volunteer_id},
            {"_id": 0}
        ).to_list(1000)
        
        if members:
            for member in members:
                participation.append({
                    "schedule_id": schedule["id"],
                    "schedule_name": schedule["name"],
                    "schedule_date": schedule["date"],
                    "schedule_time": schedule["time"],
                    "function": member["function"],
                    "confirmation_status": member["confirmation_status"]
                })
    
    participation.sort(key=lambda x: x["schedule_date"], reverse=True)
    return participation

@api_router.get("/dashboard/metrics")
async def get_dashboard_metrics(current_user: dict = Depends(require_admin)):
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    schedules_count = await db.schedules.count_documents({})
    volunteers_count = await db.volunteers.count_documents({"status": "Ativo"})
    songs_count = await db.songs.count_documents({})
    
    volunteers = await db.volunteers.find({"status": "Ativo"}, {"_id": 0, "birth_date": 1, "name": 1}).to_list(1000)
    birthdays = []
    for vol in volunteers:
        if vol.get("birth_date"):
            from dateutil import parser
            bd = parser.parse(vol["birth_date"])
            if bd.month == now.month:
                birthdays.append({"name": vol["name"], "date": bd.day})
    
    return {
        "total_schedules": schedules_count,
        "active_volunteers": volunteers_count,
        "total_songs": songs_count,
        "birthdays_this_month": birthdays
    }

@api_router.get("/dashboard/top-songs")
async def get_top_songs(current_user: dict = Depends(require_admin)):
    usage = await get_song_usage()
    songs = await db.songs.find({"id": {"$in": list(usage)}}, {"_id": 0}).to_list(None)
    songs = [with_song_usage(song, usage) for song in songs]
    songs.sort(key=lambda song: (-song["play_count"], song.get("name", "").casefold(), song["id"]))
    return songs[:10]

@api_router.get("/dashboard/burnout-alert")
async def get_burnout_alert(current_user: dict = Depends(require_admin)):
    schedules = await db.schedules.find(
        {"status": {"$in": PARTICIPATION_SCHEDULE_STATUSES}},
        {"_id": 0, "id": 1, "date": 1, "time": 1, "ministry": 1},
    ).to_list(None)
    ministries = {}
    for schedule in schedules:
        try:
            event_date = date.fromisoformat(schedule.get("date", ""))
        except (TypeError, ValueError):
            continue
        if schedule.get("id"):
            schedule["event_date"] = event_date
            ministries.setdefault(schedule.get("ministry") or "Red Music", []).append(schedule)

    volunteers = await db.volunteers.find(
        {"status": "Ativo"}, {"_id": 0, "id": 1, "name": 1}
    ).to_list(None)
    active_names = {person["id"]: person.get("name", "Voluntário") for person in volunteers if person.get("id")}
    members = await db.schedule_members.find(
        {"schedule_id": {"$in": [event["id"] for events in ministries.values() for event in events]}},
        {"_id": 0, "schedule_id": 1, "volunteer_id": 1},
    ).to_list(None)
    teams = {}
    for member in members:
        if member.get("volunteer_id") in active_names:
            teams.setdefault(member["schedule_id"], set()).add(member["volunteer_id"])

    # Report current planning streaks, not totals from old or interrupted runs.
    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).date()
    alerts = {}
    for ministry, events in sorted(ministries.items()):
        events.sort(key=lambda event: (event["event_date"], event.get("time") or "", event["id"]), reverse=True)
        last_date = events[0]["event_date"]
        if last_date < cutoff:
            continue
        ongoing = set(teams.get(events[0]["id"], set()))
        lengths = {person: 1 for person in ongoing}
        first_dates = {person: last_date for person in ongoing}
        previous_date = last_date
        for event in events[1:]:
            if (previous_date - event["event_date"]).days > 7:
                break
            ongoing.intersection_update(teams.get(event["id"], set()))
            if not ongoing:
                break
            for person in ongoing:
                lengths[person] += 1
                first_dates[person] = event["event_date"]
            previous_date = event["event_date"]
        for person, count in lengths.items():
            if count < 4:
                continue
            candidate = {
                "volunteer_id": person, "name": active_names[person],
                "consecutive_schedules": count, "ministry": ministry,
                "first_date": first_dates[person].isoformat(), "last_date": last_date.isoformat(),
            }
            existing = alerts.get(person)
            if existing is None or (count, candidate["last_date"]) > (existing["consecutive_schedules"], existing["last_date"]):
                alerts[person] = candidate
    return sorted(alerts.values(), key=lambda alert: (-alert["consecutive_schedules"], alert["name"].casefold(), alert["volunteer_id"]))

@api_router.post("/notifications/send")
async def send_notification(notif: NotificationRequest, current_user: dict = Depends(require_admin)):
    result = {"email_sent": False, "sms_sent": False}
    
    if notif.channel in ["email", "both"] and notif.recipient_email:
        resend.api_key = os.environ.get("RESEND_API_KEY", "")
        if resend.api_key:
            try:
                params = {
                    "from": os.environ.get("SENDER_EMAIL", "onboarding@resend.dev"),
                    "to": [notif.recipient_email],
                    "subject": notif.subject,
                    "html": f"<p>{notif.message}</p>"
                }
                email = await asyncio.to_thread(resend.Emails.send, params)
                result["email_sent"] = True
            except Exception as e:
                result["email_error"] = str(e)
    
    if notif.channel in ["sms", "both"] and notif.recipient_phone:
        pass
    
    notif_doc = notif.model_dump()
    notif_doc["id"] = str(uuid.uuid4())
    notif_doc["sent_at"] = datetime.now(timezone.utc)
    notif_doc["sent_by"] = current_user["id"]
    notif_doc["result"] = result
    await db.notifications.insert_one(notif_doc)
    
    return result

async def get_chat_identity(account: dict):
    role = account.get("role")
    if role in ("Administrador", "Líder"):
        return {"id": str(account["_id"]), "name": account.get("name") or "Liderança", "role": role}
    if role == "Voluntário" and account.get("volunteer_id"):
        volunteer = await db.volunteers.find_one({"id": account["volunteer_id"], "status": "Ativo"}, {"_id": 0, "name": 1})
        if volunteer:
            return {"id": str(account["_id"]), "name": volunteer.get("name") or "Voluntário", "role": role}
    return None

async def require_chat_user(current_user: dict = Depends(get_current_user)):
    identity = await get_chat_identity(current_user)
    if not identity:
        raise HTTPException(status_code=403, detail="Para acessar as mensagens, sua conta precisa estar vinculada pela liderança a um voluntário ativo")
    return identity

async def get_chat_recipient(other_user_id: str, current_user: dict):
    if not ObjectId.is_valid(other_user_id) or str(ObjectId(other_user_id)) == current_user["id"]:
        raise HTTPException(status_code=404, detail="Contato indisponível")
    account = await db.users.find_one({"_id": ObjectId(other_user_id)}, {"_id": 1, "name": 1, "role": 1, "volunteer_id": 1})
    identity = await get_chat_identity(account) if account else None
    if not identity or (current_user["role"] == "Voluntário" and identity["role"] == "Voluntário"):
        raise HTTPException(status_code=404, detail="Contato indisponível")
    return identity

@api_router.get("/chat/contacts")
async def get_chat_contacts(current_user: dict = Depends(require_chat_user)):
    roles = ["Administrador", "Líder"]
    if current_user["role"] in roles:
        roles.append("Voluntário")
    accounts = await db.users.find({"role": {"$in": roles}}, {"_id": 1, "name": 1, "role": 1, "volunteer_id": 1}).to_list(1000)
    contacts = []
    for account in accounts:
        if str(account["_id"]) == current_user["id"]:
            continue
        identity = await get_chat_identity(account)
        if identity:
            contacts.append(identity)
    return sorted(contacts, key=lambda contact: contact["name"].casefold())

@api_router.post("/chat/messages")
async def send_chat_message(message: ChatMessageCreate, current_user: dict = Depends(require_chat_user)):
    recipient = await get_chat_recipient(message.to_user_id, current_user)
    msg_doc = {
        "id": str(uuid.uuid4()),
        "from_user_id": current_user["id"],
        "from_user_name": current_user["name"],
        "to_user_id": recipient["id"],
        "message": message.message,
        "read": False,
        "timestamp": datetime.now(timezone.utc)
    }
    await db.chat_messages.insert_one(msg_doc)
    msg_doc.pop("_id", None)
    return msg_doc

@api_router.get("/chat/messages/{other_user_id}")
async def get_chat_messages(other_user_id: str, current_user: dict = Depends(require_chat_user)):
    recipient = await get_chat_recipient(other_user_id, current_user)
    other_user_id = recipient["id"]
    messages = await db.chat_messages.find(
        {
            "$or": [
                {"from_user_id": current_user["id"], "to_user_id": other_user_id},
                {"from_user_id": other_user_id, "to_user_id": current_user["id"]}
            ]
        },
        {"_id": 0}
    ).sort([("timestamp", -1), ("_id", -1)]).limit(100).to_list(100)
    messages.reverse()
    return messages

@api_router.post("/volunteers/{volunteer_id}/upload-photo")
async def upload_volunteer_photo(volunteer_id: str, file: UploadFile = File(...), current_user: dict = Depends(require_admin)):
    contents = await file.read()
    base64_image = base64.b64encode(contents).decode('utf-8')
    photo_url = f"data:{file.content_type};base64,{base64_image}"
    
    await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$set": {"photo_url": photo_url}}
    )
    
    return {"photo_url": photo_url}

app.include_router(api_router)

@app.middleware("http")
async def prevent_private_data_caching(request: Request, call_next):
    response = await call_next(request)
    if (request.url.path.startswith("/api/volunteers")
            or request.url.path.endswith("/available-volunteers")
            or request.url.path.startswith("/api/chat/")
            or request.url.path == "/api/songs" or request.url.path.startswith("/api/songs/")
            or request.url.path.startswith("/api/dashboard/")):
        response.headers["Cache-Control"] = "no-store"
    return response

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=[origin.strip() for origin in os.environ.get('CORS_ORIGINS', '').split(',') if origin.strip()],
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    get_jwt_secret()
    await db.users.create_index("email", unique=True)
    await db.users.create_index("volunteer_id", unique=True, sparse=True)
    await db.volunteers.create_index("id", unique=True)
    await db.songs.create_index("id", unique=True)
    await db.schedules.create_index("id", unique=True)
    await db.schedule_members.create_index("id", unique=True)
    
    admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "")
    if admin_email and admin_password:
        existing = await db.users.find_one({"email": admin_email})
        if existing is None:
            if len(admin_password) < 12:
                raise RuntimeError("ADMIN_PASSWORD deve ter pelo menos 12 caracteres")
            await db.users.insert_one({
                "email": admin_email,
                "password_hash": hash_password(admin_password),
                "name": "Administrador",
                "role": "Administrador",
                "created_at": datetime.now(timezone.utc)
            })
            logger.info("Administrador inicial criado")
        elif existing.get("role") != "Administrador":
            raise RuntimeError("ADMIN_EMAIL já pertence a uma conta sem perfil de administrador")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()


@app.get("/api/health")
async def health():
    try:
        await db.command("ping")
    except Exception:
        return JSONResponse(status_code=503, content={"status": "unavailable"})
    return {"status": "ok"}


FRONTEND_BUILD = ROOT_DIR.parent / "frontend" / "build"
if (FRONTEND_BUILD / "index.html").is_file():
    app.mount("/static", StaticFiles(directory=FRONTEND_BUILD / "static"), name="static")

    @app.get("/{path:path}", include_in_schema=False)
    async def frontend(path: str):
        if path == "api" or path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found")
        candidate = (FRONTEND_BUILD / path).resolve()
        if candidate.is_relative_to(FRONTEND_BUILD.resolve()) and candidate.is_file():
            return FileResponse(candidate)
        if Path(path).suffix:
            raise HTTPException(status_code=404, detail="Not found")
        return FileResponse(FRONTEND_BUILD / "index.html", headers={"Cache-Control": "no-cache"})
