from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, File, UploadFile, status
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
from fastapi.exceptions import RequestValidationError
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import re
import json
import unicodedata
from pydantic import BaseModel, Field, ConfigDict, EmailStr, StrictBool, AfterValidator, field_validator, model_validator
from typing import List, Optional, Literal, Annotated
from pymongo.errors import DuplicateKeyError
from pymongo.errors import PyMongoError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern
import uuid
from datetime import date, datetime, timezone, timedelta
from dateutil.tz import gettz
import bcrypt
import jwt
from bson import ObjectId
import asyncio
import resend
from io import BytesIO
import base64
import hashlib
import hmac
import math
import binascii
import warnings
from PIL import Image, ImageOps, UnidentifiedImageError
from bson.errors import InvalidId

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()


@app.exception_handler(RequestValidationError)
async def validation_without_input(request, error):
    # Validation messages must not echo submitted passwords or form values.
    safe = [{key: value for key, value in item.items() if key not in {"input", "ctx"}} for item in error.errors()]
    return await request_validation_exception_handler(request, RequestValidationError(safe))


api_router = APIRouter(prefix="/api")
MAX_PHOTO_BYTES = 3 * 1024 * 1024
MAX_PHOTO_TEXT = 4 * ((MAX_PHOTO_BYTES + 2) // 3) + 64
MAX_PHOTO_PIXELS = 16_000_000


def auth_limit_now():
    return datetime.now(timezone.utc)


async def consume_auth_limit(kind: str, key: str, limit: int, seconds: int):
    now = auth_limit_now()
    window = int(now.timestamp()) // seconds
    identity = hmac.new(get_jwt_secret().encode(), f"{kind}:{key}:{window}".encode(), hashlib.sha256).hexdigest()
    end = datetime.fromtimestamp((window + 1) * seconds, timezone.utc)
    try:
        # The unique _id plus conditional increment makes the quota shared and atomic.
        await db.auth_attempts.update_one({"_id": identity, "count": {"$lt": limit}},
            {"$inc": {"count": 1}, "$setOnInsert": {"expires_at": end}}, upsert=True)
    except DuplicateKeyError:
        retry = max(1, math.ceil((end - now).total_seconds()))
        raise HTTPException(429, f"Muitas tentativas. Aguarde {retry} segundos e tente novamente.",
                            headers={"Retry-After": str(retry), "Cache-Control": "no-store"})
    except PyMongoError:
        raise HTTPException(503, "Não foi possível verificar o limite de tentativas. Tente novamente em instantes.",
                            headers={"Retry-After": "30", "Cache-Control": "no-store"})


class AuthAttemptLimit:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope.get("method") == "POST":
            path = scope.get("path", "").rstrip("/")
            try:
                if path == "/api/auth/login":
                    await consume_auth_limit("login-service-minute", "service", 60, 60)
                elif path in {"/api/auth/register", "/api/public/volunteers/register"}:
                    await consume_auth_limit("register-service-minute", "service", 10, 60)
                    await consume_auth_limit("register-service-hour", "service", 30, 3600)
            except HTTPException as error:
                return await JSONResponse({"detail": error.detail}, status_code=error.status_code,
                                          headers=error.headers)(scope, receive, send)
        await self.app(scope, receive, send)


def normalize_photo(contents: bytes) -> str:
    if len(contents) > MAX_PHOTO_BYTES:
        raise HTTPException(413, "Foto muito grande. Máximo 3 MB.")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(contents)) as image:
                if image.format not in {"JPEG", "PNG", "WEBP"}:
                    raise HTTPException(422, "Use uma foto JPEG, PNG ou WebP.")
                if image.width * image.height > MAX_PHOTO_PIXELS:
                    raise HTTPException(422, "Foto com resolução excessiva. Máximo 16 megapixels.")
                if getattr(image, "is_animated", False):
                    raise HTTPException(422, "Use uma foto sem animação.")
                image.verify()
            with Image.open(BytesIO(contents)) as original:
                image = ImageOps.exif_transpose(original)
                image.thumbnail((1024, 1024))
                rgba = image.convert("RGBA")
                background = Image.new("RGB", rgba.size, "white")
                background.paste(rgba, mask=rgba.getchannel("A"))
                output = BytesIO()
                # Re-encoding excludes EXIF/GPS and the original file payload.
                background.save(output, format="JPEG", quality=85)
        return "data:image/jpeg;base64," + base64.b64encode(output.getvalue()).decode("ascii")
    except (UnidentifiedImageError, OSError, ValueError, SyntaxError,
            Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise HTTPException(422, "Arquivo inválido. Envie uma foto JPEG, PNG ou WebP válida.")


def normalize_inline_photo(value: Optional[str]) -> str:
    if not value:
        return ""
    if len(value) > MAX_PHOTO_TEXT:
        raise HTTPException(413, "Foto muito grande. Máximo 3 MB.")
    match = re.fullmatch(r"data:image/(?:jpeg|png|webp);base64,([A-Za-z0-9+/=]+)", value)
    if not match:
        raise HTTPException(422, "Envie uma foto JPEG, PNG ou WebP válida.")
    try:
        contents = base64.b64decode(match.group(1), validate=True)
    except (ValueError, binascii.Error):
        raise HTTPException(422, "Foto com codificação inválida.")
    return normalize_photo(contents)


class PhotoRequestLimit:
    """Limit incoming photo bodies, including multipart overhead, before parsing."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        path, method = scope.get("path", ""), scope.get("method")
        path = path.rstrip("/")
        small_auth = scope["type"] == "http" and method == "POST" and path in {"/api/auth/login", "/api/auth/register"}
        limited = (scope["type"] == "http" and (
            (method == "POST" and path in {"/api/public/volunteers/register", "/api/volunteers"})
            or (method == "PUT" and re.fullmatch(r"/api/volunteers/[^/]+", path))
            or (method == "POST" and re.fullmatch(r"/api/volunteers/[^/]+/upload-photo", path))))
        if not limited and not small_auth:
            return await self.app(scope, receive, send)
        total, limit, messages = 0, (16 * 1024 if small_auth else MAX_PHOTO_TEXT + 64 * 1024), []
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            if message["type"] == "http.request":
                total += len(message.get("body", b""))
                if total > limit:
                    detail = "Formulário de acesso muito grande." if small_auth else "Formulário muito grande. A foto deve ter no máximo 3 MB."
                    await JSONResponse({"detail": detail}, status_code=413, headers={"Cache-Control": "no-store"})(scope, receive, send)
                    return
                messages.append(message)
                if not message.get("more_body", False):
                    break
        iterator = iter(messages)

        async def bounded_receive():
            return next(iterator, None) or await receive()

        await self.app(scope, bounded_receive, send)
PUBLIC_SCHEDULE_STATUSES = ("Validado", "Fechada")
PARTICIPATION_SCHEDULE_STATUSES = ("Em Validação", "Validado", "Fechada")

JWT_ALGORITHM = "HS256"
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").lower() == "true"

def get_jwt_secret() -> str:
    secret = os.environ["JWT_SECRET"]
    if len(secret) < 32:
        raise RuntimeError("JWT_SECRET deve ter pelo menos 32 caracteres")
    return secret

def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode("utf-8"), salt)
    return hashed.decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))
    except ValueError:
        return False

def create_access_token(user_id: str, email: str, role: str, session_id: Optional[str] = None) -> str:
    payload = {"sub": user_id, "email": email, "role": role, "exp": datetime.now(timezone.utc) + timedelta(minutes=15), "type": "access"}
    if session_id:
        payload["sid"] = session_id
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: str, session_id: Optional[str] = None) -> str:
    payload = {"sub": user_id, "jti": session_id or str(uuid.uuid4()), "exp": datetime.now(timezone.utc) + timedelta(days=7), "type": "refresh"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def clear_auth_cookies(response):
    for name in ("access_token", "refresh_token"):
        response.delete_cookie(name, path="/", httponly=True, secure=COOKIE_SECURE, samesite="lax")

def check_auth_origin(request: Request):
    origin = request.headers.get("origin")
    allowed = {f"https://{request.url.netloc}", f"http://{request.url.netloc}"}
    allowed.update(value.strip() for value in os.environ.get("CORS_ORIGINS", "").split(",") if value.strip())
    if origin and origin not in allowed:
        raise HTTPException(status_code=403, detail="Origem não autorizada")

async def auth_user_response(user):
    return {"id": str(user["_id"]), "email": user["email"], "name": user.get("name", ""), "role": user.get("role", "Voluntário"), "access_approved": await account_has_access(user)}

async def start_auth_session(user, response):
    user_id, session_id = str(user["_id"]), str(uuid.uuid4())
    refresh_token = create_refresh_token(user_id, session_id)
    await db.auth_sessions.insert_one({"_id": session_id, "user_id": user_id,
        "token_hash": hashlib.sha256(refresh_token.encode()).hexdigest(),
        "expires_at": datetime.now(timezone.utc) + timedelta(days=7)})
    access_token = create_access_token(user_id, user["email"], user.get("role", "Voluntário"), session_id)
    response.set_cookie(key="access_token", value=access_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=900, path="/")
    response.set_cookie(key="refresh_token", value=refresh_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=604800, path="/")

async def account_has_access(user: dict) -> bool:
    if user.get("role") in ("Administrador", "Líder"):
        return True
    if user.get("role") != "Voluntário" or not user.get("volunteer_id"):
        return False
    return bool(await db.volunteers.find_one({"id": user["volunteer_id"], "status": "Ativo"}))

async def get_authenticated_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
        if payload.get("sid") and not await db.auth_sessions.find_one({"_id": payload["sid"], "user_id": payload["sub"], "expires_at": {"$gt": datetime.now(timezone.utc)}}):
            raise HTTPException(status_code=401, detail="Sessão encerrada")
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        user["_id"] = str(user["_id"])
        user["id"] = user["_id"]
        user.pop("password_hash", None)
        user["access_approved"] = await account_has_access(user)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except (InvalidId, KeyError, TypeError):
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(user: dict = Depends(get_authenticated_user)) -> dict:
    if not user["access_approved"]:
        raise HTTPException(status_code=403, detail="Acesso aguardando liberação da liderança", headers={"Cache-Control": "no-store"})
    return user

def schedule_visibility(user: dict) -> dict:
    if user.get("role") in ("Administrador", "Líder"):
        return {}
    return {"status": {"$in": ["Disponibilidade", "Em Validação", "Validado", "Fechada"]}}

async def require_visible_schedule(schedule_id: str, user: dict) -> dict:
    schedule = await db.schedules.find_one({"id": schedule_id, **schedule_visibility(user)}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Escala não encontrada")
    return schedule

async def require_admin(current_user: dict = Depends(get_current_user)) -> dict:
    if current_user.get("role") not in ("Administrador", "Líder"):
        raise HTTPException(status_code=403, detail="Acesso restrito à liderança")
    return current_user

def validate_new_password(value):
    if len(value) < 15 or value.isspace():
        raise ValueError("Use uma senha com pelo menos 15 caracteres. Você pode usar uma frase com espaços.")
    if len(value.encode("utf-8")) > 72:
        raise ValueError("A senha deve ter no máximo 72 bytes. Acentos e emojis podem ocupar mais de um byte.")
    if "\x00" in value:
        raise ValueError("A senha não pode conter caractere nulo.")
    return value


NewPassword = Annotated[str, AfterValidator(validate_new_password)]


class RegisterRequest(BaseModel):
    email: EmailStr
    password: NewPassword
    name: str
    role: Optional[str] = "Voluntário"

class LoginRequest(BaseModel):
    email: EmailStr
    # Do not apply the new-registration minimum to existing accounts.
    password: str = Field(max_length=1024)

def local_today():
    return datetime.now(gettz("America/Sao_Paulo")).date()

def validate_calendar_date(value):
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value):
        raise ValueError("Informe a data no formato AAAA-MM-DD")
    try:
        date.fromisoformat(value)
    except ValueError:
        raise ValueError("Informe uma data válida no calendário")
    return value

def validate_birth_date(value):
    validate_calendar_date(value)
    if date.fromisoformat(value) > local_today():
        raise ValueError("A data de nascimento não pode ser futura")
    return value

def validate_clock_time(value):
    if not re.fullmatch(r"([01][0-9]|2[0-3]):[0-5][0-9]", value):
        raise ValueError("Informe o horário entre 00:00 e 23:59, no formato HH:mm")
    return value

def validate_year_month(value):
    if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", value) or value.startswith("0000-"):
        raise ValueError("Informe o mês no formato AAAA-MM")
    return value

def age_for_birth_date(value):
    born, today = date.fromisoformat(value), local_today()
    return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

CalendarDate = Annotated[str, AfterValidator(validate_calendar_date)]
BirthDate = Annotated[str, AfterValidator(validate_birth_date)]
ClockTime = Annotated[str, AfterValidator(validate_clock_time)]
YearMonth = Annotated[str, AfterValidator(validate_year_month)]
VolunteerStatus = Literal["Pendente", "Ativo", "Inativo", "Afastado"]
VolunteerPhase = Literal["Em Teste", "Efetivado"]
ScheduleStatus = Literal["Disponibilidade", "Rascunho", "Em Validação", "Validado", "Fechada"]
Ministry = Literal["Red Music", "Pulse Music"]
Ministries = Annotated[List[Ministry], Field(min_length=1, max_length=2)]

class VolunteerCreate(BaseModel):
    name: str
    birth_date: BirthDate
    email: EmailStr
    phone: str
    photo_url: Optional[str] = ""
    instruments: List[str] = []
    functions: List[str] = []
    phase: VolunteerPhase = "Em Teste"
    status: VolunteerStatus = "Ativo"
    tags: List[str] = []
    ministries: Ministries = ["Red Music"]

class VolunteerUpdate(BaseModel):
    name: Optional[str] = None
    birth_date: Optional[BirthDate] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    photo_url: Optional[str] = None
    instruments: Optional[List[str]] = None
    functions: Optional[List[str]] = None
    phase: Optional[VolunteerPhase] = None
    status: Optional[VolunteerStatus] = None
    tags: Optional[List[str]] = None
    ministries: Optional[Ministries] = None

class UnavailabilityDate(BaseModel):
    date: CalendarDate
    reason: Optional[str] = ""

class SongCreate(BaseModel):
    name: str
    artist: Optional[str] = ""
    original_key: str
    bpm: Optional[int] = None
    tempo: str = "4/4"
    tags: List[str] = []
    link_original: Optional[str] = ""
    link_pt_br: Optional[str] = ""
    link_intro_arrangement: Optional[str] = ""
    sheet_music_url: Optional[str] = ""
    notes: Optional[str] = ""

class SongUpdate(BaseModel):
    name: Optional[str] = None
    artist: Optional[str] = None
    original_key: Optional[str] = None
    bpm: Optional[int] = None
    tempo: Optional[str] = None
    tags: Optional[List[str]] = None
    link_original: Optional[str] = None
    link_pt_br: Optional[str] = None
    link_intro_arrangement: Optional[str] = None
    sheet_music_url: Optional[str] = None
    notes: Optional[str] = None

class ScheduleCreate(BaseModel):
    name: str
    date: CalendarDate
    time: ClockTime
    event_type: str = "Domingo"
    ministry: str = "Red Music"
    has_choir: bool = False
    has_orchestra: bool = False
    status: ScheduleStatus = "Rascunho"
    location: str = Field(default="", max_length=100)

class ScheduleBatchCreate(BaseModel):
    dates: List[CalendarDate] = Field(min_length=1)
    time: ClockTime = "19:00"
    event_type: str = "Domingo"
    ministry: str = "Red Music"
    name_prefix: str = "Culto"
    has_choir: bool = False
    has_orchestra: bool = False

class AvailabilityMark(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schedule_id: Optional[str] = None
    available: StrictBool

class ScheduleUpdate(BaseModel):
    name: Optional[str] = None
    date: Optional[CalendarDate] = None
    time: Optional[ClockTime] = None
    event_type: Optional[str] = None
    ministry: Optional[str] = None
    has_choir: Optional[bool] = None
    has_orchestra: Optional[bool] = None
    status: Optional[ScheduleStatus] = None
    location: Optional[str] = Field(default=None, max_length=100)

SCHEDULE_FUNCTIONS = ("Vocal", "Backing Vocal", "Violão", "Guitarra", "Teclado", "Baixo", "Bateria", "Percussão", "Técnico de Som", "Técnico de Imagem")

def schedule_function_key(value: str):
    if not isinstance(value, str):
        return ""
    plain = "".join(character for character in unicodedata.normalize("NFKD", value) if not unicodedata.combining(character))
    return " ".join(plain.casefold().split())

class ScheduleMemberAdd(BaseModel):
    volunteer_id: str
    function: str = Field(min_length=1, max_length=80)
    exception_reason: str = Field(default="", max_length=500)

    @field_validator("function")
    @classmethod
    def canonical_function(cls, value):
        for function in SCHEDULE_FUNCTIONS:
            if schedule_function_key(value) == schedule_function_key(function):
                return function
        raise ValueError("Selecione uma função válida para a escala")

class ScheduleMemberUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirmation_status: Literal["Pendente", "Confirmado", "Preciso de Substituto"]

class VolunteerAccountLink(BaseModel):
    email: EmailStr

class SetlistSongAdd(BaseModel):
    song_id: str
    key_for_this_event: Optional[str] = ""
    main_vocal_volunteer_id: Optional[str] = ""
    order: int

class NotificationRequest(BaseModel):
    recipient_email: Optional[EmailStr] = None
    recipient_phone: Optional[str] = None
    subject: str
    message: str
    channel: str

class ChatMessageCreate(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    to_user_id: str = Field(min_length=1, max_length=24)
    message: str = Field(min_length=1, max_length=2000)

@api_router.post("/auth/register")
async def register(request: RegisterRequest, response: Response):
    email_lower = request.email.lower()
    await consume_auth_limit("register-email", email_lower, 5, 900)
    existing = await db.users.find_one({"email": email_lower})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # SEGURANÇA: Bloqueia autocadastro como Administrador via endpoint público
    safe_role = "Voluntário"
    
    hashed = await asyncio.to_thread(hash_password, request.password)
    user_doc = {
        "email": email_lower,
        "password_hash": hashed,
        "name": request.name,
        "role": safe_role,
        "created_at": datetime.now(timezone.utc)
    }
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    await start_auth_session(user_doc, response)
    
    return {"id": user_id, "email": email_lower, "name": request.name, "role": safe_role, "access_approved": False}

class PublicVolunteerRegister(BaseModel):
    name: str
    birth_date: BirthDate
    email: EmailStr
    phone: str
    photo_url: Optional[str] = ""
    instruments: List[str] = []
    password: NewPassword
    ministries: Ministries = ["Red Music"]

@api_router.post("/public/volunteers/register")
async def public_volunteer_register(data: PublicVolunteerRegister):
    await consume_auth_limit("register-email", data.email.lower(), 5, 900)
    photo_url = await asyncio.to_thread(normalize_inline_photo, data.photo_url)
    email_lower = data.email.lower()
    existing_user = await db.users.find_one({"email": email_lower})
    if existing_user:
        raise HTTPException(status_code=400, detail="E-mail já cadastrado")
    
    age = age_for_birth_date(data.birth_date)
    
    hashed = await asyncio.to_thread(hash_password, data.password)
    # Cria voluntário
    vol_doc = {
        "id": str(uuid.uuid4()),
        "name": data.name,
        "birth_date": data.birth_date,
        "email": email_lower,
        "phone": data.phone,
        "photo_url": photo_url,
        "instruments": data.instruments,
        "ministries": list(dict.fromkeys(data.ministries)),
        "functions": [],
        "phase": "Em Teste",
        "status": "Pendente",
        "tags": [],
        "age": age,
        "unavailability_dates": [],
        "created_at": datetime.now(timezone.utc)
    }
    vol_doc["registration_source"] = "public"
    async def operation(session):
        if await db.users.find_one({"email": email_lower}, session=session):
            raise HTTPException(400, "E-mail já cadastrado")
        if await db.volunteers.find_one({"email": {"$regex": "^" + re.escape(email_lower) + "$", "$options": "i"}}, session=session):
            raise HTTPException(409, "Já existe um perfil com este e-mail. Procure a liderança para conferir o cadastro existente.")
        await db.volunteers.insert_one(dict(vol_doc), session=session)
        try:
            await db.users.insert_one({"email": email_lower, "password_hash": hashed, "name": data.name,
                "role": "Voluntário", "volunteer_id": vol_doc["id"], "created_at": datetime.now(timezone.utc)}, session=session)
        except DuplicateKeyError:
            raise HTTPException(400, "E-mail já cadastrado")
    await run_assignment_transaction(operation)
    
    return {"message": "Cadastro realizado com sucesso! Aguarde aprovação da liderança.", "volunteer_id": vol_doc["id"]}

@api_router.get("/public/monthly/{ministry}/{year_month}")
async def get_public_monthly(ministry: str, year_month: YearMonth, response: Response):
    """Retorna apenas escalas publicadas do ministério no mês."""
    response.headers["Cache-Control"] = "no-store"
    schedules = await db.schedules.find({
        "ministry": ministry,
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES},
        "date": {"$regex": f"^{year_month}-"}
    }, {"_id": 0}).to_list(1000)
    
    if not schedules:
        return {"ministry": ministry, "year_month": year_month, "schedules": []}
    
    schedules.sort(key=lambda s: s.get("date", ""))
    song_usage = await get_song_usage()
    
    for schedule in schedules:
        members = await db.schedule_members.find({"schedule_id": schedule["id"]}, {"_id": 0}).to_list(1000)
        schedule["members"] = [safe_member(member) for member in members]
        
        setlist = await db.setlists.find_one({"schedule_id": schedule["id"]}, {"_id": 0})
        schedule["setlist"] = setlist.get("songs", []) if setlist else []
        
        # Enriquecer setlist
        for entry in schedule["setlist"]:
            song = await db.songs.find_one({"id": entry.get("song_id")}, {"_id": 0})
            if song:
                entry["song_full"] = with_song_usage(song, song_usage)
    
    return {"ministry": ministry, "year_month": year_month, "schedules": schedules}

@api_router.post("/auth/login")
async def login(request: LoginRequest, response: Response):
    email_lower = request.email.lower()
    await consume_auth_limit("login-email", email_lower, 10, 900)
    user = await db.users.find_one({"email": email_lower})
    # A dummy bcrypt check avoids a cheap timing shortcut for unknown accounts.
    dummy_hash = "$2b$12$0nY6fJ42b6ybsYunsnzlnu/Yz3Vagf8l0BWgM9EPmGQzOhpx/lCdW"
    valid = await asyncio.to_thread(verify_password, request.password, user["password_hash"] if user else dummy_hash)
    if not user or not valid:
        raise HTTPException(status_code=401, detail="E-mail ou senha inválidos")
    
    user_id = str(user["_id"])
    await start_auth_session(user, response)
    
    return {"id": user_id, "email": email_lower, "name": user.get("name", ""), "role": user.get("role", "Voluntário"), "access_approved": await account_has_access(user)}

@api_router.post("/auth/refresh")
async def refresh_session(request: Request, response: Response):
    check_auth_origin(request)
    token = request.cookies.get("refresh_token", "")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM], options={"require": ["sub", "exp", "jti"]})
        if payload.get("type") != "refresh":
            raise ValueError("Wrong token type")
        session = await db.auth_sessions.find_one({"_id": payload["jti"], "user_id": payload["sub"],
            "token_hash": hashlib.sha256(token.encode()).hexdigest(), "expires_at": {"$gt": datetime.now(timezone.utc)}})
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])}) if session else None
        if not user:
            raise ValueError("Session unavailable")
    except (jwt.InvalidTokenError, InvalidId, ValueError, TypeError):
        denied = JSONResponse(status_code=401, content={"detail": "Sessão expirada. Entre novamente."})
        clear_auth_cookies(denied)
        return denied
    access_token = create_access_token(str(user["_id"]), user["email"], user.get("role", "Voluntário"), session["_id"])
    response.set_cookie(key="access_token", value=access_token, httponly=True, secure=COOKIE_SECURE, samesite="lax", max_age=900, path="/")
    return await auth_user_response(user)

@api_router.post("/auth/logout")
async def logout(request: Request, response: Response):
    check_auth_origin(request)
    for cookie, kind, key in [("refresh_token", "refresh", "jti"), ("access_token", "access", "sid")]:
        try:
            payload = jwt.decode(request.cookies.get(cookie, ""), get_jwt_secret(), algorithms=[JWT_ALGORITHM], options={"verify_exp": False})
            if payload.get("type") == kind and payload.get(key):
                await db.auth_sessions.delete_one({"_id": payload[key], "user_id": payload.get("sub")})
        except jwt.InvalidTokenError:
            pass
    clear_auth_cookies(response)
    return {"message": "Logged out successfully"}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_authenticated_user)):
    return current_user

@api_router.post("/volunteers")
async def create_volunteer(volunteer: VolunteerCreate, current_user: dict = Depends(require_admin)):
    age = age_for_birth_date(volunteer.birth_date)
    
    vol_doc = volunteer.model_dump()
    vol_doc["photo_url"] = await asyncio.to_thread(normalize_inline_photo, volunteer.photo_url)
    vol_doc["id"] = str(uuid.uuid4())
    vol_doc["age"] = age
    vol_doc["unavailability_dates"] = []
    vol_doc["created_at"] = datetime.now(timezone.utc)
    
    result = await db.volunteers.insert_one(vol_doc)
    vol_doc.pop("_id", None)
    return vol_doc

@api_router.get("/volunteers")
async def get_volunteers(current_user: dict = Depends(require_admin)):
    volunteers = await db.volunteers.find({"archived": {"$ne": True}}).to_list(1000)
    result = []
    for vol in volunteers:
        vol_id = vol.get("id")
        if not vol_id:
            vol_id = str(vol.get("_id", uuid.uuid4()))
            await db.volunteers.update_one({"_id": vol["_id"]}, {"$set": {"id": vol_id}})
            vol["id"] = vol_id
        vol.pop("_id", None)
        result.append(vol)
    return result

@api_router.get("/volunteers/{volunteer_id}")
async def get_volunteer(volunteer_id: str, current_user: dict = Depends(require_admin)):
    volunteer = await db.volunteers.find_one({"id": volunteer_id}, {"_id": 0})
    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")
    return volunteer

@api_router.put("/volunteers/{volunteer_id}")
async def update_volunteer(volunteer_id: str, updates: VolunteerUpdate, current_user: dict = Depends(require_admin)):
    if await db.volunteers.find_one({"id": volunteer_id, "archived": True}):
        raise HTTPException(404, "Voluntário arquivado")
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    if update_data.get("status") == "Ativo":
        existing = await db.volunteers.find_one({"id": volunteer_id})
        if existing and existing.get("status") == "Pendente" and existing.get("registration_source") == "public":
            raise HTTPException(409, "Use Aprovar cadastro e selecione Em Teste ou Efetivado.")
    if "photo_url" in update_data:
        existing = await db.volunteers.find_one({"id": volunteer_id})
        if not existing:
            raise HTTPException(404, "Voluntário não encontrado")
        # Preserve unchanged legacy photos when editing unrelated profile fields.
        if update_data["photo_url"] == existing.get("photo_url"):
            update_data.pop("photo_url")
        else:
            update_data["photo_url"] = await asyncio.to_thread(normalize_inline_photo, update_data["photo_url"])
    
    if "birth_date" in update_data:
        update_data["age"] = age_for_birth_date(update_data["birth_date"])
    
    if update_data:
        await db.volunteers.update_one({"id": volunteer_id}, {"$set": update_data})
    
    updated = await db.volunteers.find_one({"id": volunteer_id}, {"_id": 0})
    return updated

class VolunteerApproval(BaseModel):
    phase: VolunteerPhase

@api_router.post("/volunteers/{volunteer_id}/approve")
async def approve_volunteer(volunteer_id: str, data: VolunteerApproval, current_user: dict = Depends(require_admin)):
    async def operation(session):
        person = await db.volunteers.find_one({"id": volunteer_id}, session=session)
        if not person:
            raise HTTPException(404, "Voluntário não encontrado")
        if person.get("status") != "Pendente":
            raise HTTPException(409, "Este cadastro não está pendente. Atualize a página.")
        account = await db.users.find_one({"volunteer_id": volunteer_id, "role": "Voluntário"}, session=session)
        if not account:
            raise HTTPException(409, "Este cadastro antigo ainda não possui conta vinculada. Confira o vínculo em Opções de conta.")
        # Serialize with link/unlink operations and verify the exact account, never infer from email.
        locked = await db.users.update_one({"_id": account["_id"], "volunteer_id": volunteer_id, "role": "Voluntário"}, {"$inc": {"_approval_revision": 1}}, session=session)
        if not locked.matched_count:
            raise HTTPException(409, "A conta foi alterada. Atualize a página.")
        result = await db.volunteers.update_one({"id": volunteer_id, "status": "Pendente"}, {"$set": {
            "status": "Ativo", "phase": data.phase, "approved_at": datetime.now(timezone.utc), "approved_by": current_user["id"]}}, session=session)
        if not result.matched_count:
            raise HTTPException(409, "O cadastro já foi alterado. Atualize a página.")
        return {"status": "Ativo", "phase": data.phase}
    return await run_assignment_transaction(operation)

@api_router.get("/volunteers/{volunteer_id}/account")
async def get_volunteer_account(volunteer_id: str, current_user: dict = Depends(require_admin)):
    account = await db.users.find_one({"volunteer_id": volunteer_id}, {"_id": 0, "email": 1})
    return {"email": account["email"] if account else None}

@api_router.put("/volunteers/{volunteer_id}/account")
async def link_volunteer_account(volunteer_id: str, data: VolunteerAccountLink, current_user: dict = Depends(require_admin)):
    if not await db.volunteers.find_one({"id": volunteer_id}):
        raise HTTPException(status_code=404, detail="Voluntário não encontrado")
    account = await db.users.find_one({"email": data.email.lower()})
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada. O voluntário precisa criar sua conta primeiro.")
    if account.get("volunteer_id") not in (None, volunteer_id):
        raise HTTPException(status_code=409, detail="Esta conta já está vinculada a outro voluntário")
    try:
        result = await db.users.update_one(
            {"_id": account["_id"], "$or": [{"volunteer_id": {"$exists": False}}, {"volunteer_id": volunteer_id}]},
            {"$set": {"volunteer_id": volunteer_id}},
        )
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Este voluntário já possui uma conta vinculada")
    if result.matched_count == 0:
        raise HTTPException(status_code=409, detail="O vínculo foi alterado. Atualize a página e tente novamente.")
    await db.volunteers.update_one({"id": volunteer_id, "status": "Pendente", "registration_source": {"$ne": "public"}}, {"$set": {"status": "Ativo"}})
    return {"email": account["email"]}

@api_router.delete("/volunteers/{volunteer_id}/account")
async def unlink_volunteer_account(volunteer_id: str, current_user: dict = Depends(require_admin)):
    await db.users.update_one({"volunteer_id": volunteer_id}, {"$unset": {"volunteer_id": ""}})
    return {"email": None}

@api_router.delete("/volunteers/{volunteer_id}")
async def delete_volunteer(volunteer_id: str, current_user: dict = Depends(require_admin)):
    async def operation(session):
        result = await db.volunteers.update_one({"id": volunteer_id, "archived": {"$ne": True}}, {"$set": {"archived": True, "status": "Inativo", "archived_at": datetime.now(timezone.utc)}, "$inc": {"_assignment_revision": 1}}, session=session)
        if not result.matched_count:
            raise HTTPException(404, "Voluntário não encontrado")
        await db.users.update_one({"volunteer_id": volunteer_id}, {"$unset": {"volunteer_id": ""}}, session=session)
        return {"message": "Voluntário arquivado. Histórico preservado e acesso bloqueado."}
    return await run_assignment_transaction(operation)

@api_router.post("/volunteers/{volunteer_id}/unavailability")
async def add_unavailability(volunteer_id: str, unavail: UnavailabilityDate, current_user: dict = Depends(require_admin)):
    await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$push": {"unavailability_dates": unavail.model_dump()}}
    )
    return {"message": "Unavailability added"}

@api_router.delete("/volunteers/{volunteer_id}/unavailability/{date}")
async def remove_unavailability(volunteer_id: str, date: str, current_user: dict = Depends(require_admin)):
    await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$pull": {"unavailability_dates": {"date": date}}}
    )
    return {"message": "Unavailability removed"}

@api_router.post("/songs")
async def create_song(song: SongCreate, current_user: dict = Depends(require_admin)):
    song_doc = song.model_dump()
    song_doc["id"] = str(uuid.uuid4())
    song_doc["last_played_date"] = None
    song_doc["play_count"] = 0
    song_doc["created_at"] = datetime.now(timezone.utc)
    
    await db.songs.insert_one(song_doc)
    song_doc.pop("_id", None)
    return song_doc

async def get_song_usage():
    ministry_timezone = gettz("America/Sao_Paulo")
    if ministry_timezone is None:
        raise RuntimeError("Fuso horário do ministério indisponível")
    today = datetime.now(timezone.utc).astimezone(ministry_timezone).date().isoformat()
    schedules = await db.schedules.find({
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES}, "date": {"$lt": today},
    }, {"_id": 0, "id": 1, "date": 1}).to_list(None)
    event_dates = {}
    for schedule in schedules:
        try:
            event_date = date.fromisoformat(schedule.get("date", ""))
        except (TypeError, ValueError):
            continue
        if schedule.get("id") and event_date.isoformat() == schedule["date"]:
            event_dates[schedule["id"]] = schedule["date"]
    if not event_dates:
        return {}
    setlists = await db.setlists.find({"schedule_id": {"$in": list(event_dates)}}, {
        "_id": 0, "schedule_id": 1, "songs.song_id": 1,
    }).to_list(None)
    used_in = {}
    for setlist in setlists:
        for entry in setlist.get("songs", []):
            if entry.get("song_id"):
                used_in.setdefault(entry["song_id"], set()).add(setlist["schedule_id"])
    return {song_id: {"play_count": len(events), "last_played_date": max(event_dates[event] for event in events)}
            for song_id, events in used_in.items()}

def with_song_usage(song: dict, usage: dict):
    return {**song, **usage.get(song.get("id"), {"play_count": 0, "last_played_date": None})}

@api_router.get("/songs")
async def get_songs(current_user: dict = Depends(get_current_user)):
    songs = await db.songs.find({"archived": {"$ne": True}}, {"_id": 0}).to_list(1000)
    usage = await get_song_usage()
    return [with_song_usage(song, usage) for song in songs]

@api_router.get("/songs/{song_id}")
async def get_song(song_id: str, current_user: dict = Depends(get_current_user)):
    song = await db.songs.find_one({"id": song_id}, {"_id": 0})
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")
    return with_song_usage(song, await get_song_usage())

@api_router.put("/songs/{song_id}")
async def update_song(song_id: str, updates: SongUpdate, current_user: dict = Depends(require_admin)):
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    if update_data:
        await db.songs.update_one({"id": song_id}, {"$set": update_data})
    updated = await db.songs.find_one({"id": song_id}, {"_id": 0})
    if not updated:
        raise HTTPException(status_code=404, detail="Song not found")
    return with_song_usage(updated, await get_song_usage())

@api_router.delete("/songs/{song_id}")
async def delete_song(song_id: str, current_user: dict = Depends(require_admin)):
    result = await db.songs.update_one({"id": song_id, "archived": {"$ne": True}}, {"$set": {"archived": True, "archived_at": datetime.now(timezone.utc)}})
    if not result.matched_count:
        raise HTTPException(404, "Música não encontrada")
    return {"message": "Música arquivada. Repertórios anteriores preservados."}

@api_router.post("/schedules")
async def create_schedule(schedule: ScheduleCreate, current_user: dict = Depends(require_admin)):
    schedule_doc = schedule.model_dump()
    schedule_doc["validation_required"] = False
    schedule_doc["id"] = str(uuid.uuid4())
    schedule_doc["share_token"] = str(uuid.uuid4())
    schedule_doc["created_at"] = datetime.now(timezone.utc)
    schedule_doc["created_by"] = current_user["_id"]
    schedule_doc["team_slots"] = {
        "Vocal": 6, "Violão": 2, "Guitarra": 2, "Teclado": 2,
        "Baixo": 1, "Bateria": 1, "Percussão": 1
    }
    
    await db.schedules.insert_one(schedule_doc)
    schedule_doc.pop("_id", None)
    return schedule_doc

@api_router.post("/schedules/batch")
async def create_schedules_batch(batch: ScheduleBatchCreate, current_user: dict = Depends(require_admin)):
    today = local_today()
    created = []
    skipped = []
    
    for date_str in batch.dates:
        date_obj = date.fromisoformat(date_str)
        
        if date_obj < today:
            skipped.append({"date": date_str, "reason": "past_date"})
            continue
        
        weekday_names_pt = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
        weekday = weekday_names_pt[date_obj.weekday()]
        
        schedule_doc = {
            "id": str(uuid.uuid4()),
            "share_token": str(uuid.uuid4()),
            "name": f"{batch.name_prefix} - {date_obj.strftime('%d/%m/%Y')}",
            "date": date_obj.isoformat(),
            "time": batch.time,
            "event_type": batch.event_type,
            "ministry": batch.ministry,
            "has_choir": batch.has_choir,
            "has_orchestra": batch.has_orchestra,
            "status": "Rascunho",
            "validation_required": False,
            "created_at": datetime.now(timezone.utc),
            "created_by": current_user["_id"],
            "team_slots": {
                "Vocal": 6, "Violão": 2, "Guitarra": 2, "Teclado": 2,
                "Baixo": 1, "Bateria": 1, "Percussão": 1
            }
        }
        await db.schedules.insert_one(schedule_doc)
        schedule_doc.pop("_id", None)
        created.append(schedule_doc)
    
    return {"created": created, "skipped": skipped, "total_created": len(created)}

@api_router.post("/schedules/{schedule_id}/availability")
async def mark_availability(schedule_id: str, mark: AvailabilityMark, current_user: dict = Depends(get_current_user)):
    target = await require_visible_schedule(schedule_id, current_user)
    if mark.schedule_id is not None and mark.schedule_id != schedule_id:
        raise HTTPException(status_code=422, detail="A escala informada não corresponde à URL")
    if target.get("plan_id"):
        return await save_month_availability(target["plan_id"], MonthlyAvailability(responses=[DailyAnswer(date=target["date"], available=mark.available)]), current_user)
    
    if mark.schedule_id is not None and mark.schedule_id != schedule_id:
        raise HTTPException(status_code=422, detail="A escala informada não corresponde à URL")
    volunteer = await db.volunteers.find_one({"id": current_user.get("volunteer_id"), "status": "Ativo"}, {"_id": 0}) if current_user.get("volunteer_id") else None
    if not volunteer:
        raise HTTPException(status_code=403, detail="É necessário um vínculo autorizado com um voluntário ativo")
    
    await db.availability.update_one(
        {"schedule_id": schedule_id, "volunteer_id": volunteer["id"]},
        {"$set": {
            "schedule_id": schedule_id,
            "volunteer_id": volunteer["id"],
            "volunteer_name": volunteer["name"],
            "available": mark.available,
            "marked_at": datetime.now(timezone.utc)
        }},
        upsert=True
    )
    return {"message": "Disponibilidade registrada", "available": mark.available}

async def get_monthly_participation_counts(year_month: str, volunteer_id: Optional[str] = None):
    """Count each person's distinct assigned schedules, rather than member rows."""
    if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", year_month):
        return {}
    schedules = await db.schedules.find({
        "date": {"$regex": f"^{year_month}-"},
        "status": {"$in": PARTICIPATION_SCHEDULE_STATUSES},
    }, {"_id": 0, "id": 1}).to_list(None)
    schedule_ids = [schedule["id"] for schedule in schedules if schedule.get("id")]
    if not schedule_ids:
        return {}
    member_query = {"schedule_id": {"$in": schedule_ids}}
    if volunteer_id is not None:
        member_query["volunteer_id"] = volunteer_id
    members = await db.schedule_members.find(
        member_query, {"_id": 0, "volunteer_id": 1, "schedule_id": 1}
    ).to_list(None)
    participation = {}
    for member in members:
        if member.get("volunteer_id"):
            participation.setdefault(member["volunteer_id"], set()).add(member["schedule_id"])
    return {person: len(assigned_schedules) for person, assigned_schedules in participation.items()}

@api_router.get("/schedules/{schedule_id}/available-volunteers")
async def get_available_volunteers_for_schedule(schedule_id: str, include_exceptions: bool = False, current_user: dict = Depends(require_admin)):
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0})
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")
    if schedule.get("plan_id"):
        return await monthly_candidates(schedule, include_exceptions)
    
    schedule_date = schedule.get("date", "")
    
    availabilities = await db.availability.find({"schedule_id": schedule_id}, {"_id": 0}).to_list(None)
    responses = {a["volunteer_id"]: a.get("available") for a in availabilities}
    
    all_volunteers = await db.volunteers.find({"status": "Ativo"}).to_list(1000)
    monthly_counts = await get_monthly_participation_counts(schedule_date[:7])
    
    result = []
    for vol in all_volunteers:
        # Backfill: ensure 'id' field exists (legacy documents may only have _id)
        vol_id = vol.get("id")
        if not vol_id:
            vol_id = str(vol.get("_id", uuid.uuid4()))
            await db.volunteers.update_one({"_id": vol["_id"]}, {"$set": {"id": vol_id}})
            vol["id"] = vol_id
        vol.pop("_id", None)
        
        is_unavailable = any(u.get("date") == schedule_date for u in vol.get("unavailability_dates", []))
        if is_unavailable:
            continue
        
        if responses.get(vol_id) is False:
            continue
        
        monthly_count = monthly_counts.get(vol_id, 0)
        
        vol["monthly_schedule_count"] = monthly_count
        vol["is_exhausted"] = monthly_count >= 2
        vol["explicitly_available"] = responses.get(vol_id) is True
        vol["availability_status"] = "Disponível" if responses.get(vol_id) is True else "Sem resposta"
        result.append(vol)
    
    return result

@api_router.get("/volunteers/{volunteer_id}/monthly-count/{year_month}")
async def get_volunteer_monthly_count(volunteer_id: str, year_month: YearMonth, current_user: dict = Depends(require_admin)):
    if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", year_month):
        raise HTTPException(status_code=422, detail="Informe o mês no formato AAAA-MM")
    counts = await get_monthly_participation_counts(year_month, volunteer_id)
    count = counts.get(volunteer_id, 0)
    return {"volunteer_id": volunteer_id, "year_month": year_month, "count": count}

@api_router.get("/volunteer-dashboard")
async def volunteer_dashboard(year_month: YearMonth, response: Response, user: dict = Depends(get_current_user)):
    response.headers["Cache-Control"] = "no-store"
    volunteer = await own_active_volunteer(user)
    schedules = await db.schedules.find({"date": {"$regex": "^" + year_month + "-"}, "status": {"$in": ["Em Validação", "Validado", "Fechada"]}}, {"_id": 0}).sort("date", 1).to_list(None)
    assignments = await db.schedule_members.find({"schedule_id": {"$in": [item["id"] for item in schedules]}, "volunteer_id": volunteer["id"]}, {"_id": 0, "schedule_id": 1, "function": 1}).to_list(None)
    answers = await db.daily_availability.find({"volunteer_id": volunteer["id"], "date": {"$regex": "^" + year_month + "-"}}, {"_id": 0}).to_list(None)
    available = {item["date"]: item["available"] for item in answers}
    return [{**{key: item.get(key) for key in ("id", "name", "date", "location", "ministry", "band_leader_name")}, "functions": [member["function"] for member in assignments if member["schedule_id"] == item["id"]], "available": available.get(item["date"])} for item in schedules]


@api_router.get("/schedules")
async def get_schedules(current_user: dict = Depends(get_current_user)):
    schedules = await db.schedules.find(schedule_visibility(current_user), {"_id": 0}).to_list(1000)
    # Backfill share_token para escalas antigas
    for s in schedules:
        if not s.get("share_token"):
            token = str(uuid.uuid4())
            await db.schedules.update_one({"id": s["id"]}, {"$set": {"share_token": token}})
            s["share_token"] = token
        if not s.get("ministry"):
            await db.schedules.update_one({"id": s["id"]}, {"$set": {"ministry": "Red Music"}})
            s["ministry"] = "Red Music"
    return schedules

@api_router.get("/public/schedules/{share_token}")
async def get_public_schedule(share_token: str, response: Response):
    response.headers["Cache-Control"] = "no-store"
    schedule = await db.schedules.find_one({
        "share_token": share_token,
        "status": {"$in": PUBLIC_SCHEDULE_STATUSES},
    }, {"_id": 0})
    if not schedule:
        raise HTTPException(
            status_code=404,
            detail="Escala não encontrada ou indisponível para visualização pública",
            headers={"Cache-Control": "no-store"},
        )
    
    members = await db.schedule_members.find({"schedule_id": schedule["id"]}, {"_id": 0}).to_list(1000)
    schedule["members"] = [safe_member(member) for member in members]
    
    setlist = await db.setlists.find_one({"schedule_id": schedule["id"]}, {"_id": 0})
    schedule["setlist"] = setlist.get("songs", []) if setlist else []
    
    # Enriquecer setlist com dados completos das músicas
    song_usage = await get_song_usage()
    for entry in schedule["setlist"]:
        song = await db.songs.find_one({"id": entry.get("song_id")}, {"_id": 0})
        if song:
            entry["song_full"] = with_song_usage(song, song_usage)
    
    return schedule

@api_router.get("/schedules/{schedule_id}")
async def get_schedule(schedule_id: str, current_user: dict = Depends(get_current_user)):
    schedule = await require_visible_schedule(schedule_id, current_user)
    own_response = await db.availability.find_one({"schedule_id": schedule_id, "volunteer_id": current_user["volunteer_id"]}, {"_id": 0, "available": 1}) if current_user.get("volunteer_id") else None
    schedule["own_availability"] = own_response.get("available") if own_response else None
    
    members = await db.schedule_members.find({"schedule_id": schedule_id}, {"_id": 0}).to_list(1000)
    own_volunteer = await db.volunteers.find_one({"id": current_user.get("volunteer_id"), "status": "Ativo"})
    for member in members:
        member["can_confirm"] = bool(
            current_user.get("role") == "Voluntário" and own_volunteer
            and member["volunteer_id"] == own_volunteer["id"]
            and schedule.get("validation_required") is not False and not schedule.get("plan_id")
        )
    schedule["members"] = [safe_member(member, current_user) for member in members]
    
    setlist = await db.setlists.find_one({"schedule_id": schedule_id}, {"_id": 0})
    schedule["setlist"] = setlist.get("songs", []) if setlist else []
    
    return schedule

@api_router.put("/schedules/{schedule_id}")
async def update_schedule(schedule_id: str, updates: ScheduleUpdate, current_user: dict = Depends(require_admin)):
    update_data = {k: v for k, v in updates.model_dump().items() if v is not None}
    async def operation(session):
        schedule = await db.schedules.find_one({"id": schedule_id}, session=session)
        if not schedule:
            raise HTTPException(404, "Escala não encontrada")
        if schedule.get("plan_id"):
            raise HTTPException(409, "Altere as equipes e as etapas pelo planejamento mensal")
        await db.schedules.update_one({"id": schedule_id}, {"$inc": {"_assignment_revision": 1}}, session=session)
        if update_data.get("date") and update_data["date"] != schedule.get("date"):
            members = await db.schedule_members.find({"schedule_id": schedule_id}, session=session).to_list(None)
            for vid in sorted({member["volunteer_id"] for member in members}):
                await db.volunteers.update_one({"id": vid}, {"$inc": {"_assignment_revision": 1}}, session=session)
                await ensure_free_day(vid, update_data["date"], schedule_id, session)
        if update_data:
            await db.schedules.update_one({"id": schedule_id}, {"$set": update_data}, session=session)
        return await db.schedules.find_one({"id": schedule_id}, {"_id": 0}, session=session)
    return await run_assignment_transaction(operation)

@api_router.delete("/schedules/{schedule_id}")
async def delete_schedule(schedule_id: str, current_user: dict = Depends(require_admin)):
    async def operation(session):
        target = await db.schedules.find_one({"id": schedule_id}, session=session)
        if not target:
            raise HTTPException(404, "Escala não encontrada")
        if target.get("plan_id"):
            await lock_month(target["plan_id"], session)
        await remove_schedules([schedule_id], session)
        if target.get("plan_id"):
            remaining = await db.schedules.find({"plan_id": target["plan_id"]}, session=session).to_list(None)
            if remaining:
                await db.monthly_plans.update_one({"id": target["plan_id"]}, {"$set": {"dates": sorted({row["date"] for row in remaining})}}, session=session)
                await planning_event(target["plan_id"], "Equipe excluída", target.get("name", "") + " · " + target["date"], session)
            else:
                await db.monthly_plans.delete_one({"id": target["plan_id"]}, session=session)
                await db.planning_events.delete_many({"plan_id": target["plan_id"]}, session=session)
        return {"message": "Escala excluída"}
    return await run_assignment_transaction(operation)

async def remove_schedules(ids, session):
    members = await db.schedule_members.find({"schedule_id": {"$in": ids}}, session=session).to_list(None)
    for vid in sorted({row["volunteer_id"] for row in members}):
        await db.volunteers.update_one({"id": vid}, {"$inc": {"_assignment_revision": 1}}, session=session)
    await db.schedules.delete_many({"id": {"$in": ids}}, session=session)
    await db.schedule_members.delete_many({"schedule_id": {"$in": ids}}, session=session)
    await db.setlists.delete_many({"schedule_id": {"$in": ids}}, session=session)
    await db.availability.delete_many({"schedule_id": {"$in": ids}}, session=session)

@api_router.delete("/monthly-plans/{plan_id}")
async def delete_monthly_plan(plan_id: str, current_user: dict = Depends(require_admin)):
    async def operation(session):
        await lock_month(plan_id, session)
        schedules = await db.schedules.find({"plan_id": plan_id}, session=session).to_list(None)
        await remove_schedules([row["id"] for row in schedules], session)
        await db.monthly_plans.delete_one({"id": plan_id}, session=session)
        await db.planning_events.delete_many({"plan_id": plan_id}, session=session)
        return {"message": "Planejamento e todas as suas equipes excluídos"}
    return await run_assignment_transaction(operation)

class BandLeaderUpdate(BaseModel):
    volunteer_id: str = Field(default="", max_length=100)
    name: str = Field(default="", max_length=120)

@api_router.put("/schedules/{schedule_id}/band-leader")
async def set_band_leader(schedule_id: str, data: BandLeaderUpdate, current_user: dict = Depends(require_admin)):
    async def operation(session):
        schedule = await db.schedules.find_one({"id": schedule_id}, session=session)
        if not schedule:
            raise HTTPException(404, "Escala não encontrada")
        if schedule.get("plan_id"):
            await lock_month(schedule["plan_id"], session)
        name = data.name.strip()
        if data.volunteer_id:
            person = await db.volunteers.find_one({"id": data.volunteer_id, "status": "Ativo", "archived": {"$ne": True}}, session=session)
            if not person:
                raise HTTPException(404, "Voluntário ativo não encontrado")
            name = person["name"]
        elif data.name and not name:
            raise HTTPException(422, "Informe o nome do líder")
        await db.schedules.update_one({"id": schedule_id}, {"$set": {"band_leader_id": data.volunteer_id, "band_leader_name": name}, "$inc": {"_assignment_revision": 1}}, session=session)
        if schedule.get("plan_id"):
            await planning_event(schedule["plan_id"], "Líder da banda atualizado", schedule["date"] + " · " + (name or "Sem líder definido"), session)
        return {"band_leader_id": data.volunteer_id, "band_leader_name": name}
    return await run_assignment_transaction(operation)

DEFAULT_TEAM_SLOTS = {"Vocal": 6, "Violão": 2, "Guitarra": 2, "Teclado": 2, "Baixo": 1, "Bateria": 1, "Percussão": 1}

async def run_assignment_transaction(operation):
    try:
        async with await client.start_session() as session:
            return await session.with_transaction(operation, read_concern=ReadConcern("snapshot"), write_concern=WriteConcern("majority"))
    except PyMongoError:
        logger.exception("Falha na transação de inclusão na escala")
        raise HTTPException(status_code=503, detail="Não foi possível concluir a inclusão. Atualize a escala antes de tentar novamente.")

@api_router.post("/schedules/{schedule_id}/members")
async def add_schedule_member(schedule_id: str, member: ScheduleMemberAdd, current_user: dict = Depends(require_admin)):
    async def operation(session):
        return await insert_schedule_member(schedule_id, member, session)
    return await run_assignment_transaction(operation)

async def insert_schedule_member(schedule_id: str, member: ScheduleMemberAdd, session):
    initial = await db.schedules.find_one({"id": schedule_id}, session=session)
    if initial and initial.get("plan_id"):
        await lock_month(initial["plan_id"], session, stages={"Montagem"})
    # Writing the shared schedule serializes competing transactions across workers.
    locked = await db.schedules.update_one({"id": schedule_id}, {"$inc": {"_assignment_revision": 1}}, session=session)
    if not locked.matched_count:
        raise HTTPException(status_code=404, detail="Escala não encontrada")
    active = await db.volunteers.update_one({"id": member.volunteer_id, "status": "Ativo"}, {"$inc": {"_assignment_revision": 1}}, session=session)
    volunteer = await db.volunteers.find_one({"id": member.volunteer_id}, {"_id": 0}, session=session)
    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")
    if not active.matched_count:
        raise HTTPException(status_code=409, detail="Somente voluntários ativos podem ser incluídos na escala")
    
    schedule = await db.schedules.find_one({"id": schedule_id}, {"_id": 0}, session=session)
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")

    existing_members = await db.schedule_members.find(
        {"schedule_id": schedule_id, "volunteer_id": member.volunteer_id}, {"_id": 0, "function": 1}, session=session
    ).to_list(None)
    if any(schedule_function_key(existing.get("function") or "") == schedule_function_key(member.function)
           for existing in existing_members):
        raise HTTPException(status_code=409, detail="Esta pessoa já está escalada nesta função")

    # Verificar indisponibilidade
    schedule_date = schedule.get("date", "")
    await ensure_free_day(member.volunteer_id, schedule_date, schedule_id, session)
    exception = None
    if schedule.get("plan_id"):
        if schedule["ministry"] not in volunteer.get("ministries", ["Red Music"]):
            raise HTTPException(409, "O voluntário não está vinculado a este ministério. Confira o perfil.")
        answer = await db.daily_availability.find_one({"volunteer_id": member.volunteer_id, "date": schedule_date}, session=session)
        blocked = any(item.get("date") == schedule_date for item in volunteer.get("unavailability_dates", []))
        if not answer or not answer.get("available") or blocked:
            if not member.exception_reason.strip():
                raise HTTPException(409, "Inclusão fora da disponibilidade exige uma justificativa da liderança")
            exception = member.exception_reason.strip()
    unavail_dates = volunteer.get("unavailability_dates", [])
    for unavail in unavail_dates:
        if unavail.get("date") == schedule_date and not schedule.get("plan_id"):
            return {"warning": f"Voluntário {volunteer['name']} está indisponível nesta data: {unavail.get('reason', 'Sem motivo especificado')}"}
    
    # Verificar limite de vagas
    team_slots = {**DEFAULT_TEAM_SLOTS, **(schedule.get("team_slots") or {})}
    function_normalized = "Vocal" if "vocal" in member.function.lower() else member.function
    
    if function_normalized in team_slots:
        limit = team_slots[function_normalized]
        members = await db.schedule_members.find({"schedule_id": schedule_id}, {"_id": 0, "function": 1}, session=session).to_list(None)
        group_keys = {schedule_function_key(function_normalized)}
        if function_normalized == "Vocal":
            group_keys.add(schedule_function_key("Backing Vocal"))
        current_count = sum(schedule_function_key(entry.get("function")) in group_keys for entry in members)
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 0:
            raise HTTPException(status_code=409, detail="Configuração de vagas inválida. Confira a escala.")
        
        if current_count >= limit:
            raise HTTPException(
                status_code=409,
                detail=f"Limite de {limit} vaga(s) para {function_normalized} já atingido"
            )
    
    slot_identity = json.dumps([schedule_id, member.volunteer_id, member.function], ensure_ascii=False)
    member_doc = {
        "_id": "schedule-slot:" + str(uuid.uuid5(uuid.NAMESPACE_URL, slot_identity)),
        "id": str(uuid.uuid4()),
        "schedule_id": schedule_id,
        "volunteer_id": member.volunteer_id,
        "volunteer_name": volunteer["name"],
        "function": member.function,
        "confirmation_status": "Dispensada" if schedule.get("validation_required") is False else "Pendente",
        "created_at": datetime.now(timezone.utc)
    }
    if schedule.get("plan_id"):
        member_doc.update(plan_id=schedule["plan_id"], availability_exception=bool(exception), exception_reason=exception or "")
    
    try:
        await db.schedule_members.insert_one(member_doc, session=session)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Esta pessoa já está escalada nesta função")
    if schedule.get("plan_id"):
        await reset_participation(schedule_id, member.volunteer_id, session)
        await planning_event(schedule["plan_id"], "Equipe alterada", f"Incluído {volunteer['name']} em {schedule['date']} · {schedule.get('location', '')}: {member.function}", session)
        member_doc = await db.schedule_members.find_one({"id": member_doc["id"]}, session=session)
    member_doc.pop("_id", None)
    return member_doc

@api_router.put("/schedules/{schedule_id}/members/{member_id}")
async def update_schedule_member(schedule_id: str, member_id: str, updates: ScheduleMemberUpdate, current_user: dict = Depends(get_current_user)):
    target = await require_visible_schedule(schedule_id, current_user)
    if target.get("plan_id") or target.get("validation_required") is False:
        raise HTTPException(409, "Use a validação do planejamento mensal. Escalas individuais novas dispensam validação.")
    member_query = {"id": member_id, "schedule_id": schedule_id}
    member = await db.schedule_members.find_one(member_query, {"_id": 0})
    if not member or not await db.schedules.find_one({"id": schedule_id}):
        raise HTTPException(status_code=404, detail="Participação não encontrada nesta escala")
    if current_user.get("role") not in ("Administrador", "Líder"):
        volunteer = await db.volunteers.find_one({"id": current_user.get("volunteer_id"), "status": "Ativo"})
        if (current_user.get("role") != "Voluntário" or not volunteer
                or member["volunteer_id"] != volunteer["id"]):
            raise HTTPException(status_code=403, detail="Você só pode responder pela sua própria participação")
    await db.schedule_members.update_one(
        member_query,
        {"$set": {"confirmation_status": updates.confirmation_status}}
    )
    updated = await db.schedule_members.find_one(member_query, {"_id": 0})
    return updated

@api_router.delete("/schedules/{schedule_id}/members/{member_id}")
async def delete_schedule_member(schedule_id: str, member_id: str, current_user: dict = Depends(require_admin)):
    async def operation(session):
        schedule = await db.schedules.find_one({"id": schedule_id}, session=session)
        if schedule and schedule.get("plan_id"):
            await lock_month(schedule["plan_id"], session, stages={"Montagem"})
        await db.schedules.update_one({"id": schedule_id}, {"$inc": {"_assignment_revision": 1}}, session=session)
        member = await db.schedule_members.find_one({"id": member_id, "schedule_id": schedule_id}, session=session)
        if not member:
            raise HTTPException(404, "Participação não encontrada")
        await db.volunteers.update_one({"id": member["volunteer_id"]}, {"$inc": {"_assignment_revision": 1}}, session=session)
        await db.schedule_members.delete_one({"id": member_id, "schedule_id": schedule_id}, session=session)
        if schedule and schedule.get("plan_id"):
            await reset_participation(schedule_id, member["volunteer_id"], session)
            await planning_event(schedule["plan_id"], "Equipe alterada", f"Removido {member['volunteer_name']} de {schedule['date']} · {schedule.get('location', '')}: {member['function']}. Observação anterior: {member.get('response_note', '')}", session)
    await run_assignment_transaction(operation)
    return {"message": "Member removed from schedule"}

@api_router.post("/setlists/{schedule_id}/songs")
async def add_setlist_song(schedule_id: str, song_data: SetlistSongAdd, current_user: dict = Depends(require_admin)):
    if not await db.schedules.find_one({"id": schedule_id}, {"_id": 1}):
        raise HTTPException(status_code=404, detail="Schedule not found")
    song = await db.songs.find_one({"id": song_data.song_id, "archived": {"$ne": True}}, {"_id": 0})
    if not song:
        raise HTTPException(status_code=404, detail="Song not found")
    
    setlist = await db.setlists.find_one({"schedule_id": schedule_id})
    
    song_entry = {
        "id": str(uuid.uuid4()),
        "song_id": song_data.song_id,
        "song_name": song["name"],
        "original_key": song["original_key"],
        "key_for_this_event": song_data.key_for_this_event or song["original_key"],
        "main_vocal_volunteer_id": song_data.main_vocal_volunteer_id,
        "order": song_data.order
    }
    
    if setlist:
        await db.setlists.update_one(
            {"schedule_id": schedule_id},
            {"$push": {"songs": song_entry}}
        )
    else:
        setlist_doc = {
            "schedule_id": schedule_id,
            "songs": [song_entry],
            "created_at": datetime.now(timezone.utc)
        }
        await db.setlists.insert_one(setlist_doc)
    
    return song_entry

@api_router.get("/setlists/{schedule_id}")
async def get_setlist(schedule_id: str, current_user: dict = Depends(get_current_user)):
    await require_visible_schedule(schedule_id, current_user)
    setlist = await db.setlists.find_one({"schedule_id": schedule_id}, {"_id": 0})
    if not setlist:
        return {"schedule_id": schedule_id, "songs": []}
    return setlist

@api_router.delete("/setlists/{schedule_id}/songs/{song_entry_id}")
async def remove_setlist_song(schedule_id: str, song_entry_id: str, current_user: dict = Depends(require_admin)):
    await db.setlists.update_one(
        {"schedule_id": schedule_id},
        {"$pull": {"songs": {"id": song_entry_id}}}
    )
    return {"message": "Song removed from setlist"}

class SetlistReorder(BaseModel):
    model_config = ConfigDict(extra="forbid")
    song_entry_ids: List[Annotated[str, Field(min_length=1)]]
    expected_entry_ids: List[Annotated[str, Field(min_length=1)]]

    @field_validator("song_entry_ids", "expected_entry_ids")
    @classmethod
    def unique_entries(cls, value):
        if len(value) != len(set(value)):
            raise ValueError("Cada entrada do repertório deve aparecer uma única vez")
        return value

@api_router.put("/setlists/{schedule_id}/reorder")
async def reorder_setlist(schedule_id: str, data: SetlistReorder, current_user: dict = Depends(require_admin)):
    if not await db.schedules.find_one({"id": schedule_id}, {"_id": 1}):
        raise HTTPException(status_code=404, detail="Escala não encontrada")
    setlist = await db.setlists.find_one({"schedule_id": schedule_id})
    if not setlist:
        raise HTTPException(status_code=404, detail="Repertório não encontrado")
    original = setlist.get("songs")
    if not isinstance(original, list) or any(not isinstance(entry, dict) or not isinstance(entry.get("id"), str) or not entry["id"] for entry in original):
        raise HTTPException(status_code=409, detail="Há entradas sem identificador válido. Revise o repertório antes de reordenar.")
    current_ids = [entry["id"] for entry in original]
    if len(set(current_ids)) != len(current_ids):
        raise HTTPException(status_code=409, detail="Há entradas com identificadores duplicados. Revise o repertório antes de reordenar.")
    if data.expected_entry_ids != current_ids or set(data.song_entry_ids) != set(current_ids):
        raise HTTPException(status_code=409, detail="O repertório mudou ou a lista enviada está incompleta. Atualize a escala e tente novamente.")
    by_id = {entry["id"]: entry for entry in original}
    reordered = [{**by_id[entry_id], "order": index + 1} for index, entry_id in enumerate(data.song_entry_ids)]
    # Compare the full snapshot atomically so concurrent edits cannot be overwritten.
    result = await db.setlists.update_one(
        {"_id": setlist["_id"], "songs": original},
        {"$set": {"songs": reordered}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=409, detail="O repertório foi alterado durante a reordenação. Atualize a escala e tente novamente.")
    return {"message": "Setlist reordered successfully"}

@api_router.get("/schedules/{schedule_id}/vocals")
async def get_schedule_vocals(schedule_id: str, current_user: dict = Depends(get_current_user)):
    await require_visible_schedule(schedule_id, current_user)
    members = await db.schedule_members.find(
        {"schedule_id": schedule_id, "function": {"$regex": "vocal", "$options": "i"}},
        {"_id": 0}
    ).to_list(1000)
    return members

@api_router.get("/volunteers/{volunteer_id}/participation-history")
async def get_volunteer_participation(volunteer_id: str, current_user: dict = Depends(require_admin)):
    schedules = await db.schedules.find({}, {"_id": 0}).to_list(1000)
    
    participation = []
    for schedule in schedules:
        members = await db.schedule_members.find(
            {"schedule_id": schedule["id"], "volunteer_id": volunteer_id},
            {"_id": 0}
        ).to_list(1000)
        
        if members:
            for member in members:
                participation.append({
                    "schedule_id": schedule["id"],
                    "schedule_name": schedule["name"],
                    "schedule_date": schedule["date"],
                    "schedule_time": schedule["time"],
                    "function": member["function"],
                    "confirmation_status": member["confirmation_status"]
                })
    
    participation.sort(key=lambda x: x["schedule_date"], reverse=True)
    return participation

@api_router.get("/dashboard/metrics")
async def get_dashboard_metrics(current_user: dict = Depends(require_admin)):
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    schedules_count = await db.schedules.count_documents({})
    volunteers_count = await db.volunteers.count_documents({"status": "Ativo"})
    songs_count = await db.songs.count_documents({"archived": {"$ne": True}})
    
    volunteers = await db.volunteers.find({"status": "Ativo"}, {"_id": 0, "birth_date": 1, "name": 1}).to_list(1000)
    birthdays = []
    for vol in volunteers:
        if vol.get("birth_date"):
            from dateutil import parser
            bd = parser.parse(vol["birth_date"])
            if bd.month == now.month:
                birthdays.append({"name": vol["name"], "date": bd.day})
    
    return {
        "total_schedules": schedules_count,
        "active_volunteers": volunteers_count,
        "total_songs": songs_count,
        "birthdays_this_month": birthdays
    }

@api_router.get("/dashboard/top-songs")
async def get_top_songs(current_user: dict = Depends(require_admin)):
    usage = await get_song_usage()
    songs = await db.songs.find({"id": {"$in": list(usage)}, "archived": {"$ne": True}}, {"_id": 0}).to_list(None)
    songs = [with_song_usage(song, usage) for song in songs]
    songs.sort(key=lambda song: (-song["play_count"], song.get("name", "").casefold(), song["id"]))
    return songs[:10]

@api_router.get("/dashboard/burnout-alert")
async def get_burnout_alert(current_user: dict = Depends(require_admin)):
    schedules = await db.schedules.find(
        {"status": {"$in": PARTICIPATION_SCHEDULE_STATUSES}},
        {"_id": 0, "id": 1, "date": 1, "time": 1, "ministry": 1},
    ).to_list(None)
    ministries = {}
    for schedule in schedules:
        try:
            event_date = date.fromisoformat(schedule.get("date", ""))
        except (TypeError, ValueError):
            continue
        if schedule.get("id"):
            schedule["event_date"] = event_date
            ministries.setdefault(schedule.get("ministry") or "Red Music", []).append(schedule)

    volunteers = await db.volunteers.find(
        {"status": "Ativo"}, {"_id": 0, "id": 1, "name": 1}
    ).to_list(None)
    active_names = {person["id"]: person.get("name", "Voluntário") for person in volunteers if person.get("id")}
    members = await db.schedule_members.find(
        {"schedule_id": {"$in": [event["id"] for events in ministries.values() for event in events]}},
        {"_id": 0, "schedule_id": 1, "volunteer_id": 1},
    ).to_list(None)
    teams = {}
    for member in members:
        if member.get("volunteer_id") in active_names:
            teams.setdefault(member["schedule_id"], set()).add(member["volunteer_id"])

    # Report current planning streaks, not totals from old or interrupted runs.
    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).date()
    alerts = {}
    for ministry, events in sorted(ministries.items()):
        events.sort(key=lambda event: (event["event_date"], event.get("time") or "", event["id"]), reverse=True)
        last_date = events[0]["event_date"]
        if last_date < cutoff:
            continue
        ongoing = set(teams.get(events[0]["id"], set()))
        lengths = {person: 1 for person in ongoing}
        first_dates = {person: last_date for person in ongoing}
        previous_date = last_date
        for event in events[1:]:
            if (previous_date - event["event_date"]).days > 7:
                break
            ongoing.intersection_update(teams.get(event["id"], set()))
            if not ongoing:
                break
            for person in ongoing:
                lengths[person] += 1
                first_dates[person] = event["event_date"]
            previous_date = event["event_date"]
        for person, count in lengths.items():
            if count < 4:
                continue
            candidate = {
                "volunteer_id": person, "name": active_names[person],
                "consecutive_schedules": count, "ministry": ministry,
                "first_date": first_dates[person].isoformat(), "last_date": last_date.isoformat(),
            }
            existing = alerts.get(person)
            if existing is None or (count, candidate["last_date"]) > (existing["consecutive_schedules"], existing["last_date"]):
                alerts[person] = candidate
    return sorted(alerts.values(), key=lambda alert: (-alert["consecutive_schedules"], alert["name"].casefold(), alert["volunteer_id"]))

@api_router.post("/notifications/send")
async def send_notification(notif: NotificationRequest, current_user: dict = Depends(require_admin)):
    result = {"email_sent": False, "sms_sent": False}
    
    if notif.channel in ["email", "both"] and notif.recipient_email:
        resend.api_key = os.environ.get("RESEND_API_KEY", "")
        if resend.api_key:
            try:
                params = {
                    "from": os.environ.get("SENDER_EMAIL", "onboarding@resend.dev"),
                    "to": [notif.recipient_email],
                    "subject": notif.subject,
                    "html": f"<p>{notif.message}</p>"
                }
                email = await asyncio.to_thread(resend.Emails.send, params)
                result["email_sent"] = True
            except Exception as e:
                result["email_error"] = str(e)
    
    if notif.channel in ["sms", "both"] and notif.recipient_phone:
        pass
    
    notif_doc = notif.model_dump()
    notif_doc["id"] = str(uuid.uuid4())
    notif_doc["sent_at"] = datetime.now(timezone.utc)
    notif_doc["sent_by"] = current_user["id"]
    notif_doc["result"] = result
    await db.notifications.insert_one(notif_doc)
    
    return result

async def get_chat_identity(account: dict):
    role = account.get("role")
    if role in ("Administrador", "Líder"):
        return {"id": str(account["_id"]), "name": account.get("name") or "Liderança", "role": role}
    if role == "Voluntário" and account.get("volunteer_id"):
        volunteer = await db.volunteers.find_one({"id": account["volunteer_id"], "status": "Ativo"}, {"_id": 0, "name": 1})
        if volunteer:
            return {"id": str(account["_id"]), "name": volunteer.get("name") or "Voluntário", "role": role}
    return None

async def require_chat_user(current_user: dict = Depends(get_current_user)):
    identity = await get_chat_identity(current_user)
    if not identity:
        raise HTTPException(status_code=403, detail="Para acessar as mensagens, sua conta precisa estar vinculada pela liderança a um voluntário ativo")
    return identity

async def get_chat_recipient(other_user_id: str, current_user: dict):
    if not ObjectId.is_valid(other_user_id) or str(ObjectId(other_user_id)) == current_user["id"]:
        raise HTTPException(status_code=404, detail="Contato indisponível")
    account = await db.users.find_one({"_id": ObjectId(other_user_id)}, {"_id": 1, "name": 1, "role": 1, "volunteer_id": 1})
    identity = await get_chat_identity(account) if account else None
    if not identity or (current_user["role"] == "Voluntário" and identity["role"] == "Voluntário"):
        raise HTTPException(status_code=404, detail="Contato indisponível")
    return identity

@api_router.get("/chat/contacts")
async def get_chat_contacts(current_user: dict = Depends(require_chat_user)):
    roles = ["Administrador", "Líder"]
    if current_user["role"] in roles:
        roles.append("Voluntário")
    accounts = await db.users.find({"role": {"$in": roles}}, {"_id": 1, "name": 1, "role": 1, "volunteer_id": 1}).to_list(1000)
    contacts = []
    for account in accounts:
        if str(account["_id"]) == current_user["id"]:
            continue
        identity = await get_chat_identity(account)
        if identity:
            contacts.append(identity)
    return sorted(contacts, key=lambda contact: contact["name"].casefold())

@api_router.post("/chat/messages")
async def send_chat_message(message: ChatMessageCreate, current_user: dict = Depends(require_chat_user)):
    recipient = await get_chat_recipient(message.to_user_id, current_user)
    msg_doc = {
        "id": str(uuid.uuid4()),
        "from_user_id": current_user["id"],
        "from_user_name": current_user["name"],
        "to_user_id": recipient["id"],
        "message": message.message,
        "read": False,
        "timestamp": datetime.now(timezone.utc)
    }
    await db.chat_messages.insert_one(msg_doc)
    msg_doc.pop("_id", None)
    return msg_doc

@api_router.get("/chat/messages/{other_user_id}")
async def get_chat_messages(other_user_id: str, current_user: dict = Depends(require_chat_user)):
    recipient = await get_chat_recipient(other_user_id, current_user)
    other_user_id = recipient["id"]
    messages = await db.chat_messages.find(
        {
            "$or": [
                {"from_user_id": current_user["id"], "to_user_id": other_user_id},
                {"from_user_id": other_user_id, "to_user_id": current_user["id"]}
            ]
        },
        {"_id": 0}
    ).sort([("timestamp", -1), ("_id", -1)]).limit(100).to_list(100)
    messages.reverse()
    return messages

@api_router.post("/volunteers/{volunteer_id}/upload-photo")
async def upload_volunteer_photo(volunteer_id: str, file: UploadFile = File(...), current_user: dict = Depends(require_admin)):
    try:
        if not await db.volunteers.find_one({"id": volunteer_id}):
            raise HTTPException(404, "Voluntário não encontrado")
        contents = await file.read(MAX_PHOTO_BYTES + 1)
        photo_url = await asyncio.to_thread(normalize_photo, contents)
    finally:
        await file.close()
    
    result = await db.volunteers.update_one(
        {"id": volunteer_id},
        {"$set": {"photo_url": photo_url}}
    )
    if not result.matched_count:
        raise HTTPException(404, "Voluntário não encontrado")
    
    return {"photo_url": photo_url}

class MonthlyPlanCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    year_month: YearMonth
    ministry: Ministry
    dates: List[CalendarDate] = Field(min_length=1, max_length=31)
    availability_deadline: Optional[CalendarDate] = None

    @model_validator(mode="after")
    def valid_dates(self):
        if len(set(self.dates)) != len(self.dates) or any(not value.startswith(self.year_month + "-") for value in self.dates):
            raise ValueError("Selecione datas únicas dentro do mês escolhido")
        if any(date.fromisoformat(value) < local_today() for value in self.dates):
            raise ValueError("O planejamento deve usar datas de hoje em diante")
        if self.availability_deadline and not (local_today().isoformat() <= self.availability_deadline <= min(self.dates)):
            raise ValueError("O prazo deve ficar entre hoje e a primeira data do planejamento")
        return self


class DailyAnswer(BaseModel):
    model_config = ConfigDict(extra="forbid")
    date: CalendarDate
    available: StrictBool


class MonthlyAvailability(BaseModel):
    model_config = ConfigDict(extra="forbid")
    responses: List[DailyAnswer] = Field(min_length=1, max_length=31)


class MonthAction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Literal["montar", "validar", "reabrir", "publicar"]


class ParticipationAnswer(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schedule_id: str
    expected_version: str = Field(min_length=1)
    decision: Literal["Confirmado", "Preciso de Substituto"]
    note: str = Field(default="", max_length=1000)

    @model_validator(mode="after")
    def note_for_adjustment(self):
        if self.decision == "Preciso de Substituto" and not self.note.strip():
            raise ValueError("Explique o ajuste necessário no campo de observação")
        return self


class MonthlyAnswers(BaseModel):
    model_config = ConfigDict(extra="forbid")
    responses: List[ParticipationAnswer] = Field(min_length=1, max_length=62)


class AdjustmentResolution(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schedule_id: str
    volunteer_id: str
    expected_version: str = Field(min_length=1)
    resolution: str = Field(min_length=1, max_length=1000)


def safe_member(member, user=None):
    value = dict(member)
    if not user or (user.get("role") not in {"Administrador", "Líder"} and user.get("volunteer_id") != member.get("volunteer_id")):
        for key in ("response_note", "adjustment_resolution", "exception_reason", "validation_version", "response_at", "availability_exception"):
            value.pop(key, None)
    value.pop("_id", None)
    return value


async def ensure_free_day(volunteer_id, day, schedule_id, session=None):
    if not day:
        return
    others = await db.schedules.find({"date": day, "id": {"$ne": schedule_id}}, {"id": 1}, session=session).to_list(None)
    if others and await db.schedule_members.find_one({"schedule_id": {"$in": [item["id"] for item in others]}, "volunteer_id": volunteer_id}, session=session):
        raise HTTPException(409, "Esta pessoa já está em outra equipe neste dia, inclusive entre Red e Pulse. O conflito não pode ser ignorado.")


async def lock_month(plan_id, session, stages=None):
    plan = await db.monthly_plans.find_one({"id": plan_id}, session=session)
    if not plan:
        raise HTTPException(404, "Planejamento não encontrado")
    if stages and plan["stage"] not in stages:
        raise HTTPException(409, "Esta ação não está disponível nesta etapa. Atualize o planejamento.")
    await db.monthly_plans.update_one({"id": plan_id}, {"$inc": {"revision": 1}}, session=session)
    return plan


async def planning_event(plan_id, title, detail, session):
    await db.planning_events.insert_one({"plan_id": plan_id, "title": title, "detail": detail,
        "created_at": datetime.now(timezone.utc)}, session=session)


async def reset_participation(schedule_id, volunteer_id, session, resolution=""):
    await db.schedule_members.update_many({"schedule_id": schedule_id, "volunteer_id": volunteer_id},
        {"$set": {"confirmation_status": "Pendente", "validation_version": str(uuid.uuid4()),
                  "response_note": "", "adjustment_resolution": resolution}}, session=session)


async def own_active_volunteer(user, session=None):
    volunteer = await db.volunteers.find_one({"id": user.get("volunteer_id"), "status": "Ativo"}, session=session) if user.get("volunteer_id") else None
    if not volunteer:
        raise HTTPException(403, "É necessário um vínculo autorizado com um voluntário ativo")
    return volunteer


async def monthly_candidates(schedule, include_exceptions):
    people = await db.volunteers.find({"status": "Ativo"}, {"_id": 0}).to_list(None)
    answers = await db.daily_availability.find({"date": schedule["date"]}, {"_id": 0}).to_list(None)
    available = {item["volunteer_id"]: item["available"] for item in answers}
    month_schedules = await db.schedules.find({"date": {"$regex": "^" + schedule["date"][:7] + "-"}}, {"_id": 0}).to_list(None)
    members = await db.schedule_members.find({"schedule_id": {"$in": [item["id"] for item in month_schedules]}}, {"_id": 0}).to_list(None)
    day_ids = {item["id"] for item in month_schedules if item["date"] == schedule["date"] and item["id"] != schedule["id"]}
    conflicts = {item["volunteer_id"] for item in members if item["schedule_id"] in day_ids}
    result = []
    for person in people:
        if not person.get("id"):
            continue
        if schedule["ministry"] not in person.get("ministries", ["Red Music"]):
            continue
        vid = person["id"]
        blocked = any(item.get("date") == schedule["date"] for item in person.get("unavailability_dates", []))
        explicit = available.get(vid) is True and not blocked
        if not include_exceptions and (not explicit or vid in conflicts):
            continue
        result.append({"id": vid, "name": person["name"], "instruments": person.get("instruments", []),
            "functions": person.get("functions", []), "explicitly_available": explicit,
            "availability_status": "Bloqueio de data" if blocked else "Disponível" if available.get(vid) is True else "Indisponível" if available.get(vid) is False else "Sem resposta",
            "day_conflict": vid in conflicts,
            "monthly_schedule_count": len({item["schedule_id"] for item in members if item["volunteer_id"] == vid})})
    return sorted(result, key=lambda person: person["name"].casefold())


def participation_groups(members):
    groups = {}
    for member in members:
        key = (member["schedule_id"], member["volunteer_id"])
        if key not in groups:
            groups[key] = {key: member.get(key, "") for key in ("schedule_id", "volunteer_id", "volunteer_name", "confirmation_status", "validation_version", "response_note", "adjustment_resolution")}
            groups[key]["functions"] = []
        groups[key]["functions"].append(member["function"])
    return list(groups.values())


async def month_view(plan, user):
    leader = user.get("role") in {"Administrador", "Líder"}
    schedules = await db.schedules.find({"plan_id": plan["id"]}, {"_id": 0}).sort([("date", 1), ("location", 1)]).to_list(None)
    members = await db.schedule_members.find({"plan_id": plan["id"]}, {"_id": 0}).to_list(None)
    volunteer = None if leader else await own_active_volunteer(user)
    if not leader and plan["ministry"] not in volunteer.get("ministries", ["Red Music"]) and not any(item["volunteer_id"] == volunteer["id"] for item in members):
        raise HTTPException(404, "Planejamento não encontrado")
    result = {key: value for key, value in plan.items() if key not in {"_id", "created_by"}}
    result["schedules"] = [{key: item.get(key) for key in ("id", "name", "date", "location", "ministry", "status", "band_leader_id", "band_leader_name")} for item in schedules]
    if leader:
        profiles = {item["id"]: item for item in await db.volunteers.find({}, {"id": 1, "status": 1, "unavailability_dates": 1}).to_list(None) if item.get("id")}
        accounts = {item.get("volunteer_id") for item in await db.users.find({"role": {"$in": ["Voluntário", "Líder", "Administrador"]}}, {"volunteer_id": 1}).to_list(None)}
        answers = await db.daily_availability.find({"date": {"$in": plan["dates"]}}, {"_id": 0}).to_list(None)
        by_day = {(item["volunteer_id"], item["date"]): item["available"] for item in answers}
        by_schedule = {item["id"]: item for item in schedules}
        for member in members:
            person = profiles.get(member["volunteer_id"], {})
            member["account_ready"] = member["volunteer_id"] in accounts and person.get("status") == "Ativo"
            day = by_schedule[member["schedule_id"]]["date"]
            member["availability_warning"] = by_day.get((member["volunteer_id"], day)) is not True or any(item.get("date") == day for item in person.get("unavailability_dates", []))
        result["members"] = members
        groups = participation_groups(members)
        result["summary"] = {"total": len(groups), "confirmed": sum(item["confirmation_status"] == "Confirmado" for item in groups), "adjustments": sum(item["confirmation_status"] == "Preciso de Substituto" for item in groups), "pending": sum(item["confirmation_status"] == "Pendente" for item in groups)}
        eligible = [item for item in await db.volunteers.find({"status": "Ativo"}, {"_id": 0}).to_list(None) if item.get("id") and plan["ministry"] in item.get("ministries", ["Red Music"])]
        result["availability_overview"] = [{"id": item["id"], "name": item["name"], "responses": {day: by_day.get((item["id"], day)) for day in plan["dates"]}} for item in eligible]
        result["events"] = await db.planning_events.find({"plan_id": plan["id"]}, {"_id": 0}).sort("created_at", -1).limit(100).to_list(100)
        if user.get("volunteer_id"):
            own = await db.volunteers.find_one({"id": user["volunteer_id"], "status": "Ativo"})
            if own:
                result["participations"] = participation_groups([item for item in members if item["volunteer_id"] == own["id"]]) if plan["stage"] in {"Em Validação", "Concluído"} else []
                result["own_availability"] = {day: by_day[(own["id"], day)] for day in plan["dates"] if (own["id"], day) in by_day}
                result["can_answer_availability"] = plan["stage"] in {"Coleta", "Montagem"} and (not plan.get("availability_deadline") or local_today().isoformat() <= plan["availability_deadline"]) and plan["ministry"] in own.get("ministries", ["Red Music"])
    else:
        answers = await db.daily_availability.find({"date": {"$in": plan["dates"]}, "volunteer_id": volunteer["id"]}, {"_id": 0}).to_list(None)
        result["own_availability"] = {item["date"]: item["available"] for item in answers}
        result["can_answer_availability"] = plan["stage"] in {"Coleta", "Montagem"} and (not plan.get("availability_deadline") or local_today().isoformat() <= plan["availability_deadline"]) and plan["ministry"] in volunteer.get("ministries", ["Red Music"])
        result["participations"] = participation_groups([item for item in members if item["volunteer_id"] == volunteer["id"]]) if plan["stage"] in {"Em Validação", "Concluído"} else []
    return result


@api_router.post("/monthly-plans")
async def create_monthly_plan(data: MonthlyPlanCreate, user: dict = Depends(require_admin)):
    plan_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "monthly:" + data.ministry + ":" + data.year_month))
    async def operation(session):
        if await db.monthly_plans.find_one({"id": plan_id}, session=session):
            raise HTTPException(409, "Já existe um planejamento deste ministério neste mês")
        plan = {"_id": plan_id, "id": plan_id, **data.model_dump(), "dates": sorted(data.dates), "stage": "Coleta", "revision": 0, "created_at": datetime.now(timezone.utc), "created_by": str(user["_id"])}
        try:
            await db.monthly_plans.insert_one(plan, session=session)
        except DuplicateKeyError:
            raise HTTPException(409, "Já existe um planejamento deste ministério neste mês")
        for day in plan["dates"]:
            for location in (["Indaiatuba", "Itu"] if data.ministry == "Red Music" else ["Equipe única"]):
                await db.schedules.insert_one({"id": str(uuid.uuid4()), "plan_id": plan_id, "name": f"{data.ministry} · {location}", "date": day, "time": "00:00", "location": location,
                    "ministry": data.ministry, "event_type": "Domingo" if date.fromisoformat(day).weekday() == 6 else "Evento", "status": "Rascunho", "validation_required": True,
                    "share_token": str(uuid.uuid4()), "team_slots": DEFAULT_TEAM_SLOTS.copy(), "created_at": plan["created_at"], "created_by": str(user["_id"])}, session=session)
        return {"id": plan_id}
    return await run_assignment_transaction(operation)


@api_router.get("/monthly-plans")
async def list_monthly_plans(user: dict = Depends(get_current_user)):
    plans = await db.monthly_plans.find({}, {"_id": 0}).sort("year_month", -1).to_list(None)
    result = []
    for plan in plans:
        try:
            result.append(await month_view(plan, user))
        except HTTPException as error:
            if error.status_code != 404:
                raise
    return result


@api_router.get("/monthly-plans/{plan_id}")
async def get_monthly_plan(plan_id: str, user: dict = Depends(get_current_user)):
    plan = await db.monthly_plans.find_one({"id": plan_id}, {"_id": 0})
    if not plan:
        raise HTTPException(404, "Planejamento não encontrado")
    return await month_view(plan, user)


@api_router.put("/monthly-plans/{plan_id}/availability")
async def save_month_availability(plan_id: str, data: MonthlyAvailability, user: dict = Depends(get_current_user)):
    async def operation(session):
        plan = await lock_month(plan_id, session, {"Coleta", "Montagem"})
        volunteer = await own_active_volunteer(user, session)
        if plan["ministry"] not in volunteer.get("ministries", ["Red Music"]):
            raise HTTPException(403, "Você não está vinculado a este ministério")
        if plan.get("availability_deadline") and local_today().isoformat() > plan["availability_deadline"]:
            raise HTTPException(409, "O prazo de disponibilidade terminou. Entre em contato com a liderança.")
        days = [item.date for item in data.responses]
        if len(days) != len(set(days)) or not set(days).issubset(plan["dates"]):
            raise HTTPException(422, "Responda somente datas únicas deste planejamento")
        await db.volunteers.update_one({"id": volunteer["id"]}, {"$inc": {"_assignment_revision": 1}}, session=session)
        for item in data.responses:
            identity = str(uuid.uuid5(uuid.NAMESPACE_URL, "daily:" + volunteer["id"] + ":" + item.date))
            await db.daily_availability.update_one({"_id": identity}, {"$set": {"volunteer_id": volunteer["id"], "date": item.date, "available": item.available, "updated_at": datetime.now(timezone.utc)}}, upsert=True, session=session)
        return {"message": "Disponibilidade salva por dia, compartilhada entre Red e Pulse. Se você já estiver em uma equipe, a liderança verá eventuais indisponibilidades."}
    return await run_assignment_transaction(operation)


@api_router.post("/monthly-plans/{plan_id}/stage")
async def change_month_stage(plan_id: str, data: MonthAction, user: dict = Depends(require_admin)):
    async def operation(session):
        allowed = {"montar": {"Coleta"}, "validar": {"Montagem"}, "reabrir": {"Em Validação", "Concluído"}, "publicar": {"Em Validação"}}
        await lock_month(plan_id, session, allowed[data.action])
        schedules = await db.schedules.find({"plan_id": plan_id}, session=session).to_list(None)
        members = await db.schedule_members.find({"plan_id": plan_id}, session=session).to_list(None)
        if data.action in {"validar", "publicar"}:
            if not schedules or any(not any(member["schedule_id"] == schedule["id"] for member in members) for schedule in schedules):
                raise HTTPException(409, "Inclua ao menos uma pessoa em cada equipe antes de enviar ou concluir o mês")
            for vid in {member["volunteer_id"] for member in members}:
                if not await db.volunteers.find_one({"id": vid, "status": "Ativo"}, session=session) or not await db.users.find_one({"volunteer_id": vid, "role": {"$in": ["Voluntário", "Líder", "Administrador"]}}, session=session):
                    raise HTTPException(409, "Todas as pessoas escaladas precisam de perfil ativo e conta de voluntário vinculada para validar. Confira os avisos nas equipes.")
            if data.action == "publicar" and any(member["confirmation_status"] != "Confirmado" for member in members):
                raise HTTPException(409, "Ainda existem confirmações pendentes ou solicitações de ajuste")
        stage = {"montar": "Montagem", "validar": "Em Validação", "reabrir": "Montagem", "publicar": "Concluído"}[data.action]
        await db.monthly_plans.update_one({"id": plan_id}, {"$set": {"stage": stage}}, session=session)
        await db.schedules.update_many({"plan_id": plan_id}, {"$set": {"status": "Fechada" if stage == "Concluído" else "Em Validação" if stage == "Em Validação" else "Rascunho"}}, session=session)
        await planning_event(plan_id, "Etapa alterada", f"{stage} · por {user.get('name', 'Liderança')}", session)
        return {"stage": stage}
    return await run_assignment_transaction(operation)


@api_router.put("/daily-availability")
async def save_daily_availability(data: MonthlyAvailability, user: dict = Depends(get_current_user)):
    async def operation(session):
        volunteer = await own_active_volunteer(user, session)
        days = [item.date for item in data.responses]
        if len(days) != len(set(days)):
            raise HTTPException(422, "Responda cada dia uma única vez")
        plans = await db.monthly_plans.find({"stage": {"$in": ["Coleta", "Montagem"]}, "ministry": {"$in": volunteer.get("ministries", ["Red Music"])}, "dates": {"$in": days}}, session=session).to_list(None)
        eligible = [plan for plan in plans if not plan.get("availability_deadline") or local_today().isoformat() <= plan["availability_deadline"]]
        if not set(days).issubset({day for plan in eligible for day in plan["dates"]}):
            raise HTTPException(409, "Alguma data já encerrou a coleta ou não pertence aos seus ministérios. Atualize o painel.")
        for plan in sorted(eligible, key=lambda item: item["id"]):
            await lock_month(plan["id"], session, {"Coleta", "Montagem"})
        await db.volunteers.update_one({"id": volunteer["id"]}, {"$inc": {"_assignment_revision": 1}}, session=session)
        for item in data.responses:
            identity = str(uuid.uuid5(uuid.NAMESPACE_URL, "daily:" + volunteer["id"] + ":" + item.date))
            await db.daily_availability.update_one({"_id": identity}, {"$set": {"volunteer_id": volunteer["id"], "date": item.date, "available": item.available, "updated_at": datetime.now(timezone.utc)}}, upsert=True, session=session)
        return {"message": "Disponibilidade salva por dia e compartilhada entre seus ministérios"}
    return await run_assignment_transaction(operation)


@api_router.put("/monthly-plans/{plan_id}/responses")
async def answer_monthly_participations(plan_id: str, data: MonthlyAnswers, user: dict = Depends(get_current_user)):
    async def operation(session):
        await lock_month(plan_id, session, {"Em Validação"})
        volunteer = await own_active_volunteer(user, session)
        ids = [item.schedule_id for item in data.responses]
        if len(ids) != len(set(ids)):
            raise HTTPException(422, "Uma única resposta por participação")
        validated = []
        for item in data.responses:
            query = {"plan_id": plan_id, "schedule_id": item.schedule_id, "volunteer_id": volunteer["id"]}
            members = await db.schedule_members.find(query, session=session).to_list(None)
            if not members:
                raise HTTPException(403, "Você só pode responder pelas suas participações neste mês")
            if any(member.get("validation_version") != item.expected_version for member in members):
                raise HTTPException(409, "A participação foi alterada. Atualize o painel antes de responder.")
            if item.decision == "Confirmado" and any(member["confirmation_status"] == "Preciso de Substituto" for member in members):
                raise HTTPException(409, "Aguarde a liderança resolver a solicitação de ajuste antes de confirmar")
            validated.append((item, query, members))
        for item, query, members in validated:
            note = item.note.strip() if item.decision == "Preciso de Substituto" else ""
            await db.schedule_members.update_many(query, {"$set": {"confirmation_status": item.decision, "response_note": note, "response_at": datetime.now(timezone.utc), "validation_version": str(uuid.uuid4())}}, session=session)
            await planning_event(plan_id, "Resposta do voluntário", f"{volunteer['name']} · {members[0]['schedule_id']} · {item.decision}. {note}", session)
        return {"message": "Respostas registradas"}
    return await run_assignment_transaction(operation)


@api_router.put("/monthly-plans/{plan_id}/resolve")
async def resolve_month_adjustment(plan_id: str, data: AdjustmentResolution, user: dict = Depends(require_admin)):
    async def operation(session):
        await lock_month(plan_id, session, {"Montagem"})
        query = {"plan_id": plan_id, "schedule_id": data.schedule_id, "volunteer_id": data.volunteer_id}
        members = await db.schedule_members.find(query, session=session).to_list(None)
        if not data.resolution.strip() or not members or any(member.get("validation_version") != data.expected_version for member in members):
            raise HTTPException(409, "A participação foi alterada. Atualize o planejamento e descreva a solução.")
        await planning_event(plan_id, "Ajuste resolvido", f"{members[0]['volunteer_name']}: {members[0].get('response_note', '')} → {data.resolution.strip()}", session)
        await reset_participation(data.schedule_id, data.volunteer_id, session, data.resolution.strip())
        return {"message": "Solução registrada. A participação precisará de nova confirmação."}
    return await run_assignment_transaction(operation)


app.include_router(api_router)

@app.middleware("http")
async def prevent_private_data_caching(request: Request, call_next):
    response = await call_next(request)
    if (request.url.path.startswith("/api/volunteers")
            or request.url.path.startswith("/api/auth/")
            or request.url.path.startswith("/api/schedules")
            or request.url.path.startswith("/api/setlists/")
            or request.url.path.endswith("/available-volunteers")
            or request.url.path.startswith("/api/chat/")
            or request.url.path.startswith("/api/monthly-plans")
            or request.url.path == "/api/daily-availability"
            or request.url.path == "/api/songs" or request.url.path.startswith("/api/songs/")
            or request.url.path.startswith("/api/dashboard/")):
        response.headers["Cache-Control"] = "no-store"
    return response

app.add_middleware(AuthAttemptLimit)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=[origin.strip() for origin in os.environ.get('CORS_ORIGINS', '').split(',') if origin.strip()],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(PhotoRequestLimit)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    get_jwt_secret()
    await db.users.create_index("email", unique=True)
    await db.users.create_index("volunteer_id", unique=True, sparse=True)
    await db.volunteers.create_index("id", unique=True)
    await db.songs.create_index("id", unique=True)
    await db.schedules.create_index("id", unique=True)
    await db.schedule_members.create_index("id", unique=True)
    await db.auth_sessions.create_index("expires_at", expireAfterSeconds=0)
    await db.auth_attempts.create_index("expires_at", expireAfterSeconds=0)
    await db.monthly_plans.create_index("id", unique=True)
    await db.schedules.create_index("plan_id")
    await db.schedule_members.create_index("plan_id")
    await db.daily_availability.create_index([("volunteer_id", 1), ("date", 1)], unique=True)
    await db.planning_events.create_index([("plan_id", 1), ("created_at", -1)])
    
    admin_email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "")
    if admin_email and admin_password:
        existing = await db.users.find_one({"email": admin_email})
        if existing is None:
            try:
                validate_new_password(admin_password)
            except ValueError as error:
                raise RuntimeError(f"ADMIN_PASSWORD: {error}")
            await db.users.insert_one({
                "email": admin_email,
                "password_hash": hash_password(admin_password),
                "name": "Administrador",
                "role": "Administrador",
                "created_at": datetime.now(timezone.utc)
            })
            logger.info("Administrador inicial criado")
        elif existing.get("role") != "Administrador":
            raise RuntimeError("ADMIN_EMAIL já pertence a uma conta sem perfil de administrador")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()


@app.get("/api/health")
async def health():
    try:
        await db.command("ping")
    except Exception:
        return JSONResponse(status_code=503, content={"status": "unavailable"})
    return {"status": "ok"}


FRONTEND_BUILD = ROOT_DIR.parent / "frontend" / "build"
if (FRONTEND_BUILD / "index.html").is_file():
    app.mount("/static", StaticFiles(directory=FRONTEND_BUILD / "static"), name="static")

    @app.get("/{path:path}", include_in_schema=False)
    async def frontend(path: str):
        if path == "api" or path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found")
        candidate = (FRONTEND_BUILD / path).resolve()
        if candidate.is_relative_to(FRONTEND_BUILD.resolve()) and candidate.is_file():
            return FileResponse(candidate)
        if Path(path).suffix:
            raise HTTPException(status_code=404, detail="Not found")
        return FileResponse(FRONTEND_BUILD / "index.html", headers={"Cache-Control": "no-cache"})

