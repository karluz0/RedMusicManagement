"""Monthly workflow integration; isolated local MongoDB only."""
import asyncio
import importlib.util
import os
from pathlib import Path
import uuid
import pytest


@pytest.mark.skipif(os.environ.get('RUN_MONGO_TRANSACTION_TESTS') != '1', reason='Requires disposable local replica set')
def test_monthly_transactions_cross_team_races_publish_race_and_rollback(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    monkeypatch.setenv('MONGO_URL', 'mongodb://127.0.0.1:27019/?replicaSet=codex-local-test')
    database = 'codex_monthly_test_' + uuid.uuid4().hex
    monkeypatch.setenv('DB_NAME', database)
    monkeypatch.setenv('JWT_SECRET', 'isolated-monthly-secret-at-least-32-characters')

    async def exercise():
        workers = []
        for index in range(2):
            spec = importlib.util.spec_from_file_location('month_worker_' + str(index), Path(__file__).parents[1] / 'server.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.client.close()
            module.client = AsyncIOMotorClient(module.mongo_url, serverSelectionTimeoutMS=10000)
            module.db = module.client[database]
            workers.append(module)
        first, second = workers
        leader = {'_id': 'isolated-leader', 'name': 'Leader', 'role': 'Gestor'}
        try:
            await first.db.command('ping')
            await first.db.volunteers.insert_many([{'id': name, 'name': name.title(), 'status': 'Ativo', 'ministries': ['Red Music', 'Pulse Music']} for name in ['ana', 'bruno']])
            await first.db.users.insert_many([{'email': name + '@example.com', 'role': 'Voluntário', 'volunteer_id': name} for name in ['ana', 'bruno']])
            dates = ['2099-11-0' + str(index) for index in range(1, 6)]
            red = (await first.create_monthly_plan(first.MonthlyPlanCreate(year_month='2099-11', ministry='Red Music', dates=dates), leader))['id']
            pulse = (await second.create_monthly_plan(second.MonthlyPlanCreate(year_month='2099-11', ministry='Pulse Music', dates=dates), leader))['id']
            for pid in [red, pulse]:
                await first.change_month_stage(pid, first.MonthAction(action='montar'), leader)
            for day in dates:
                red_team = await first.db.schedules.find_one({'plan_id': red, 'date': day, 'location': 'Itu'})
                pulse_team = await first.db.schedules.find_one({'plan_id': pulse, 'date': day})
                async def assign(module, sid):
                    try:
                        await module.add_schedule_member(sid, module.ScheduleMemberAdd(volunteer_id='ana', function='Vocal', exception_reason='Local test agreement'), leader)
                        return 200
                    except module.HTTPException as error:
                        return error.status_code
                results = await asyncio.gather(assign(first, red_team['id']), assign(second, pulse_team['id']))
                assert sorted(results) == [200, 409], results
            assert await first.db.schedule_members.count_documents({'volunteer_id': 'ana'}) == 5
            assert (await first.db.volunteers.find_one({'id': 'ana'}))['_assignment_revision'] == 5

            # A failure after writing a schedule must roll back the entire plan creation.
            collection = first.db.schedules
            monkeypatch.setattr(first.db, 'schedules', collection)
            original_insert = collection.insert_one
            async def fail_after_write(document, **kwargs):
                await original_insert(document, **kwargs)
                raise RuntimeError('isolated injected error')
            monkeypatch.setattr(collection, 'insert_one', fail_after_write)
            before_plans = await first.db.monthly_plans.count_documents({})
            before_schedules = await first.db.schedules.count_documents({})
            with pytest.raises(RuntimeError):
                await first.create_monthly_plan(first.MonthlyPlanCreate(year_month='2100-01', ministry='Red Music', dates=['2100-01-01']), leader)
            assert await first.db.monthly_plans.count_documents({}) == before_plans
            assert await first.db.schedules.count_documents({}) == before_schedules
            monkeypatch.setattr(collection, 'insert_one', original_insert)

            pid = (await first.create_monthly_plan(first.MonthlyPlanCreate(year_month='2099-12', ministry='Pulse Music', dates=['2099-12-01']), leader))['id']
            await first.change_month_stage(pid, first.MonthAction(action='montar'), leader)
            team = await first.db.schedules.find_one({'plan_id': pid})
            await first.add_schedule_member(team['id'], first.ScheduleMemberAdd(volunteer_id='bruno', function='Vocal', exception_reason='Local test agreement'), leader)
            await first.change_month_stage(pid, first.MonthAction(action='validar'), leader)
            member = await first.db.schedule_members.find_one({'plan_id': pid})
            own = {'_id': 'isolated-bruno', 'role': 'Voluntário', 'volunteer_id': 'bruno'}
            await first.answer_monthly_participations(pid, first.MonthlyAnswers(responses=[first.ParticipationAnswer(schedule_id=team['id'], expected_version=member['validation_version'], decision='Confirmado')]), own)
            member = await first.db.schedule_members.find_one({'plan_id': pid})
            async def publish():
                try:
                    await first.change_month_stage(pid, first.MonthAction(action='publicar'), leader)
                    return 200
                except first.HTTPException as error:
                    return error.status_code
            async def adjust():
                try:
                    await second.answer_monthly_participations(pid, second.MonthlyAnswers(responses=[second.ParticipationAnswer(schedule_id=team['id'], expected_version=member['validation_version'], decision='Preciso de Substituto', note='Ajuste de última hora')]), own)
                    return 200
                except second.HTTPException as error:
                    return error.status_code
            results = await asyncio.gather(publish(), adjust())
            assert sorted(results) == [200, 409], results
            plan = await first.db.monthly_plans.find_one({'id': pid})
            participation = await first.db.schedule_members.find_one({'plan_id': pid})
            assert (plan['stage'], participation['confirmation_status']) in [('Concluído', 'Confirmado'), ('Em Validação', 'Preciso de Substituto')]
        finally:
            await first.client.drop_database(database)
            for module in workers:
                module.client.close()
    asyncio.run(exercise())
