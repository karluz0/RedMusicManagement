"""Real MongoDB check with independent workers; only disposable local data."""
import asyncio
import importlib.util
import os
from pathlib import Path
import uuid
import pytest


@pytest.mark.skipif(os.environ.get("RUN_MONGO_TRANSACTION_TESTS") != "1", reason="Requires disposable local MongoDB")
def test_auth_quota_is_atomic_across_workers_and_survives_recreation(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    monkeypatch.setenv("MONGO_URL", "mongodb://127.0.0.1:27019/?replicaSet=codex-local-test")
    monkeypatch.setenv("DB_NAME", "codex_auth_limit_test_" + uuid.uuid4().hex)
    monkeypatch.setenv("JWT_SECRET", "isolated-limit-test-secret-at-least-32-characters")

    async def exercise():
        workers = []
        def worker():
            spec = importlib.util.spec_from_file_location("auth_worker_" + uuid.uuid4().hex, Path(__file__).parents[1] / "server.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.client.close()
            module.client = AsyncIOMotorClient(module.mongo_url, serverSelectionTimeoutMS=10000)
            module.db = module.client[os.environ["DB_NAME"]]
            # Freeze beyond real time so neither a minute boundary nor TTL changes the test.
            module.auth_limit_now = lambda: module.datetime(2099, 1, 1, tzinfo=module.timezone.utc)
            workers.append(module)
            return module
        first, second = worker(), worker()
        try:
            await first.db.command("ping")
            await first.db.auth_attempts.create_index("expires_at", expireAfterSeconds=0)
            for iteration in range(5):
                async def attempt(index):
                    module = [first, second][index % 2]
                    try:
                        await module.consume_auth_limit("login-email", f"race-{iteration}@example.com", 10, 900)
                        return 200
                    except module.HTTPException as error:
                        return error.status_code
                results = await asyncio.gather(*[attempt(index) for index in range(40)])
                assert results.count(200) == 10 and results.count(429) == 30, results
            recreated = worker()
            with pytest.raises(recreated.HTTPException) as blocked:
                await recreated.consume_auth_limit("login-email", "race-0@example.com", 10, 900)
            assert blocked.value.status_code == 429
            records = await first.db.auth_attempts.find({}).to_list(100)
            assert len(records) == 5 and all(record["count"] == 10 for record in records)
        finally:
            await first.client.drop_database(os.environ["DB_NAME"])
            for module in workers:
                module.client.close()
    asyncio.run(exercise())
