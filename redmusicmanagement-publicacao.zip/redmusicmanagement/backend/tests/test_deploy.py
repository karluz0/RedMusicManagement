"""Regression tests for publishing. Uses an isolated in-memory database."""
import asyncio
import importlib.util
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from mongomock_motor import AsyncMongoMockClient


@pytest.fixture
def server(monkeypatch):
    monkeypatch.setenv("MONGO_URL", "mongodb://localhost:27017")
    monkeypatch.setenv("DB_NAME", "isolated_test")
    monkeypatch.setenv("JWT_SECRET", "isolated-test-secret-at-least-32-characters")
    monkeypatch.setenv("COOKIE_SECURE", "true")
    monkeypatch.delenv("ADMIN_EMAIL", raising=False)
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    spec = importlib.util.spec_from_file_location("deploy_server", Path(__file__).parents[1] / "server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.client.close()
    module.client = AsyncMongoMockClient()
    module.db = module.client["isolated_test"]
    return module


def test_public_registration_cannot_grant_management_access(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        for index, role in enumerate(["Líder", "Administrador", "unexpected"]):
            response = client.post("/api/auth/register", json={
                "email": f"person{index}@example.com", "password": "test-password-only",
                "name": "Teste", "role": role,
            })
            assert response.status_code == 200
            assert response.json()["role"] == "Voluntário"
            assert all("Secure" in cookie and "HttpOnly" in cookie
                       for cookie in response.headers.get_list("set-cookie"))
            assert client.post("/api/schedules", json={
                "name": "Blocked", "date": "2027-01-01", "time": "19:00"
            }).status_code == 403


def test_unknown_role_is_denied(server):
    async def verify():
        with pytest.raises(server.HTTPException) as error:
            await server.require_admin({"role": "unexpected"})
        assert error.value.status_code == 403
    asyncio.run(verify())


def test_no_default_admin_is_created(server):
    with TestClient(server.app, base_url="https://testserver"):
        assert asyncio.run(server.db.users.count_documents({})) == 0


def test_admin_bootstrap_does_not_reset_existing_password(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
    monkeypatch.setenv("ADMIN_PASSWORD", "different-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "different-test-password"
        }).status_code == 401


def test_health_and_frontend_routing(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/health").json() == {"status": "ok"}
        assert client.get("/api/not-found").status_code == 404
        assert (server.FRONTEND_BUILD / "index.html").is_file(), "Build frontend before running this test"
        assert "text/html" in client.get("/login").headers["content-type"]
        assert "text/html" in client.get("/schedules/example").headers["content-type"]
        assert client.get("/missing.js").status_code == 404


def test_health_reports_database_failure_without_exposing_connection(server, monkeypatch):
    async def unavailable(*args, **kwargs):
        raise RuntimeError("private connection details")

    with TestClient(server.app, base_url="https://testserver") as client:
        monkeypatch.setattr(server.db, "command", unavailable)
        response = client.get("/api/health")
        assert response.status_code == 503
        assert response.json() == {"status": "unavailable"}


@pytest.mark.parametrize("schedule_status", [
    "Rascunho", "Disponibilidade", "Em Validação", "unexpected", None,
    "Validado", "Fechada",
])
def test_public_schedule_visibility(server, schedule_status):
    document = {"id": "demo", "share_token": "demo-token", "ministry": "Red Music",
                "date": "2027-01-10"}
    if schedule_status is not None:
        document["status"] = schedule_status
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one(document))
        individual = client.get("/api/public/schedules/demo-token")
        monthly = client.get("/api/public/monthly/Red%20Music/2027-01")
        published = schedule_status in ("Validado", "Fechada")
        assert individual.status_code == (200 if published else 404)
        assert [s["id"] for s in monthly.json()["schedules"]] == (["demo"] if published else [])
        assert individual.headers["cache-control"] == "no-store"
        assert monthly.headers["cache-control"] == "no-store"
        if published:
            assert individual.json()["members"] == []
            assert individual.json()["setlist"] == []
        else:
            assert "demo-token" not in individual.text


def test_leader_can_publish_and_revoke_public_access(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one({
            "id": "demo", "share_token": "demo-token", "status": "Rascunho",
            "ministry": "Red Music", "date": "2027-01-10",
        }))
        client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password",
        }).raise_for_status()
        assert client.get("/api/schedules/demo").json()["status"] == "Rascunho"
        for schedule_status, expected in [("Validado", 200), ("Rascunho", 404)]:
            client.put("/api/schedules/demo", json={"status": schedule_status}).raise_for_status()
            assert client.get("/api/public/schedules/demo-token").status_code == expected
            schedules = client.get("/api/public/monthly/Red%20Music/2027-01").json()["schedules"]
            assert len(schedules) == (1 if expected == 200 else 0)
        assert client.get("/api/schedules/demo").status_code == 200


@pytest.fixture
def confirmation_accounts(server):
    async def seed():
        await server.db.volunteers.insert_many([
            {"id": "ana", "email": "ana@example.com", "status": "Ativo"},
            {"id": "bruno", "email": "bruno@example.com", "status": "Ativo"},
        ])
        await server.db.schedules.insert_many([
            {"id": "first", "status": "Validado"}, {"id": "second", "status": "Rascunho"},
        ])
        await server.db.schedule_members.insert_many([
            {"id": "ana-slot", "schedule_id": "first", "volunteer_id": "ana", "confirmation_status": "Pendente"},
            {"id": "bruno-slot", "schedule_id": "first", "volunteer_id": "bruno", "confirmation_status": "Pendente"},
        ])
        headers = {}
        for name, role in [("ana", "Voluntário"), ("bruno", "Voluntário"), ("leader", "Líder"), ("unknown", "unexpected")]:
            email = f"{name}@example.com"
            result = await server.db.users.insert_one({"email": email, "role": role})
            headers[name] = {"Authorization": "Bearer " + server.create_access_token(str(result.inserted_id), email, role)}
        return headers
    return asyncio.run(seed())


def test_only_linked_volunteer_can_respond_for_self(server, confirmation_accounts):
    headers = confirmation_accounts
    path = "/api/schedules/first/members/ana-slot"
    with TestClient(server.app, base_url="https://testserver") as client:
        data = {"confirmation_status": "Confirmado"}
        assert client.put(path, json=data).status_code == 401
        # Matching email is insufficient: the leadership must approve the link.
        assert client.put(path, json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).status_code == 200
        for status in ["Confirmado", "Preciso de Substituto", "Pendente"]:
            result = client.put(path, json={"confirmation_status": status}, headers=headers["ana"])
            assert result.status_code == 200
            assert result.json()["confirmation_status"] == status
        assert client.put(path, json=data, headers=headers["bruno"]).status_code == 403
        assert client.put("/api/schedules/first/members/bruno-slot", json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/second/members/ana-slot", json=data, headers=headers["ana"]).status_code == 404
        assert client.put(path, json={"confirmation_status": "inventado"}, headers=headers["ana"]).status_code == 422
        assert client.put(path, json={**data, "volunteer_id": "bruno"}, headers=headers["ana"]).status_code == 422
        detail = client.get("/api/schedules/first", headers=headers["ana"]).json()
        assert {m["id"]: m["can_confirm"] for m in detail["members"]} == {"ana-slot": True, "bruno-slot": False}
        assert client.delete("/api/schedules/first/members/ana-slot", headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/first", json={"status": "Rascunho"}, headers=headers["ana"]).status_code == 403
        assert client.put(path, json=data, headers=headers["leader"]).status_code == 200


def test_account_links_require_leadership_and_are_unique(server, confirmation_accounts):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for method in ["get", "put", "delete"]:
            kwargs = {"json": {"email": "ana@example.com"}} if method == "put" else {}
            assert getattr(client, method)("/api/volunteers/ana/account", headers=headers["ana"], **kwargs).status_code == 403
        link = lambda volunteer, email: client.put(f"/api/volunteers/{volunteer}/account", json={"email": email}, headers=headers["leader"])
        assert link("missing", "ana@example.com").status_code == 404
        assert link("ana", "missing@example.com").status_code == 404
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "bruno@example.com").status_code == 409
        assert link("bruno", "ana@example.com").status_code == 409
        assert client.get("/api/volunteers/ana/account", headers=headers["leader"]).json() == {"email": "ana@example.com"}
        assert client.delete("/api/volunteers/ana/account", headers=headers["leader"]).status_code == 200
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        assert link("ana", "bruno@example.com").status_code == 200


@pytest.mark.parametrize("condition", ["Inativo", "Afastado", "deleted", "unknown-role"])
def test_inactive_or_invalid_account_cannot_confirm(server, confirmation_accounts, condition):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).raise_for_status()
        if condition == "deleted":
            client.delete("/api/volunteers/ana", headers=headers["leader"]).raise_for_status()
            assert "volunteer_id" not in asyncio.run(server.db.users.find_one({"email": "ana@example.com"}))
        elif condition == "unknown-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": condition}}))
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        detail = client.get("/api/schedules/first", headers=headers["ana"]).json()
        assert all(not member["can_confirm"] for member in detail["members"])


PRIVATE_VOLUNTEER_PATHS = [
    "/api/volunteers",
    "/api/volunteers/ana",
    "/api/volunteers/bruno",
    "/api/schedules/first/available-volunteers",
    "/api/volunteers/ana/monthly-count/2027-01",
    "/api/volunteers/bruno/participation-history",
]


@pytest.fixture
def private_profiles(server, confirmation_accounts):
    async def enrich():
        for volunteer_id in ["ana", "bruno"]:
            await server.db.volunteers.update_one({"id": volunteer_id}, {"$set": {
                "name": volunteer_id.title(), "phone": "private-phone-123",
                "birth_date": "1990-04-02", "photo_url": "private-photo",
                "unavailability_dates": [{"date": "2027-02-01", "reason": "private-reason"}],
            }})
            await server.db.schedule_members.update_one({"volunteer_id": volunteer_id}, {"$set": {
                "volunteer_name": volunteer_id.title(), "function": "Vocal",
            }})
        for schedule_id in ["first", "second"]:
            await server.db.schedules.update_one({"id": schedule_id}, {"$set": {
                "name": "Exemplo", "date": "2027-01-10", "time": "19:00",
                "ministry": "Red Music", "share_token": f"token-{schedule_id}",
            }})
        # Even a linked account cannot access the administrative profiles.
        await server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"volunteer_id": "ana"}})
    asyncio.run(enrich())
    return confirmation_accounts


@pytest.mark.parametrize("account", [None, "ana", "unknown"])
def test_private_profiles_denied_before_returning_personal_data(server, private_profiles, account):
    headers = private_profiles[account] if account else {}
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=headers)
            assert response.status_code == (403 if account else 401), path
            assert response.headers["cache-control"] == "no-store"
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        # Missing identifiers must not reveal whether a profile exists either.
        assert client.get("/api/volunteers/missing", headers=headers).status_code == (403 if account else 401)


@pytest.mark.parametrize("role", ["Líder", "Administrador"])
def test_leadership_retains_private_management_access(server, private_profiles, role):
    asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": role}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=private_profiles["leader"])
            assert response.status_code == 200, path
            assert response.headers["cache-control"] == "no-store"
        profile = client.get("/api/volunteers/ana", headers=private_profiles["leader"]).json()
        assert profile["email"] == "ana@example.com"
        assert profile["phone"] == "private-phone-123"
        assert profile["unavailability_dates"][0]["reason"] == "private-reason"


def test_schedules_remain_usable_without_loading_private_profiles(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in ["/api/schedules", "/api/schedules/first", "/api/schedules/first/vocals",
                     "/api/public/schedules/token-first", "/api/public/monthly/Red%20Music/2027-01"]:
            response = client.get(path, headers=private_profiles["ana"])
            assert response.status_code == 200, path
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        detail = client.get("/api/schedules/first", headers=private_profiles["ana"]).json()
        assert detail["members"][0]["volunteer_name"] == "Ana"
        assert detail["members"][0]["function"] == "Vocal"
        assert detail["members"][0]["can_confirm"] is True
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=private_profiles["ana"]).status_code == 200


def test_private_access_revoked_when_role_changes(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/volunteers", headers=private_profiles["leader"]).status_code == 200
        asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": "Voluntário"}}))
        for path in PRIVATE_VOLUNTEER_PATHS:
            assert client.get(path, headers=private_profiles["leader"]).status_code == 403
