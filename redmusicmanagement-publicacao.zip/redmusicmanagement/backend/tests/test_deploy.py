"""Regression tests for publishing. Uses an isolated in-memory database."""
import asyncio
import importlib.util
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from mongomock_motor import AsyncMongoMockClient


@pytest.fixture
def server(monkeypatch):
    monkeypatch.setenv("MONGO_URL", "mongodb://localhost:27017")
    monkeypatch.setenv("DB_NAME", "isolated_test")
    monkeypatch.setenv("JWT_SECRET", "isolated-test-secret-at-least-32-characters")
    monkeypatch.setenv("COOKIE_SECURE", "true")
    monkeypatch.delenv("ADMIN_EMAIL", raising=False)
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    spec = importlib.util.spec_from_file_location("deploy_server", Path(__file__).parents[1] / "server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.client.close()
    module.client = AsyncMongoMockClient()
    module.db = module.client["isolated_test"]
    # Logic tests use mongomock; real transaction concurrency is tested separately.
    async def without_transaction(operation):
        return await operation(None)
    monkeypatch.setattr(module, "run_assignment_transaction", without_transaction)
    return module


def test_public_registration_cannot_grant_management_access(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        for index, role in enumerate(["Líder", "Administrador", "unexpected"]):
            response = client.post("/api/auth/register", json={
                "email": f"person{index}@example.com", "password": "test-password-only",
                "name": "Teste", "role": role,
            })
            assert response.status_code == 200
            assert response.json()["role"] == "Voluntário"
            assert all("Secure" in cookie and "HttpOnly" in cookie
                       for cookie in response.headers.get_list("set-cookie"))
            assert client.post("/api/schedules", json={
                "name": "Blocked", "date": "2027-01-01", "time": "19:00"
            }).status_code == 403


def test_unknown_role_is_denied(server):
    async def verify():
        with pytest.raises(server.HTTPException) as error:
            await server.require_admin({"role": "unexpected"})
        assert error.value.status_code == 403
    asyncio.run(verify())


@pytest.fixture
def reorder_context(server, private_profiles):
    async def seed():
        # The same song can legitimately occur twice, with distinct entry IDs.
        await server.db.setlists.insert_one({"schedule_id": "first", "songs": [
            {"id": "entry-a", "song_id": "same-song", "song_name": "Graça", "original_key": "C", "key_for_this_event": "D", "main_vocal_volunteer_id": "ana", "notes": "Preservar", "custom": {"arrangement": [1, 2]}, "order": 7},
            {"id": "entry-b", "song_id": "another-song", "song_name": "Esperança", "original_key": "G", "key_for_this_event": "A", "main_vocal_volunteer_id": "bruno", "order": 10},
            {"id": "entry-c", "song_id": "same-song", "song_name": "Graça", "key_for_this_event": "E", "main_vocal_volunteer_id": "bruno", "order": 12},
        ]})
        await server.db.setlists.insert_one({"schedule_id": "second", "songs": [{"id": "foreign-entry", "song_id": "other", "order": 1}]})
    asyncio.run(seed())
    return private_profiles


def test_reorder_changes_only_position_and_preserves_all_stored_metadata(server, reorder_context):
    original = asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))
    with TestClient(server.app, base_url="https://testserver") as client:
        body = {"song_entry_ids": ["entry-c", "entry-a", "entry-b"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}
        result = client.put("/api/setlists/first/reorder", json=body, headers=reorder_context["leader"])
        assert result.status_code == 200
        stored = asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))
        assert [entry["id"] for entry in stored["songs"]] == body["song_entry_ids"]
        assert [entry["order"] for entry in stored["songs"]] == [1, 2, 3]
        before = {entry["id"]: {k: v for k, v in entry.items() if k != "order"} for entry in original["songs"]}
        after = {entry["id"]: {k: v for k, v in entry.items() if k != "order"} for entry in stored["songs"]}
        assert before == after
        assert stored["_id"] == original["_id"]
        assert asyncio.run(server.db.setlists.find_one({"schedule_id": "second"}))["songs"][0]["id"] == "foreign-entry"


@pytest.mark.parametrize("ids,expected", [
    ([], 409), (["entry-a", "entry-b"], 409), (["entry-a", "entry-b", "foreign-entry"], 409),
    (["entry-a", "entry-b", "entry-c", "invented"], 409), (["entry-a", "entry-a", "entry-c"], 422),
    (["entry-a", "entry-b", ""], 422), (["entry-a", "entry-b", 123], 422),
])
def test_reorder_rejects_omissions_inventions_and_duplicates_without_writing(server, reorder_context, ids, expected):
    original = asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.put("/api/setlists/first/reorder", json={"song_entry_ids": ids, "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}, headers=reorder_context["leader"])
        assert result.status_code == expected
        assert asyncio.run(server.db.setlists.find_one({"schedule_id": "first"})) == original


@pytest.mark.parametrize("body", [
    {"songs": [{"id": "entry-a", "key_for_this_event": "FORGED"}]},
    {"song_entry_ids": ["entry-a", "entry-b", "entry-c"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"], "songs": []},
    {"song_entry_ids": ["entry-a", "entry-b", "entry-c"]},
])
def test_reorder_never_accepts_client_metadata_or_old_full_list_payload(server, reorder_context, body):
    original = asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.put("/api/setlists/first/reorder", json=body, headers=reorder_context["leader"]).status_code == 422
        assert asyncio.run(server.db.setlists.find_one({"schedule_id": "first"})) == original


def test_reorder_requires_leadership_and_existing_parent(server, reorder_context):
    body = {"song_entry_ids": ["entry-c", "entry-b", "entry-a"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.put("/api/setlists/first/reorder", json=body).status_code == 401
        assert client.put("/api/setlists/first/reorder", json=body, headers=reorder_context["ana"]).status_code == 403
        assert client.put("/api/setlists/missing/reorder", json=body, headers=reorder_context["leader"]).status_code == 404
        asyncio.run(server.db.setlists.delete_one({"schedule_id": "second"}))
        assert client.put("/api/setlists/second/reorder", json=body, headers=reorder_context["leader"]).status_code == 404


def test_stale_reorder_does_not_overwrite_another_leaders_order(server, reorder_context):
    with TestClient(server.app, base_url="https://testserver") as client:
        headers = reorder_context["leader"]
        first = {"song_entry_ids": ["entry-c", "entry-b", "entry-a"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}
        assert client.put("/api/setlists/first/reorder", json=first, headers=headers).status_code == 200
        stale = {"song_entry_ids": ["entry-b", "entry-a", "entry-c"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}
        assert client.put("/api/setlists/first/reorder", json=stale, headers=headers).status_code == 409
        assert [e["id"] for e in asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))["songs"]] == first["song_entry_ids"]


@pytest.mark.parametrize("change", ["add", "remove", "metadata", "delete-setlist"])
def test_atomic_reorder_does_not_lose_concurrent_changes(server, reorder_context, monkeypatch, change):
    collection = server.db.setlists
    monkeypatch.setattr(server.db, "setlists", collection)
    update = collection.update_one
    captured = []
    async def racing_update(query, update_doc, *args, **kwargs):
        if "$set" in update_doc and "songs" in update_doc["$set"]:
            if change == "add":
                await update({"schedule_id": "first"}, {"$push": {"songs": {"id": "new-entry", "song_id": "new", "order": 4}}})
            elif change == "remove":
                await update({"schedule_id": "first"}, {"$pull": {"songs": {"id": "entry-b"}}})
            elif change == "metadata":
                await update({"schedule_id": "first"}, {"$set": {"songs.0.key_for_this_event": "F#"}})
            else:
                await server.db.setlists.delete_one({"schedule_id": "first"})
            captured.append(await server.db.setlists.find_one({"schedule_id": "first"}))
        return await update(query, update_doc, *args, **kwargs)
    monkeypatch.setattr(collection, "update_one", racing_update)
    with TestClient(server.app, base_url="https://testserver") as client:
        body = {"song_entry_ids": ["entry-c", "entry-a", "entry-b"], "expected_entry_ids": ["entry-a", "entry-b", "entry-c"]}
        assert client.put("/api/setlists/first/reorder", json=body, headers=reorder_context["leader"]).status_code == 409
        assert len(captured) == 1
        assert asyncio.run(server.db.setlists.find_one({"schedule_id": "first"})) == captured[0]


@pytest.mark.parametrize("songs", [[{"song_id": "legacy"}], [{"id": "same"}, {"id": "same"}], None])
def test_legacy_entries_without_unique_ids_are_preserved(server, reorder_context, songs):
    asyncio.run(server.db.setlists.update_one({"schedule_id": "first"}, {"$set": {"songs": songs}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.put("/api/setlists/first/reorder", json={"song_entry_ids": [], "expected_entry_ids": []}, headers=reorder_context["leader"]).status_code == 409
        assert asyncio.run(server.db.setlists.find_one({"schedule_id": "first"}))["songs"] == songs


@pytest.mark.parametrize("value", ["2027-02-29", "2027-04-31", "2027-13-01", "0000-01-01", "20270101", "01/02/2027", "2027-1-02", "2027-01-02T19:00:00Z", "not-a-date", 123])
def test_invalid_schedule_dates_are_rejected_before_writes(server, confirmation_accounts, value):
    headers = confirmation_accounts["leader"]
    with TestClient(server.app, base_url="https://testserver") as client:
        total = asyncio.run(server.db.schedules.count_documents({}))
        assert client.post("/api/schedules", json={"name": "Teste", "date": value, "time": "19:00"}, headers=headers).status_code == 422
        assert client.put("/api/schedules/first", json={"date": value, "name": "Do not change"}, headers=headers).status_code == 422
        assert client.post("/api/schedules/batch", json={"dates": ["2099-01-10", value], "time": "19:00"}, headers=headers).status_code == 422
        assert asyncio.run(server.db.schedules.count_documents({})) == total
        stored = asyncio.run(server.db.schedules.find_one({"id": "first"}))
        assert "date" not in stored and "name" not in stored


@pytest.mark.parametrize("value", ["24:00", "12:60", "-1:00", "7:00", "19:00:01", "19:00Z", "", 1900])
def test_invalid_schedule_times_are_rejected_in_all_write_routes(server, confirmation_accounts, value):
    headers = confirmation_accounts["leader"]
    with TestClient(server.app, base_url="https://testserver") as client:
        total = asyncio.run(server.db.schedules.count_documents({}))
        assert client.post("/api/schedules", json={"name": "Teste", "date": "2099-01-01", "time": value}, headers=headers).status_code == 422
        assert client.put("/api/schedules/first", json={"time": value}, headers=headers).status_code == 422
        assert client.post("/api/schedules/batch", json={"dates": ["2099-01-01"], "time": value}, headers=headers).status_code == 422
        assert asyncio.run(server.db.schedules.count_documents({})) == total


def test_calendar_dates_times_and_known_statuses_remain_usable(server, confirmation_accounts):
    headers = confirmation_accounts["leader"]
    with TestClient(server.app, base_url="https://testserver") as client:
        created = client.post("/api/schedules", json={"name": "Ano bissexto", "date": "2028-02-29", "time": "00:00"}, headers=headers)
        assert created.status_code == 200
        sid = created.json()["id"]
        for status in ["Disponibilidade", "Rascunho", "Em Validação", "Validado", "Fechada"]:
            result = client.put(f"/api/schedules/{sid}", json={"status": status, "time": "23:59"}, headers=headers)
            assert result.status_code == 200
            assert result.json()["status"] == status
            assert result.json()["date"] == "2028-02-29" and result.json()["time"] == "23:59"
        assert client.post("/api/schedules/batch", json={"dates": []}, headers=headers).status_code == 422
        batch = client.post("/api/schedules/batch", json={"dates": ["2099-01-01", "2099-01-02"], "time": "00:00"}, headers=headers)
        assert batch.status_code == 200 and batch.json()["total_created"] == 2


@pytest.mark.parametrize("field,value", [("status", "Admin"), ("status", "Validado "), ("status", ""), ("phase", "anything")])
def test_volunteer_status_and_phase_allow_only_known_options(server, confirmation_accounts, field, value):
    headers = confirmation_accounts["leader"]
    with TestClient(server.app, base_url="https://testserver") as client:
        body = {"name": "Teste", "email": "new@example.com", "phone": "000", "birth_date": "2000-02-29", field: value}
        assert client.post("/api/volunteers", json=body, headers=headers).status_code == 422
        assert client.put("/api/volunteers/ana", json={field: value}, headers=headers).status_code == 422
        assert asyncio.run(server.db.volunteers.count_documents({})) == 2
        assert asyncio.run(server.db.volunteers.find_one({"id": "ana"}))["status"] == "Ativo"


@pytest.mark.parametrize("value", ["unexpected", "validado", "", "Ativo"])
def test_schedule_status_validation_preserves_previous_state(server, confirmation_accounts, value):
    with TestClient(server.app, base_url="https://testserver") as client:
        headers = confirmation_accounts["leader"]
        assert client.put("/api/schedules/first", json={"status": value}, headers=headers).status_code == 422
        assert client.post("/api/schedules", json={"name": "Teste", "date": "2099-01-01", "time": "19:00", "status": value}, headers=headers).status_code == 422
        assert asyncio.run(server.db.schedules.find_one({"id": "first"}))["status"] == "Validado"


@pytest.mark.parametrize("value", ["2001-02-29", "31/12/2000", "2000-12-31T00:00:00Z", "2099-01-01"])
def test_invalid_birth_dates_never_create_public_accounts_or_profiles(server, confirmation_accounts, value):
    with TestClient(server.app, base_url="https://testserver") as client:
        body = {"name": "Teste", "email": "new@example.com", "phone": "000", "birth_date": value, "password": "local-test-password"}
        users = asyncio.run(server.db.users.count_documents({}))
        assert client.post("/api/public/volunteers/register", json=body).status_code == 422
        assert client.post("/api/volunteers", json=body, headers=confirmation_accounts["leader"]).status_code == 422
        assert client.put("/api/volunteers/ana", json={"birth_date": value}, headers=confirmation_accounts["leader"]).status_code == 422
        assert asyncio.run(server.db.users.count_documents({})) == users
        assert asyncio.run(server.db.volunteers.count_documents({})) == 2


def test_birth_date_age_and_unavailability_use_valid_calendar_dates(server, confirmation_accounts, monkeypatch):
    monkeypatch.setattr(server, "local_today", lambda: server.date(2026, 10, 21))
    assert server.age_for_birth_date("2000-10-22") == 25
    assert server.age_for_birth_date("2000-10-21") == 26
    with TestClient(server.app, base_url="https://testserver") as client:
        headers = confirmation_accounts["leader"]
        assert client.put("/api/volunteers/ana", json={"birth_date": "2026-10-22"}, headers=headers).status_code == 422
        updated = client.put("/api/volunteers/ana", json={"birth_date": "2000-10-21"}, headers=headers)
        assert updated.status_code == 200 and updated.json()["age"] == 26
        assert client.post("/api/volunteers/ana/unavailability", json={"date": "2027-02-30"}, headers=headers).status_code == 422
        assert client.post("/api/volunteers/ana/unavailability", json={"date": "2028-02-29"}, headers=headers).status_code == 200


@pytest.mark.parametrize("year_month", ["2027-00", "2027-13", "2027-1", "2027-01.*", "0000-01"])
def test_public_monthly_rejects_invalid_month_and_regex_input(server, year_month):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get(f"/api/public/monthly/Red%20Music/{year_month}").status_code == 422


def test_batch_day_boundary_uses_sao_paulo_date(server, confirmation_accounts, monkeypatch):
    from datetime import datetime, timezone
    class BoundaryClock:
        @classmethod
        def now(cls, tz=None):
            return datetime(2027, 2, 1, 1, tzinfo=timezone.utc).astimezone(tz)
    monkeypatch.setattr(server, "datetime", BoundaryClock)
    assert server.local_today().isoformat() == "2027-01-31"
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.post("/api/schedules/batch", json={"dates": ["2027-01-31"], "time": "19:00"}, headers=confirmation_accounts["leader"])
        assert result.status_code == 200 and result.json()["total_created"] == 1


def test_refresh_recovers_expired_access_and_logout_revokes_session(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        client.post("/api/auth/register", json={"email": "session@example.com", "name": "Teste", "password": "local-test-password"}).raise_for_status()
        refresh = client.cookies.get("refresh_token")
        access = client.cookies.get("access_token")
        payload = server.jwt.decode(access, server.get_jwt_secret(), algorithms=[server.JWT_ALGORITHM])
        payload["exp"] = server.datetime.now(server.timezone.utc) - server.timedelta(seconds=1)
        expired_access = server.jwt.encode(payload, server.get_jwt_secret(), algorithm=server.JWT_ALGORITHM)
        client.cookies.clear()
        client.cookies.set("access_token", expired_access)
        client.cookies.set("refresh_token", refresh)
        assert client.get("/api/auth/me").status_code == 401
        session_before = asyncio.run(server.db.auth_sessions.find_one({}))
        assert refresh not in str(session_before)
        renewed = client.post("/api/auth/refresh", json={"role": "Administrador", "access_approved": True})
        assert renewed.status_code == 200
        assert renewed.json()["role"] == "Voluntário"
        assert renewed.json()["access_approved"] is False
        assert renewed.headers["cache-control"] == "no-store"
        assert len(renewed.headers.get_list("set-cookie")) == 1
        assert "Secure" in renewed.headers["set-cookie"] and "HttpOnly" in renewed.headers["set-cookie"]
        assert asyncio.run(server.db.auth_sessions.find_one({}))["expires_at"] == session_before["expires_at"]
        # Recreate the browser cookie jar after manually installing the expired test cookies.
        new_access = renewed.cookies.get("access_token")
        client.cookies.clear()
        client.cookies.set("access_token", new_access)
        client.cookies.set("refresh_token", refresh)
        assert client.get("/api/auth/me").status_code == 200
        assert client.get("/api/schedules").status_code == 403
        assert client.post("/api/auth/logout").status_code == 200
        assert asyncio.run(server.db.auth_sessions.count_documents({})) == 0
        client.cookies.clear()
        client.cookies.set("access_token", new_access)
        client.cookies.set("refresh_token", refresh)
        assert client.get("/api/auth/me").status_code == 401
        assert client.post("/api/auth/refresh").status_code == 401


@pytest.mark.parametrize("invalid", ["missing", "tampered", "expired", "access-type", "legacy", "unknown-session", "database-expired"])
def test_invalid_refresh_is_rejected_and_cookies_are_cleared(server, invalid):
    with TestClient(server.app, base_url="https://testserver") as client:
        registration = client.post("/api/auth/register", json={"email": "session@example.com", "name": "Teste", "password": "local-test-password"})
        registration.raise_for_status()
        token = client.cookies.get("refresh_token")
        payload = server.jwt.decode(token, server.get_jwt_secret(), algorithms=[server.JWT_ALGORITHM])
        if invalid == "tampered":
            token = token + "broken"
        elif invalid == "expired":
            payload["exp"] = server.datetime.now(server.timezone.utc) - server.timedelta(seconds=1)
        elif invalid == "access-type":
            payload["type"] = "access"
        elif invalid == "legacy":
            payload.pop("jti")
        elif invalid == "unknown-session":
            payload["jti"] = "unregistered"
        elif invalid == "database-expired":
            asyncio.run(server.db.auth_sessions.update_many({}, {"$set": {"expires_at": server.datetime.now(server.timezone.utc) - server.timedelta(seconds=1)}}))
        if invalid in ["expired", "access-type", "legacy", "unknown-session"]:
            token = server.jwt.encode(payload, server.get_jwt_secret(), algorithm=server.JWT_ALGORITHM)
        client.cookies.clear()
        if invalid != "missing":
            client.cookies.set("refresh_token", token)
        result = client.post("/api/auth/refresh")
        assert result.status_code == 401
        assert all("Max-Age=0" in cookie for cookie in result.headers.get_list("set-cookie"))


@pytest.mark.parametrize("change", ["Inativo", "Pendente", "Afastado", "unlinked", "deleted-profile", "deleted-account", "unexpected-role"])
def test_refresh_never_restores_revoked_permissions(server, change):
    async def seed():
        await server.db.volunteers.insert_one({"id": "ana", "status": "Ativo"})
        await server.db.users.insert_one({"email": "ana@example.com", "name": "Ana", "role": "Voluntário", "volunteer_id": "ana", "password_hash": server.hash_password("local-test-password")})
    asyncio.run(seed())
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={"email": "ana@example.com", "password": "local-test-password"}).json()["access_approved"] is True
        if change == "unlinked":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$unset": {"volunteer_id": ""}}))
        elif change == "deleted-profile":
            asyncio.run(server.db.volunteers.delete_one({"id": "ana"}))
        elif change == "deleted-account":
            asyncio.run(server.db.users.delete_one({"email": "ana@example.com"}))
        elif change == "unexpected-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": change}}))
        renewed = client.post("/api/auth/refresh")
        if change == "deleted-account":
            assert renewed.status_code == 401
        else:
            assert renewed.status_code == 200
            assert renewed.json()["access_approved"] is False
            assert client.get("/api/schedules").status_code == 403


def test_logout_works_with_expired_access_and_only_revokes_current_login(server):
    with TestClient(server.app, base_url="https://testserver") as first, TestClient(server.app, base_url="https://testserver") as second:
        first.post("/api/auth/register", json={"email": "session@example.com", "name": "Teste", "password": "local-test-password"}).raise_for_status()
        second.post("/api/auth/login", json={"email": "session@example.com", "password": "local-test-password"}).raise_for_status()
        refresh = first.cookies.get("refresh_token")
        first.cookies.clear()
        first.cookies.set("refresh_token", refresh)
        assert first.post("/api/auth/logout").status_code == 200
        assert first.post("/api/auth/logout").status_code == 200
        assert second.post("/api/auth/refresh").status_code == 200
        assert asyncio.run(server.db.auth_sessions.count_documents({})) == 1


def test_cross_origin_refresh_and_logout_are_denied(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        client.post("/api/auth/register", json={"email": "session@example.com", "name": "Teste", "password": "local-test-password"}).raise_for_status()
        for action in ["refresh", "logout"]:
            assert client.post(f"/api/auth/{action}", headers={"Origin": "https://untrusted.example"}).status_code == 403
        assert client.post("/api/auth/refresh", headers={"Origin": "https://testserver"}).status_code == 200


def test_availability_uses_authorized_link_not_matching_email(server, confirmation_accounts):
    headers = confirmation_accounts
    asyncio.run(server.db.volunteers.update_one({"id": "bruno"}, {"$set": {"name": "Bruno"}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        path = "/api/schedules/first/availability"
        assert client.post(path, json={"available": True}).status_code == 401
        assert client.post(path, json={"available": True}, headers=headers["ana"]).status_code == 403
        client.put("/api/volunteers/bruno/account", json={"email": "ana@example.com"}, headers=headers["leader"]).raise_for_status()
        for available in [False, True, False]:
            response = client.post(path, json={"available": available}, headers=headers["ana"])
            assert response.status_code == 200
            assert client.get("/api/schedules/first", headers=headers["ana"]).json()["own_availability"] is available
            records = asyncio.run(server.db.availability.find({"schedule_id": "first"}).to_list(None))
            assert len(records) == 1
            assert records[0]["volunteer_id"] == "bruno"
            assert records[0]["available"] is available
        for body in [{"available": "false"}, {"available": 1}, {"available": None},
                     {"available": True, "volunteer_id": "ana"}, {"available": True, "schedule_id": "second"}]:
            assert client.post(path, json=body, headers=headers["ana"]).status_code == 422
        assert client.post(path, json={"available": True}, headers=headers["leader"]).status_code == 403
        assert client.post("/api/schedules/second/availability", json={"available": True}, headers=headers["ana"]).status_code == 404
        assert client.post("/api/schedules/missing/availability", json={"available": True}, headers=headers["ana"]).status_code == 404
        asyncio.run(server.db.volunteers.update_one({"id": "bruno"}, {"$set": {"status": "Inativo"}}))
        assert client.post(path, json={"available": True}, headers=headers["ana"]).status_code == 403


@pytest.mark.parametrize("ana_response,bruno_response", [(None, None), (False, None), (False, False), (True, None), (True, False), (False, True)])
def test_selection_distinguishes_no_from_unanswered(server, private_profiles, ana_response, bruno_response):
    async def prepare():
        for person, response in [("ana", ana_response), ("bruno", bruno_response)]:
            if response is not None:
                await server.db.availability.insert_one({"schedule_id": "first", "volunteer_id": person, "available": response})
        # A yes for a different event must not change this event's selection.
        await server.db.availability.insert_one({"schedule_id": "second", "volunteer_id": "bruno", "available": True})
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/schedules/first/available-volunteers", headers=private_profiles["leader"])
        assert result.status_code == 200
        by_id = {person["id"]: person for person in result.json()}
        for person, response in [("ana", ana_response), ("bruno", bruno_response)]:
            assert (person in by_id) == (response is not False)
            if response is not False:
                assert by_id[person]["explicitly_available"] is (response is True)
                assert by_id[person]["availability_status"] == ("Disponível" if response is True else "Sem resposta")
        assert result.headers["cache-control"] == "no-store"
        # Date blocks override an explicit yes, and inactive people remain excluded.
        asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"unavailability_dates": [{"date": "2027-01-10"}]}}))
        asyncio.run(server.db.volunteers.update_one({"id": "bruno"}, {"$set": {"status": "Inativo"}}))
        assert client.get("/api/schedules/first/available-volunteers", headers=private_profiles["leader"]).json() == []


def test_registration_requires_explicit_approval_and_revocation_is_immediate(server, confirmation_accounts):
    leader = confirmation_accounts["leader"]
    with TestClient(server.app, base_url="https://testserver") as client, TestClient(server.app, base_url="https://testserver") as manager:
        registration = client.post("/api/public/volunteers/register", json={
            "name": "Nova pessoa", "email": "new@example.com", "password": "local-test-password",
            "birth_date": "1995-01-01", "phone": "000000000", "instruments": ["Vocal"],
        })
        registration.raise_for_status()
        volunteer_id = registration.json()["volunteer_id"]
        assert asyncio.run(server.db.volunteers.find_one({"id": volunteer_id}))["status"] == "Pendente"
        login = client.post("/api/auth/login", json={"email": "new@example.com", "password": "local-test-password"})
        assert login.json()["access_approved"] is False
        assert client.get("/api/auth/me").json()["access_approved"] is False
        paths = ["/api/schedules", "/api/schedules/first", "/api/setlists/first", "/api/schedules/first/vocals", "/api/songs", "/api/chat/contacts"]
        for path in paths:
            assert client.get(path).status_code == 403
        # Changing profile status alone or matching the e-mail never approves an account.
        manager.put(f"/api/volunteers/{volunteer_id}", json={"status": "Ativo"}, headers=leader).raise_for_status()
        assert client.get("/api/schedules").status_code == 403
        manager.put(f"/api/volunteers/{volunteer_id}", json={"status": "Pendente"}, headers=leader).raise_for_status()
        manager.put(f"/api/volunteers/{volunteer_id}/account", json={"email": "new@example.com"}, headers=leader).raise_for_status()
        assert asyncio.run(server.db.volunteers.find_one({"id": volunteer_id}))["status"] == "Ativo"
        assert client.get("/api/auth/me").json()["access_approved"] is True
        for path in paths[:-1]:
            assert client.get(path).status_code == 200
        manager.delete(f"/api/volunteers/{volunteer_id}/account", headers=leader).raise_for_status()
        assert client.get("/api/auth/me").json()["access_approved"] is False
        assert client.get("/api/schedules").status_code == 403
        assert client.post("/api/auth/logout").status_code == 200


def test_generic_signup_is_pending_and_cannot_self_approve(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        response = client.post("/api/auth/register", json={
            "name": "Teste", "email": "new@example.com", "password": "local-test-password",
            "role": "Administrador", "access_approved": True, "volunteer_id": "ana",
        })
        assert response.json()["access_approved"] is False
        assert client.get("/api/schedules").status_code == 403
        assert client.post("/api/auth/logout").status_code == 200


@pytest.mark.parametrize("schedule_status", ["Rascunho", "unexpected", None, "Disponibilidade", "Em Validação", "Validado", "Fechada"])
def test_approved_volunteer_cannot_read_drafts_through_alternate_routes(server, confirmation_accounts, schedule_status):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).raise_for_status()
        asyncio.run(server.db.schedules.update_one({"id": "second"}, {"$set": {"status": schedule_status}}))
        asyncio.run(server.db.setlists.insert_one({"schedule_id": "second", "songs": [{"song_id": "secret"}]}))
        expected = 200 if schedule_status in ("Disponibilidade", "Em Validação", "Validado", "Fechada") else 404
        for path in ["/api/schedules/second", "/api/setlists/second", "/api/schedules/second/vocals"]:
            response = client.get(path, headers=headers["ana"])
            assert response.status_code == expected
            assert response.headers["cache-control"] == "no-store"
            assert client.get(path, headers=headers["leader"]).status_code == 200
        ids = [s["id"] for s in client.get("/api/schedules", headers=headers["ana"]).json()]
        assert ("second" in ids) == (expected == 200)


def test_no_default_admin_is_created(server):
    with TestClient(server.app, base_url="https://testserver"):
        assert asyncio.run(server.db.users.count_documents({})) == 0


def test_admin_bootstrap_does_not_reset_existing_password(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
    monkeypatch.setenv("ADMIN_PASSWORD", "different-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "different-test-password"
        }).status_code == 401


def test_health_and_frontend_routing(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/health").json() == {"status": "ok"}
        assert client.get("/api/not-found").status_code == 404
        assert (server.FRONTEND_BUILD / "index.html").is_file(), "Build frontend before running this test"
        assert "text/html" in client.get("/login").headers["content-type"]
        assert "text/html" in client.get("/schedules/example").headers["content-type"]
        assert client.get("/missing.js").status_code == 404


def test_health_reports_database_failure_without_exposing_connection(server, monkeypatch):
    async def unavailable(*args, **kwargs):
        raise RuntimeError("private connection details")

    with TestClient(server.app, base_url="https://testserver") as client:
        monkeypatch.setattr(server.db, "command", unavailable)
        response = client.get("/api/health")
        assert response.status_code == 503
        assert response.json() == {"status": "unavailable"}


@pytest.mark.parametrize("schedule_status", [
    "Rascunho", "Disponibilidade", "Em Validação", "unexpected", None,
    "Validado", "Fechada",
])
def test_public_schedule_visibility(server, schedule_status):
    document = {"id": "demo", "share_token": "demo-token", "ministry": "Red Music",
                "date": "2027-01-10"}
    if schedule_status is not None:
        document["status"] = schedule_status
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one(document))
        individual = client.get("/api/public/schedules/demo-token")
        monthly = client.get("/api/public/monthly/Red%20Music/2027-01")
        published = schedule_status in ("Validado", "Fechada")
        assert individual.status_code == (200 if published else 404)
        assert [s["id"] for s in monthly.json()["schedules"]] == (["demo"] if published else [])
        assert individual.headers["cache-control"] == "no-store"
        assert monthly.headers["cache-control"] == "no-store"
        if published:
            assert individual.json()["members"] == []
            assert individual.json()["setlist"] == []
        else:
            assert "demo-token" not in individual.text


def test_leader_can_publish_and_revoke_public_access(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one({
            "id": "demo", "share_token": "demo-token", "status": "Rascunho",
            "ministry": "Red Music", "date": "2027-01-10",
        }))
        client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password",
        }).raise_for_status()
        assert client.get("/api/schedules/demo").json()["status"] == "Rascunho"
        for schedule_status, expected in [("Validado", 200), ("Rascunho", 404)]:
            client.put("/api/schedules/demo", json={"status": schedule_status}).raise_for_status()
            assert client.get("/api/public/schedules/demo-token").status_code == expected
            schedules = client.get("/api/public/monthly/Red%20Music/2027-01").json()["schedules"]
            assert len(schedules) == (1 if expected == 200 else 0)
        assert client.get("/api/schedules/demo").status_code == 200


@pytest.fixture
def confirmation_accounts(server):
    async def seed():
        await server.db.volunteers.insert_many([
            {"id": "ana", "email": "ana@example.com", "status": "Ativo"},
            {"id": "bruno", "email": "bruno@example.com", "status": "Ativo"},
        ])
        await server.db.schedules.insert_many([
            {"id": "first", "status": "Validado"}, {"id": "second", "status": "Rascunho"},
        ])
        await server.db.schedule_members.insert_many([
            {"id": "ana-slot", "schedule_id": "first", "volunteer_id": "ana", "confirmation_status": "Pendente"},
            {"id": "bruno-slot", "schedule_id": "first", "volunteer_id": "bruno", "confirmation_status": "Pendente"},
        ])
        headers = {}
        for name, role in [("ana", "Voluntário"), ("bruno", "Voluntário"), ("leader", "Líder"), ("unknown", "unexpected")]:
            email = f"{name}@example.com"
            result = await server.db.users.insert_one({"email": email, "role": role})
            headers[name] = {"Authorization": "Bearer " + server.create_access_token(str(result.inserted_id), email, role)}
        return headers
    return asyncio.run(seed())


def test_only_linked_volunteer_can_respond_for_self(server, confirmation_accounts):
    headers = confirmation_accounts
    path = "/api/schedules/first/members/ana-slot"
    with TestClient(server.app, base_url="https://testserver") as client:
        data = {"confirmation_status": "Confirmado"}
        assert client.put(path, json=data).status_code == 401
        # Matching email is insufficient: the leadership must approve the link.
        assert client.put(path, json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).status_code == 200
        for status in ["Confirmado", "Preciso de Substituto", "Pendente"]:
            result = client.put(path, json={"confirmation_status": status}, headers=headers["ana"])
            assert result.status_code == 200
            assert result.json()["confirmation_status"] == status
        assert client.put(path, json=data, headers=headers["bruno"]).status_code == 403
        assert client.put("/api/schedules/first/members/bruno-slot", json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/second/members/ana-slot", json=data, headers=headers["ana"]).status_code == 404
        assert client.put(path, json={"confirmation_status": "inventado"}, headers=headers["ana"]).status_code == 422
        assert client.put(path, json={**data, "volunteer_id": "bruno"}, headers=headers["ana"]).status_code == 422
        detail = client.get("/api/schedules/first", headers=headers["ana"]).json()
        assert {m["id"]: m["can_confirm"] for m in detail["members"]} == {"ana-slot": True, "bruno-slot": False}
        assert client.delete("/api/schedules/first/members/ana-slot", headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/first", json={"status": "Rascunho"}, headers=headers["ana"]).status_code == 403
        assert client.put(path, json=data, headers=headers["leader"]).status_code == 200


def test_account_links_require_leadership_and_are_unique(server, confirmation_accounts):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for method in ["get", "put", "delete"]:
            kwargs = {"json": {"email": "ana@example.com"}} if method == "put" else {}
            assert getattr(client, method)("/api/volunteers/ana/account", headers=headers["ana"], **kwargs).status_code == 403
        link = lambda volunteer, email: client.put(f"/api/volunteers/{volunteer}/account", json={"email": email}, headers=headers["leader"])
        assert link("missing", "ana@example.com").status_code == 404
        assert link("ana", "missing@example.com").status_code == 404
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "bruno@example.com").status_code == 409
        assert link("bruno", "ana@example.com").status_code == 409
        assert client.get("/api/volunteers/ana/account", headers=headers["leader"]).json() == {"email": "ana@example.com"}
        assert client.delete("/api/volunteers/ana/account", headers=headers["leader"]).status_code == 200
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        assert link("ana", "bruno@example.com").status_code == 200


@pytest.mark.parametrize("condition", ["Inativo", "Afastado", "deleted", "unknown-role"])
def test_inactive_or_invalid_account_cannot_confirm(server, confirmation_accounts, condition):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).raise_for_status()
        if condition == "deleted":
            client.delete("/api/volunteers/ana", headers=headers["leader"]).raise_for_status()
            assert "volunteer_id" not in asyncio.run(server.db.users.find_one({"email": "ana@example.com"}))
        elif condition == "unknown-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": condition}}))
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        assert client.get("/api/schedules/first", headers=headers["ana"]).status_code == 403


PRIVATE_VOLUNTEER_PATHS = [
    "/api/volunteers",
    "/api/volunteers/ana",
    "/api/volunteers/bruno",
    "/api/schedules/first/available-volunteers",
    "/api/volunteers/ana/monthly-count/2027-01",
    "/api/volunteers/bruno/participation-history",
]


@pytest.fixture
def private_profiles(server, confirmation_accounts):
    async def enrich():
        for volunteer_id in ["ana", "bruno"]:
            await server.db.volunteers.update_one({"id": volunteer_id}, {"$set": {
                "name": volunteer_id.title(), "phone": "private-phone-123",
                "birth_date": "1990-04-02", "photo_url": "private-photo",
                "unavailability_dates": [{"date": "2027-02-01", "reason": "private-reason"}],
            }})
            await server.db.schedule_members.update_one({"volunteer_id": volunteer_id}, {"$set": {
                "volunteer_name": volunteer_id.title(), "function": "Vocal",
            }})
        for schedule_id in ["first", "second"]:
            await server.db.schedules.update_one({"id": schedule_id}, {"$set": {
                "name": "Exemplo", "date": "2027-01-10", "time": "19:00",
                "ministry": "Red Music", "share_token": f"token-{schedule_id}",
            }})
        # Even a linked account cannot access the administrative profiles.
        await server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"volunteer_id": "ana"}})
    asyncio.run(enrich())
    return confirmation_accounts


@pytest.mark.parametrize("account", [None, "ana", "unknown"])
def test_private_profiles_denied_before_returning_personal_data(server, private_profiles, account):
    headers = private_profiles[account] if account else {}
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=headers)
            assert response.status_code == (403 if account else 401), path
            assert response.headers["cache-control"] == "no-store"
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        # Missing identifiers must not reveal whether a profile exists either.
        assert client.get("/api/volunteers/missing", headers=headers).status_code == (403 if account else 401)


@pytest.mark.parametrize("role", ["Líder", "Administrador"])
def test_leadership_retains_private_management_access(server, private_profiles, role):
    asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": role}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=private_profiles["leader"])
            assert response.status_code == 200, path
            assert response.headers["cache-control"] == "no-store"
        profile = client.get("/api/volunteers/ana", headers=private_profiles["leader"]).json()
        assert profile["email"] == "ana@example.com"
        assert profile["phone"] == "private-phone-123"
        assert profile["unavailability_dates"][0]["reason"] == "private-reason"


def test_schedules_remain_usable_without_loading_private_profiles(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in ["/api/schedules", "/api/schedules/first", "/api/schedules/first/vocals",
                     "/api/public/schedules/token-first", "/api/public/monthly/Red%20Music/2027-01"]:
            response = client.get(path, headers=private_profiles["ana"])
            assert response.status_code == 200, path
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        detail = client.get("/api/schedules/first", headers=private_profiles["ana"]).json()
        assert detail["members"][0]["volunteer_name"] == "Ana"
        assert detail["members"][0]["function"] == "Vocal"
        assert detail["members"][0]["can_confirm"] is True
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=private_profiles["ana"]).status_code == 200


def test_private_access_revoked_when_role_changes(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/volunteers", headers=private_profiles["leader"]).status_code == 200
        asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": "Voluntário"}}))
        for path in PRIVATE_VOLUNTEER_PATHS:
            assert client.get(path, headers=private_profiles["leader"]).status_code == 403


@pytest.fixture
def chat_accounts(server, private_profiles):
    async def seed():
        await server.db.users.update_one({"email": "bruno@example.com"}, {"$set": {"volunteer_id": "bruno"}})
        await server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"name": "Liderança A"}})
        await server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"name": "Nome informado na conta"}})
        headers = dict(private_profiles)
        for name, role in [("admin", "Administrador"), ("unlinked", "Voluntário")]:
            email = f"{name}@example.com"
            result = await server.db.users.insert_one({"email": email, "role": role, "name": name.title()})
            headers[name] = {"Authorization": "Bearer " + server.create_access_token(str(result.inserted_id), email, role)}
        ids = {}
        for name in headers:
            account = await server.db.users.find_one({"email": f"{name}@example.com"})
            ids[name] = str(account["_id"])
        return headers, ids
    return asyncio.run(seed())


def test_chat_contacts_use_accounts_without_personal_profiles(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for account, expected in [("ana", {ids["leader"], ids["admin"]}),
                                  ("leader", {ids["ana"], ids["bruno"], ids["admin"]})]:
            response = client.get("/api/chat/contacts", headers=headers[account])
            assert response.status_code == 200
            assert response.headers["cache-control"] == "no-store"
            assert {contact["id"] for contact in response.json()} == expected
            assert all(set(contact) == {"id", "name", "role"} for contact in response.json())
            assert "@example.com" not in response.text
            assert "private-" not in response.text
        ana = next(contact for contact in client.get("/api/chat/contacts", headers=headers["leader"]).json() if contact["id"] == ids["ana"])
        assert ana["name"] == "Ana"


@pytest.mark.parametrize("account, expected", [(None, 401), ("unlinked", 403), ("unknown", 403)])
def test_chat_rejects_ineligible_accounts(server, chat_accounts, account, expected):
    headers, ids = chat_accounts
    auth = headers[account] if account else {}
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/chat/contacts", headers=auth).status_code == expected
        response = client.get(f'/api/chat/messages/{ids["leader"]}', headers=auth)
        assert response.status_code == expected
        assert response.headers["cache-control"] == "no-store"
        assert client.post("/api/chat/messages", json={"to_user_id": ids["leader"], "message": "Teste"}, headers=auth).status_code == expected
        assert asyncio.run(server.db.chat_messages.count_documents({})) == 0


def test_chat_delivers_both_directions_and_isolates_conversations(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        def send(sender, recipient, message):
            response = client.post("/api/chat/messages", json={"to_user_id": ids[recipient], "message": message}, headers=headers[sender])
            assert response.status_code == 200
            assert response.headers["cache-control"] == "no-store"
            assert response.json()["from_user_id"] == ids[sender]
            assert response.json()["to_user_id"] == ids[recipient]
            return response.json()
        send("leader", "ana", "  Olá Ana  ")
        reply = send("ana", "leader", "Confirmo o ensaio")
        assert reply["from_user_name"] == "Ana"
        send("leader", "bruno", "Conversa reservada com Bruno")
        ana_history = client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).json()
        leader_history = client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["leader"]).json()
        assert ana_history == leader_history
        assert [message["message"] for message in ana_history] == ["Olá Ana", "Confirmo o ensaio"]
        assert client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["admin"]).json() == []
        assert client.get(f'/api/chat/messages/{ids["bruno"]}', headers=headers["ana"]).status_code == 404
        assert client.post("/api/chat/messages", json={"to_user_id": ids["bruno"], "message": "Indevido"}, headers=headers["ana"]).status_code == 404


def test_chat_validates_recipient_content_and_sender(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for target in ["not-an-account", "0123456789abcdef01234567", ids["leader"], ids["leader"].upper(), ids["unlinked"], ids["unknown"]]:
            response = client.post("/api/chat/messages", json={"to_user_id": target, "message": "Teste"}, headers=headers["leader"])
            assert response.status_code == 404
            assert response.json()["detail"] == "Contato indisponível"
            assert client.get(f"/api/chat/messages/{target}", headers=headers["leader"]).status_code == 404
        for message in ["", " \n\t ", "a" * 2001]:
            assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": message}, headers=headers["leader"]).status_code == 422
        assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Teste", "from_user_id": ids["admin"]}, headers=headers["leader"]).status_code == 422
        assert asyncio.run(server.db.chat_messages.count_documents({})) == 0


@pytest.mark.parametrize("condition", ["unlinked", "Inativo", "Afastado", "unknown-role"])
def test_chat_access_is_revoked_with_account_eligibility(server, chat_accounts, condition):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Antes da revogação"}, headers=headers["leader"]).raise_for_status()
        if condition == "unlinked":
            client.delete("/api/volunteers/ana/account", headers=headers["leader"]).raise_for_status()
        elif condition == "unknown-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": condition}}))
        assert client.get("/api/chat/contacts", headers=headers["ana"]).status_code == 403
        assert client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).status_code == 403
        assert client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["leader"]).status_code == 404
        assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Depois"}, headers=headers["leader"]).status_code == 404
        assert ids["ana"] not in {contact["id"] for contact in client.get("/api/chat/contacts", headers=headers["leader"]).json()}


def test_chat_returns_recent_history_without_assigning_legacy_messages(server, chat_accounts):
    from datetime import datetime, timedelta, timezone
    headers, ids = chat_accounts
    async def seed():
        start = datetime(2027, 1, 1, tzinfo=timezone.utc)
        await server.db.chat_messages.insert_many([
            {"id": f"message-{index}", "from_user_id": ids["leader"], "to_user_id": ids["ana"],
             "message": str(index), "timestamp": start + timedelta(seconds=index)}
            for index in range(105)
        ])
        await server.db.chat_messages.insert_one({"id": "legacy", "from_user_id": ids["leader"],
            "to_user_id": "ana", "message": "Endereço antigo sem vínculo confiável", "timestamp": start + timedelta(days=1)})
    asyncio.run(seed())
    with TestClient(server.app, base_url="https://testserver") as client:
        history = client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).json()
        assert [message["message"] for message in history] == [str(index) for index in range(5, 105)]
        assert asyncio.run(server.db.chat_messages.count_documents({"id": "legacy"})) == 1


@pytest.mark.parametrize("status, expected", [
    ("Em Validação", 1), ("Validado", 1), ("Fechada", 1),
    ("Rascunho", 0), ("Disponibilidade", 0), ("unexpected", 0), (None, 0),
])
def test_monthly_participation_uses_consistent_schedule_statuses(server, private_profiles, status, expected):
    async def prepare():
        await server.db.schedules.update_one({"id": "first"}, {"$set": {"status": status}})
        # Two functions in the same event still count as one schedule.
        await server.db.schedule_members.insert_one({"id": "ana-extra", "schedule_id": "first", "volunteer_id": "ana", "function": "Violão"})
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        count = client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"])
        assert count.status_code == 200
        assert count.json()["count"] == expected
        available = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        ana = next(person for person in available if person["id"] == "ana")
        assert ana["monthly_schedule_count"] == expected
        assert ana["is_exhausted"] is False


def test_monthly_participation_counts_distinct_events_and_month_boundaries(server, private_profiles):
    async def prepare():
        await server.db.schedules.insert_many([
            {"id": "same-day", "date": "2027-01-10", "status": "Fechada", "ministry": "Pulse Music"},
            {"id": "previous-month", "date": "2026-12-31", "status": "Validado"},
            {"id": "next-month", "date": "2027-02-01", "status": "Validado"},
            {"id": "other-year", "date": "2026-01-10", "status": "Validado"},
            {"id": "malformed", "date": "2027-010-10", "status": "Validado"},
        ])
        await server.db.volunteers.insert_one({"id": "clara", "name": "Clara", "status": "Ativo"})
        await server.db.schedule_members.insert_many([
            {"id": f"member-{schedule}", "schedule_id": schedule, "volunteer_id": "ana"}
            for schedule in ["same-day", "previous-month", "next-month", "other-year", "malformed", "deleted-schedule", "second"]
        ])
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        counts = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        by_id = {person["id"]: person for person in counts}
        assert by_id["ana"]["monthly_schedule_count"] == 2
        assert by_id["ana"]["is_exhausted"] is True
        assert by_id["bruno"]["monthly_schedule_count"] == 1
        assert by_id["bruno"]["is_exhausted"] is False
        assert by_id["clara"]["monthly_schedule_count"] == 0
        for person in counts:
            result = client.get(f'/api/volunteers/{person["id"]}/monthly-count/2027-01', headers=private_profiles["leader"])
            assert result.json()["count"] == person["monthly_schedule_count"]
        assert client.get("/api/volunteers/ana/monthly-count/2026-12", headers=private_profiles["leader"]).json()["count"] == 1
        assert client.get("/api/volunteers/ana/monthly-count/2027-02", headers=private_profiles["leader"]).json()["count"] == 1
        # Status edits and removal must update both views immediately.
        client.put("/api/schedules/first", json={"status": "Rascunho"}, headers=private_profiles["leader"]).raise_for_status()
        assert client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"]).json()["count"] == 1
        client.delete("/api/schedules/same-day", headers=private_profiles["leader"]).raise_for_status()
        assert client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"]).json()["count"] == 0
        available = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        assert next(person for person in available if person["id"] == "ana")["is_exhausted"] is False


@pytest.mark.parametrize("year_month", ["2027-00", "2027-13", "2027-1", "2027-01.*"])
def test_monthly_participation_rejects_invalid_months(server, private_profiles, year_month):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get(f"/api/volunteers/ana/monthly-count/{year_month}", headers=private_profiles["leader"]).status_code == 422


@pytest.fixture
def streak_context(server, private_profiles, monkeypatch):
    from datetime import datetime, timezone
    reference = datetime(2027, 1, 31, 12, tzinfo=timezone.utc)
    class FixedClock:
        @classmethod
        def now(cls, tz=None):
            return reference
    monkeypatch.setattr(server, "datetime", FixedClock)
    asyncio.run(server.db.schedules.delete_many({}))
    asyncio.run(server.db.schedule_members.delete_many({}))

    def seed(events):
        async def insert():
            for index, item in enumerate(events):
                event = {"id": f"event-{index}", "status": "Validado", "ministry": "Red Music", "time": "19:00", **item}
                attendees = event.pop("attendees", ["ana"])
                await server.db.schedules.insert_one(event)
                for attendee_index, person in enumerate(attendees):
                    await server.db.schedule_members.insert_one({
                        "id": f'{event["id"]}-{person}-{attendee_index}', "schedule_id": event["id"],
                        "volunteer_id": person, "volunteer_name": "Nome antigo", "function": "Vocal",
                    })
        asyncio.run(insert())
    return private_profiles, seed


def test_streak_reports_current_sequence_with_dates_and_no_duplicate_functions(server, streak_context):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    asyncio.run(server.db.schedule_members.insert_one({"id": "duplicate-function", "schedule_id": "event-3", "volunteer_id": "ana", "function": "Violão"}))
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"])
        assert result.status_code == 200
        assert result.headers["cache-control"] == "no-store"
        assert result.json() == [{"volunteer_id": "ana", "name": "Ana", "consecutive_schedules": 4,
                                  "ministry": "Red Music", "first_date": "2027-01-10", "last_date": "2027-01-31"}]
        # A new program where Ana rests ends her current streak.
        asyncio.run(server.db.schedules.insert_one({"id": "rest", "date": "2027-02-07", "time": "19:00", "status": "Validado", "ministry": "Red Music"}))
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


@pytest.mark.parametrize("events", [
    [{"date": "2027-01-03"}, {"date": "2027-01-10"}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-03"}, {"date": "2027-01-10"}, {"date": "2027-01-17", "attendees": ["bruno"]}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-31", "attendees": ["ana"] * 4}],
    [{"date": "2027-01-17"}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-10"}, {"date": "2027-01-17"}, {"date": "2027-01-24"}, {"date": "2027-01-31", "ministry": "Pulse Music"}],
])
def test_streak_does_not_confuse_history_repetition_gaps_or_ministries(server, streak_context, events):
    headers, seed = streak_context
    seed(events)
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


@pytest.mark.parametrize("status, expected", [("Em Validação", 1), ("Validado", 1), ("Fechada", 1), ("Rascunho", 0), ("Disponibilidade", 0), ("unexpected", 0), (None, 0)])
def test_streak_uses_committed_schedule_statuses(server, streak_context, status, expected):
    headers, seed = streak_context
    seed([{"date": day, "status": status} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert len(client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()) == expected


def test_drafts_and_other_ministries_do_not_interrupt_a_real_streak(server, streak_context):
    headers, seed = streak_context
    seed(
        [{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]]
        + [{"date": "2027-01-29", "status": "Rascunho", "attendees": []},
           {"date": "2027-01-30", "ministry": "Pulse Music", "attendees": ["bruno"]}]
    )
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()
        assert len(result) == 1
        assert result[0]["ministry"] == "Red Music"
        assert result[0]["consecutive_schedules"] == 4


def test_streak_ignores_unrelated_events_and_chooses_longest_current_ministry(server, streak_context):
    headers, seed = streak_context
    seed(
        [{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]]
        + [{"date": "2027-01-28", "attendees": [], "status": "Rascunho"},
           {"date": "not-a-date", "attendees": []},
           {"date": "2027-01-28", "ministry": "Other Music", "attendees": ["bruno"]}]
        + [{"date": day, "ministry": "Pulse Music"} for day in ["2027-02-07", "2027-02-14", "2027-02-21", "2027-02-28", "2027-03-07"]]
    )
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()
        assert len(result) == 1
        assert result[0]["ministry"] == "Pulse Music"
        assert result[0]["consecutive_schedules"] == 5


@pytest.mark.parametrize("days, expected", [
    (["2027-01-03", "2027-01-10", "2027-01-17", "2027-01-24"], 1),
    (["2027-01-02", "2027-01-09", "2027-01-16", "2027-01-23"], 0),
    (["2027-02-07", "2027-02-14", "2027-02-21", "2027-02-28"], 1),
])
def test_streak_only_reports_recent_or_future_sequences(server, streak_context, days, expected):
    headers, seed = streak_context
    seed([{"date": day} for day in days])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert len(client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()) == expected


@pytest.mark.parametrize("status", ["Inativo", "Afastado", "deleted"])
def test_streak_excludes_inactive_and_deleted_people(server, streak_context, status):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    if status == "deleted":
        asyncio.run(server.db.volunteers.delete_one({"id": "ana"}))
    else:
        asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": status}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


def test_streak_remains_restricted_to_leadership(server, streak_context):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert").status_code == 401
        for person in ["ana", "unknown"]:
            assert client.get("/api/dashboard/burnout-alert", headers=headers[person]).status_code == 403


@pytest.fixture
def music_context(server, streak_context):
    headers, _ = streak_context
    async def seed():
        await server.db.songs.insert_many([
            {"id": "a", "name": "Canção A", "original_key": "C", "play_count": 999, "last_played_date": "2050-01-01"},
            {"id": "b", "name": "Canção B", "original_key": "D", "play_count": 0},
            {"id": "c", "name": "Sem uso", "original_key": "E", "play_count": 500},
        ])
        for event_id, day, status in [("past1", "2027-01-10", "Validado"), ("past2", "2027-01-24", "Fechada"),
                                      ("draft", "2027-01-30", "Rascunho"), ("today", "2027-01-31", "Validado"),
                                      ("future", "2027-02-01", "Validado"), ("validation", "2027-01-25", "Em Validação")]:
            await server.db.schedules.insert_one({"id": event_id, "date": day, "status": status, "share_token": event_id, "ministry": "Red Music"})
            songs = [{"id": f"{event_id}-a", "song_id": "a"}]
            if event_id == "past2":
                songs += [{"id": "repeat-a", "song_id": "a"}, {"id": "past2-b", "song_id": "b"}]
            await server.db.setlists.insert_one({"schedule_id": event_id, "songs": songs})
        await server.db.setlists.insert_one({"schedule_id": "deleted", "songs": [{"song_id": "c"}]})
    asyncio.run(seed())
    return headers


def test_song_usage_is_derived_from_distinct_past_published_events(server, music_context):
    with TestClient(server.app, base_url="https://testserver") as client:
        ranking = client.get("/api/dashboard/top-songs", headers=music_context["leader"])
        assert ranking.status_code == 200
        assert [(song["id"], song["play_count"]) for song in ranking.json()] == [("a", 2), ("b", 1)]
        songs = client.get("/api/songs", headers=music_context["ana"])
        assert songs.headers["cache-control"] == "no-store"
        by_id = {song["id"]: song for song in songs.json()}
        assert by_id["a"]["last_played_date"] == "2027-01-24"
        assert by_id["c"]["play_count"] == 0
        assert by_id["c"]["last_played_date"] is None
        assert client.get("/api/songs/a", headers=music_context["ana"]).json() == by_id["a"]
        public = client.get("/api/public/schedules/past2").json()
        assert public["setlist"][0]["song_full"]["play_count"] == 2
        monthly = client.get("/api/public/monthly/Red%20Music/2027-01").json()
        for event in monthly["schedules"]:
            for entry in event["setlist"]:
                assert entry["song_full"]["play_count"] == by_id[entry["song_id"]]["play_count"]


def test_song_usage_follows_setlist_status_and_schedule_changes(server, music_context):
    headers = music_context["leader"]
    with TestClient(server.app, base_url="https://testserver") as client:
        added = client.post("/api/setlists/draft/songs", json={"song_id": "a", "order": 2}, headers=headers)
        assert added.status_code == 200
        assert asyncio.run(server.db.songs.find_one({"id": "a"}))["play_count"] == 999
        assert client.get("/api/songs/a", headers=headers).json()["play_count"] == 2
        client.put("/api/schedules/draft", json={"status": "Validado"}, headers=headers).raise_for_status()
        assert client.get("/api/songs/a", headers=headers).json()["play_count"] == 3
        # Removing just one duplicated entry keeps that event counted once.
        client.delete(f'/api/setlists/draft/songs/{added.json()["id"]}', headers=headers).raise_for_status()
        assert client.get("/api/songs/a", headers=headers).json()["play_count"] == 3
        client.delete("/api/setlists/draft/songs/draft-a", headers=headers).raise_for_status()
        assert client.get("/api/songs/a", headers=headers).json()["play_count"] == 2
        client.delete("/api/schedules/past2", headers=headers).raise_for_status()
        assert client.get("/api/songs/a", headers=headers).json()["last_played_date"] == "2027-01-10"
        assert client.get("/api/songs/b", headers=headers).json()["play_count"] == 0
        client.put("/api/schedules/past1", json={"status": "Rascunho"}, headers=headers).raise_for_status()
        assert client.get("/api/dashboard/top-songs", headers=headers).json() == []


@pytest.mark.parametrize("status, expected", [("Validado", 1), ("Fechada", 1), ("Rascunho", 0), ("Disponibilidade", 0), ("Em Validação", 0), ("unexpected", 0)])
def test_song_usage_requires_published_status(server, music_context, status, expected):
    asyncio.run(server.db.schedules.update_many({}, {"$set": {"status": "Rascunho"}}))
    asyncio.run(server.db.schedules.update_one({"id": "past1"}, {"$set": {"status": status}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/songs/a", headers=music_context["leader"]).json()["play_count"] == expected


def test_song_ranking_is_limited_and_excludes_deleted_songs(server, music_context):
    async def prepare():
        await server.db.songs.insert_many([{"id": f"new-{i}", "name": f"Extra {i:02d}"} for i in range(12)])
        await server.db.setlists.update_one({"schedule_id": "past1"}, {"$push": {"songs": {"$each": [{"song_id": f"new-{i}"} for i in range(12)]}}})
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        headers = music_context["leader"]
        ranking = client.get("/api/dashboard/top-songs", headers=headers).json()
        assert len(ranking) == 10
        assert ranking[0]["id"] == "a"
        client.delete("/api/songs/a", headers=headers).raise_for_status()
        assert "a" not in [song["id"] for song in client.get("/api/dashboard/top-songs", headers=headers).json()]
        assert client.get("/api/dashboard/top-songs", headers=music_context["ana"]).status_code == 403
        assert client.post("/api/setlists/missing/songs", json={"song_id": "b", "order": 1}, headers=headers).status_code == 404


@pytest.mark.parametrize("utc_hour, expected", [(1, 2), (3, 3)])
def test_song_usage_changes_day_in_sao_paulo_timezone(server, music_context, monkeypatch, utc_hour, expected):
    from datetime import datetime, timezone
    class BoundaryClock:
        @classmethod
        def now(cls, tz=None):
            return datetime(2027, 2, 1, utc_hour, tzinfo=timezone.utc)
    monkeypatch.setattr(server, "datetime", BoundaryClock)
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/songs/a", headers=music_context["leader"]).json()["play_count"] == expected


def test_member_addition_rejects_duplicate_but_preserves_other_functions(server, private_profiles):
    headers = private_profiles["leader"]
    path = "/api/schedules/second/members"
    with TestClient(server.app, base_url="https://testserver") as client:
        first = client.post(path, json={"volunteer_id": "ana", "function": " vocal "}, headers=headers)
        assert first.status_code == 200
        assert first.json()["function"] == "Vocal"
        assert "_id" not in first.json()
        member_id = first.json()["id"]
        client.put(f"{path}/{member_id}", json={"confirmation_status": "Confirmado"}, headers=headers).raise_for_status()
        assert client.post(path, json={"volunteer_id": "ana", "function": "VoCaL"}, headers=headers).status_code == 409
        stored = asyncio.run(server.db.schedule_members.find_one({"id": member_id}))
        assert stored["confirmation_status"] == "Confirmado"
        assert client.post(path, json={"volunteer_id": "ana", "function": "violao"}, headers=headers).json()["function"] == "Violão"
        assert client.post(path, json={"volunteer_id": "bruno", "function": "Vocal"}, headers=headers).status_code == 200
        assert asyncio.run(server.db.schedule_members.count_documents({"schedule_id": "second"})) == 3
        client.delete(f"{path}/{member_id}", headers=headers).raise_for_status()
        replacement = client.post(path, json={"volunteer_id": "ana", "function": "Vocal"}, headers=headers)
        assert replacement.status_code == 200
        assert replacement.json()["id"] != member_id


def test_duplicate_check_preserves_existing_legacy_records(server, private_profiles):
    async def seed():
        await server.db.schedule_members.insert_many([
            {"id": f"legacy-{i}", "schedule_id": "second", "volunteer_id": "ana", "function": "   VIOLAO  ", "confirmation_status": "Confirmado"}
            for i in range(2)
        ])
    asyncio.run(seed())
    with TestClient(server.app, base_url="https://testserver") as client:
        response = client.post("/api/schedules/second/members", json={"volunteer_id": "ana", "function": "Violão"}, headers=private_profiles["leader"])
        assert response.status_code == 409
        assert asyncio.run(server.db.schedule_members.count_documents({"schedule_id": "second"})) == 2
        assert asyncio.run(server.db.schedule_members.find_one({"id": "legacy-0"}))["function"] == "   VIOLAO  "


def test_simultaneous_member_additions_are_guarded_at_database_insert(server, private_profiles, monkeypatch):
    async def race():
        original_insert = server.db.schedule_members.insert_one
        both_ready = asyncio.Event()
        arrived = 0
        async def synchronized_insert(document, *args, **kwargs):
            nonlocal arrived
            arrived += 1
            if arrived == 2:
                both_ready.set()
            await asyncio.wait_for(both_ready.wait(), timeout=5)
            return await original_insert(document, *args, **kwargs)
        monkeypatch.setattr(server.db.schedule_members, "insert_one", synchronized_insert)
        results = await asyncio.gather(*[
            server.add_schedule_member("second", server.ScheduleMemberAdd(volunteer_id="ana", function="Vocal"), {"role": "Líder"})
            for _ in range(2)
        ], return_exceptions=True)
        assert sum(isinstance(result, dict) for result in results) == 1
        errors = [result for result in results if isinstance(result, server.HTTPException)]
        assert len(errors) == 1 and errors[0].status_code == 409
        assert await server.db.schedule_members.count_documents({"schedule_id": "second", "volunteer_id": "ana"}) == 1
    asyncio.run(race())


def test_member_addition_retains_role_validation_and_slot_limits(server, private_profiles):
    path = "/api/schedules/second/members"
    data = {"volunteer_id": "ana", "function": "Vocal"}
    headers = private_profiles["leader"]
    asyncio.run(server.db.schedules.update_one({"id": "second"}, {"$set": {"team_slots": {"Vocal": 1}}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post(path, json=data).status_code == 401
        assert client.post(path, json=data, headers=private_profiles["ana"]).status_code == 403
        for invalid in ["", "Função desconhecida", "a" * 81]:
            assert client.post(path, json={**data, "function": invalid}, headers=headers).status_code == 422
        client.post(path, json={"volunteer_id": "bruno", "function": "Vocal"}, headers=headers).raise_for_status()
        assert client.post(path, json=data, headers=headers).status_code == 409
        assert client.post(path, json={**data, "function": "Violão"}, headers=headers).status_code == 200


@pytest.mark.parametrize("status", ["Pendente", "Inativo", "Afastado", None])
def test_member_addition_requires_active_volunteer(server, private_profiles, status):
    asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": status}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        response = client.post("/api/schedules/second/members", json={"volunteer_id": "ana", "function": "Vocal"}, headers=private_profiles["leader"])
        assert response.status_code == 409
        assert asyncio.run(server.db.schedule_members.count_documents({"schedule_id": "second"})) == 0


def test_capacity_counts_legacy_spelling_and_shared_vocal_slots(server, private_profiles):
    asyncio.run(server.db.schedules.update_one({"id": "second"}, {"$set": {"team_slots": {"Vocal": 1, "Violão": 1}}}))
    asyncio.run(server.db.schedule_members.insert_many([
        {"id": "old-backing", "schedule_id": "second", "volunteer_id": "old", "function": " backing   VOCAL "},
        {"id": "old-guitar", "schedule_id": "second", "volunteer_id": "old", "function": "VIOLAO"},
    ]))
    with TestClient(server.app, base_url="https://testserver") as client:
        for function in ["Vocal", "Backing Vocal", "Violão"]:
            assert client.post("/api/schedules/second/members", json={"volunteer_id": "ana", "function": function}, headers=private_profiles["leader"]).status_code == 409
