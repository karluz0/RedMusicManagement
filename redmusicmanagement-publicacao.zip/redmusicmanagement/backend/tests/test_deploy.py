"""Regression tests for publishing. Uses an isolated in-memory database."""
import asyncio
import importlib.util
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from mongomock_motor import AsyncMongoMockClient


@pytest.fixture
def server(monkeypatch):
    monkeypatch.setenv("MONGO_URL", "mongodb://localhost:27017")
    monkeypatch.setenv("DB_NAME", "isolated_test")
    monkeypatch.setenv("JWT_SECRET", "isolated-test-secret-at-least-32-characters")
    monkeypatch.setenv("COOKIE_SECURE", "true")
    monkeypatch.delenv("ADMIN_EMAIL", raising=False)
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    spec = importlib.util.spec_from_file_location("deploy_server", Path(__file__).parents[1] / "server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.client.close()
    module.client = AsyncMongoMockClient()
    module.db = module.client["isolated_test"]
    return module


def test_public_registration_cannot_grant_management_access(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        for index, role in enumerate(["Líder", "Administrador", "unexpected"]):
            response = client.post("/api/auth/register", json={
                "email": f"person{index}@example.com", "password": "test-password-only",
                "name": "Teste", "role": role,
            })
            assert response.status_code == 200
            assert response.json()["role"] == "Voluntário"
            assert all("Secure" in cookie and "HttpOnly" in cookie
                       for cookie in response.headers.get_list("set-cookie"))
            assert client.post("/api/schedules", json={
                "name": "Blocked", "date": "2027-01-01", "time": "19:00"
            }).status_code == 403


def test_unknown_role_is_denied(server):
    async def verify():
        with pytest.raises(server.HTTPException) as error:
            await server.require_admin({"role": "unexpected"})
        assert error.value.status_code == 403
    asyncio.run(verify())


def test_no_default_admin_is_created(server):
    with TestClient(server.app, base_url="https://testserver"):
        assert asyncio.run(server.db.users.count_documents({})) == 0


def test_admin_bootstrap_does_not_reset_existing_password(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
    monkeypatch.setenv("ADMIN_PASSWORD", "different-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "different-test-password"
        }).status_code == 401


def test_health_and_frontend_routing(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/health").json() == {"status": "ok"}
        assert client.get("/api/not-found").status_code == 404
        assert (server.FRONTEND_BUILD / "index.html").is_file(), "Build frontend before running this test"
        assert "text/html" in client.get("/login").headers["content-type"]
        assert "text/html" in client.get("/schedules/example").headers["content-type"]
        assert client.get("/missing.js").status_code == 404


def test_health_reports_database_failure_without_exposing_connection(server, monkeypatch):
    async def unavailable(*args, **kwargs):
        raise RuntimeError("private connection details")

    with TestClient(server.app, base_url="https://testserver") as client:
        monkeypatch.setattr(server.db, "command", unavailable)
        response = client.get("/api/health")
        assert response.status_code == 503
        assert response.json() == {"status": "unavailable"}
