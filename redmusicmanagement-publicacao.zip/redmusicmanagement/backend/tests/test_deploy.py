"""Regression tests for publishing. Uses an isolated in-memory database."""
import asyncio
import importlib.util
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from mongomock_motor import AsyncMongoMockClient


@pytest.fixture
def server(monkeypatch):
    monkeypatch.setenv("MONGO_URL", "mongodb://localhost:27017")
    monkeypatch.setenv("DB_NAME", "isolated_test")
    monkeypatch.setenv("JWT_SECRET", "isolated-test-secret-at-least-32-characters")
    monkeypatch.setenv("COOKIE_SECURE", "true")
    monkeypatch.delenv("ADMIN_EMAIL", raising=False)
    monkeypatch.delenv("ADMIN_PASSWORD", raising=False)
    spec = importlib.util.spec_from_file_location("deploy_server", Path(__file__).parents[1] / "server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.client.close()
    module.client = AsyncMongoMockClient()
    module.db = module.client["isolated_test"]
    return module


def test_public_registration_cannot_grant_management_access(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        for index, role in enumerate(["Líder", "Administrador", "unexpected"]):
            response = client.post("/api/auth/register", json={
                "email": f"person{index}@example.com", "password": "test-password-only",
                "name": "Teste", "role": role,
            })
            assert response.status_code == 200
            assert response.json()["role"] == "Voluntário"
            assert all("Secure" in cookie and "HttpOnly" in cookie
                       for cookie in response.headers.get_list("set-cookie"))
            assert client.post("/api/schedules", json={
                "name": "Blocked", "date": "2027-01-01", "time": "19:00"
            }).status_code == 403


def test_unknown_role_is_denied(server):
    async def verify():
        with pytest.raises(server.HTTPException) as error:
            await server.require_admin({"role": "unexpected"})
        assert error.value.status_code == 403
    asyncio.run(verify())


def test_no_default_admin_is_created(server):
    with TestClient(server.app, base_url="https://testserver"):
        assert asyncio.run(server.db.users.count_documents({})) == 0


def test_admin_bootstrap_does_not_reset_existing_password(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
    monkeypatch.setenv("ADMIN_PASSWORD", "different-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password"
        }).status_code == 200
        assert client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "different-test-password"
        }).status_code == 401


def test_health_and_frontend_routing(server):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/health").json() == {"status": "ok"}
        assert client.get("/api/not-found").status_code == 404
        assert (server.FRONTEND_BUILD / "index.html").is_file(), "Build frontend before running this test"
        assert "text/html" in client.get("/login").headers["content-type"]
        assert "text/html" in client.get("/schedules/example").headers["content-type"]
        assert client.get("/missing.js").status_code == 404


def test_health_reports_database_failure_without_exposing_connection(server, monkeypatch):
    async def unavailable(*args, **kwargs):
        raise RuntimeError("private connection details")

    with TestClient(server.app, base_url="https://testserver") as client:
        monkeypatch.setattr(server.db, "command", unavailable)
        response = client.get("/api/health")
        assert response.status_code == 503
        assert response.json() == {"status": "unavailable"}


@pytest.mark.parametrize("schedule_status", [
    "Rascunho", "Disponibilidade", "Em Validação", "unexpected", None,
    "Validado", "Fechada",
])
def test_public_schedule_visibility(server, schedule_status):
    document = {"id": "demo", "share_token": "demo-token", "ministry": "Red Music",
                "date": "2027-01-10"}
    if schedule_status is not None:
        document["status"] = schedule_status
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one(document))
        individual = client.get("/api/public/schedules/demo-token")
        monthly = client.get("/api/public/monthly/Red%20Music/2027-01")
        published = schedule_status in ("Validado", "Fechada")
        assert individual.status_code == (200 if published else 404)
        assert [s["id"] for s in monthly.json()["schedules"]] == (["demo"] if published else [])
        assert individual.headers["cache-control"] == "no-store"
        assert monthly.headers["cache-control"] == "no-store"
        if published:
            assert individual.json()["members"] == []
            assert individual.json()["setlist"] == []
        else:
            assert "demo-token" not in individual.text


def test_leader_can_publish_and_revoke_public_access(server, monkeypatch):
    monkeypatch.setenv("ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("ADMIN_PASSWORD", "initial-test-password")
    with TestClient(server.app, base_url="https://testserver") as client:
        asyncio.run(server.db.schedules.insert_one({
            "id": "demo", "share_token": "demo-token", "status": "Rascunho",
            "ministry": "Red Music", "date": "2027-01-10",
        }))
        client.post("/api/auth/login", json={
            "email": "owner@example.com", "password": "initial-test-password",
        }).raise_for_status()
        assert client.get("/api/schedules/demo").json()["status"] == "Rascunho"
        for schedule_status, expected in [("Validado", 200), ("Rascunho", 404)]:
            client.put("/api/schedules/demo", json={"status": schedule_status}).raise_for_status()
            assert client.get("/api/public/schedules/demo-token").status_code == expected
            schedules = client.get("/api/public/monthly/Red%20Music/2027-01").json()["schedules"]
            assert len(schedules) == (1 if expected == 200 else 0)
        assert client.get("/api/schedules/demo").status_code == 200


@pytest.fixture
def confirmation_accounts(server):
    async def seed():
        await server.db.volunteers.insert_many([
            {"id": "ana", "email": "ana@example.com", "status": "Ativo"},
            {"id": "bruno", "email": "bruno@example.com", "status": "Ativo"},
        ])
        await server.db.schedules.insert_many([
            {"id": "first", "status": "Validado"}, {"id": "second", "status": "Rascunho"},
        ])
        await server.db.schedule_members.insert_many([
            {"id": "ana-slot", "schedule_id": "first", "volunteer_id": "ana", "confirmation_status": "Pendente"},
            {"id": "bruno-slot", "schedule_id": "first", "volunteer_id": "bruno", "confirmation_status": "Pendente"},
        ])
        headers = {}
        for name, role in [("ana", "Voluntário"), ("bruno", "Voluntário"), ("leader", "Líder"), ("unknown", "unexpected")]:
            email = f"{name}@example.com"
            result = await server.db.users.insert_one({"email": email, "role": role})
            headers[name] = {"Authorization": "Bearer " + server.create_access_token(str(result.inserted_id), email, role)}
        return headers
    return asyncio.run(seed())


def test_only_linked_volunteer_can_respond_for_self(server, confirmation_accounts):
    headers = confirmation_accounts
    path = "/api/schedules/first/members/ana-slot"
    with TestClient(server.app, base_url="https://testserver") as client:
        data = {"confirmation_status": "Confirmado"}
        assert client.put(path, json=data).status_code == 401
        # Matching email is insufficient: the leadership must approve the link.
        assert client.put(path, json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).status_code == 200
        for status in ["Confirmado", "Preciso de Substituto", "Pendente"]:
            result = client.put(path, json={"confirmation_status": status}, headers=headers["ana"])
            assert result.status_code == 200
            assert result.json()["confirmation_status"] == status
        assert client.put(path, json=data, headers=headers["bruno"]).status_code == 403
        assert client.put("/api/schedules/first/members/bruno-slot", json=data, headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/second/members/ana-slot", json=data, headers=headers["ana"]).status_code == 404
        assert client.put(path, json={"confirmation_status": "inventado"}, headers=headers["ana"]).status_code == 422
        assert client.put(path, json={**data, "volunteer_id": "bruno"}, headers=headers["ana"]).status_code == 422
        detail = client.get("/api/schedules/first", headers=headers["ana"]).json()
        assert {m["id"]: m["can_confirm"] for m in detail["members"]} == {"ana-slot": True, "bruno-slot": False}
        assert client.delete("/api/schedules/first/members/ana-slot", headers=headers["ana"]).status_code == 403
        assert client.put("/api/schedules/first", json={"status": "Rascunho"}, headers=headers["ana"]).status_code == 403
        assert client.put(path, json=data, headers=headers["leader"]).status_code == 200


def test_account_links_require_leadership_and_are_unique(server, confirmation_accounts):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for method in ["get", "put", "delete"]:
            kwargs = {"json": {"email": "ana@example.com"}} if method == "put" else {}
            assert getattr(client, method)("/api/volunteers/ana/account", headers=headers["ana"], **kwargs).status_code == 403
        link = lambda volunteer, email: client.put(f"/api/volunteers/{volunteer}/account", json={"email": email}, headers=headers["leader"])
        assert link("missing", "ana@example.com").status_code == 404
        assert link("ana", "missing@example.com").status_code == 404
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "ana@example.com").status_code == 200
        assert link("ana", "bruno@example.com").status_code == 409
        assert link("bruno", "ana@example.com").status_code == 409
        assert client.get("/api/volunteers/ana/account", headers=headers["leader"]).json() == {"email": "ana@example.com"}
        assert client.delete("/api/volunteers/ana/account", headers=headers["leader"]).status_code == 200
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        assert link("ana", "bruno@example.com").status_code == 200


@pytest.mark.parametrize("condition", ["Inativo", "Afastado", "deleted", "unknown-role"])
def test_inactive_or_invalid_account_cannot_confirm(server, confirmation_accounts, condition):
    headers = confirmation_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.put("/api/volunteers/ana/account", json={"email": "ana@example.com"}, headers=headers["leader"]).raise_for_status()
        if condition == "deleted":
            client.delete("/api/volunteers/ana", headers=headers["leader"]).raise_for_status()
            assert "volunteer_id" not in asyncio.run(server.db.users.find_one({"email": "ana@example.com"}))
        elif condition == "unknown-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": condition}}))
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=headers["ana"]).status_code == 403
        detail = client.get("/api/schedules/first", headers=headers["ana"]).json()
        assert all(not member["can_confirm"] for member in detail["members"])


PRIVATE_VOLUNTEER_PATHS = [
    "/api/volunteers",
    "/api/volunteers/ana",
    "/api/volunteers/bruno",
    "/api/schedules/first/available-volunteers",
    "/api/volunteers/ana/monthly-count/2027-01",
    "/api/volunteers/bruno/participation-history",
]


@pytest.fixture
def private_profiles(server, confirmation_accounts):
    async def enrich():
        for volunteer_id in ["ana", "bruno"]:
            await server.db.volunteers.update_one({"id": volunteer_id}, {"$set": {
                "name": volunteer_id.title(), "phone": "private-phone-123",
                "birth_date": "1990-04-02", "photo_url": "private-photo",
                "unavailability_dates": [{"date": "2027-02-01", "reason": "private-reason"}],
            }})
            await server.db.schedule_members.update_one({"volunteer_id": volunteer_id}, {"$set": {
                "volunteer_name": volunteer_id.title(), "function": "Vocal",
            }})
        for schedule_id in ["first", "second"]:
            await server.db.schedules.update_one({"id": schedule_id}, {"$set": {
                "name": "Exemplo", "date": "2027-01-10", "time": "19:00",
                "ministry": "Red Music", "share_token": f"token-{schedule_id}",
            }})
        # Even a linked account cannot access the administrative profiles.
        await server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"volunteer_id": "ana"}})
    asyncio.run(enrich())
    return confirmation_accounts


@pytest.mark.parametrize("account", [None, "ana", "unknown"])
def test_private_profiles_denied_before_returning_personal_data(server, private_profiles, account):
    headers = private_profiles[account] if account else {}
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=headers)
            assert response.status_code == (403 if account else 401), path
            assert response.headers["cache-control"] == "no-store"
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        # Missing identifiers must not reveal whether a profile exists either.
        assert client.get("/api/volunteers/missing", headers=headers).status_code == (403 if account else 401)


@pytest.mark.parametrize("role", ["Líder", "Administrador"])
def test_leadership_retains_private_management_access(server, private_profiles, role):
    asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": role}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in PRIVATE_VOLUNTEER_PATHS:
            response = client.get(path, headers=private_profiles["leader"])
            assert response.status_code == 200, path
            assert response.headers["cache-control"] == "no-store"
        profile = client.get("/api/volunteers/ana", headers=private_profiles["leader"]).json()
        assert profile["email"] == "ana@example.com"
        assert profile["phone"] == "private-phone-123"
        assert profile["unavailability_dates"][0]["reason"] == "private-reason"


def test_schedules_remain_usable_without_loading_private_profiles(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        for path in ["/api/schedules", "/api/schedules/first", "/api/schedules/first/vocals",
                     "/api/public/schedules/token-first", "/api/public/monthly/Red%20Music/2027-01"]:
            response = client.get(path, headers=private_profiles["ana"])
            assert response.status_code == 200, path
            for secret in ["private-phone", "private-reason", "private-photo", "1990-04-02", "ana@example.com", "bruno@example.com"]:
                assert secret not in response.text
        detail = client.get("/api/schedules/first", headers=private_profiles["ana"]).json()
        assert detail["members"][0]["volunteer_name"] == "Ana"
        assert detail["members"][0]["function"] == "Vocal"
        assert detail["members"][0]["can_confirm"] is True
        assert client.put("/api/schedules/first/members/ana-slot", json={"confirmation_status": "Confirmado"}, headers=private_profiles["ana"]).status_code == 200


def test_private_access_revoked_when_role_changes(server, private_profiles):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/volunteers", headers=private_profiles["leader"]).status_code == 200
        asyncio.run(server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"role": "Voluntário"}}))
        for path in PRIVATE_VOLUNTEER_PATHS:
            assert client.get(path, headers=private_profiles["leader"]).status_code == 403


@pytest.fixture
def chat_accounts(server, private_profiles):
    async def seed():
        await server.db.users.update_one({"email": "bruno@example.com"}, {"$set": {"volunteer_id": "bruno"}})
        await server.db.users.update_one({"email": "leader@example.com"}, {"$set": {"name": "Liderança A"}})
        await server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"name": "Nome informado na conta"}})
        headers = dict(private_profiles)
        for name, role in [("admin", "Administrador"), ("unlinked", "Voluntário")]:
            email = f"{name}@example.com"
            result = await server.db.users.insert_one({"email": email, "role": role, "name": name.title()})
            headers[name] = {"Authorization": "Bearer " + server.create_access_token(str(result.inserted_id), email, role)}
        ids = {}
        for name in headers:
            account = await server.db.users.find_one({"email": f"{name}@example.com"})
            ids[name] = str(account["_id"])
        return headers, ids
    return asyncio.run(seed())


def test_chat_contacts_use_accounts_without_personal_profiles(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for account, expected in [("ana", {ids["leader"], ids["admin"]}),
                                  ("leader", {ids["ana"], ids["bruno"], ids["admin"]})]:
            response = client.get("/api/chat/contacts", headers=headers[account])
            assert response.status_code == 200
            assert response.headers["cache-control"] == "no-store"
            assert {contact["id"] for contact in response.json()} == expected
            assert all(set(contact) == {"id", "name", "role"} for contact in response.json())
            assert "@example.com" not in response.text
            assert "private-" not in response.text
        ana = next(contact for contact in client.get("/api/chat/contacts", headers=headers["leader"]).json() if contact["id"] == ids["ana"])
        assert ana["name"] == "Ana"


@pytest.mark.parametrize("account, expected", [(None, 401), ("unlinked", 403), ("unknown", 403)])
def test_chat_rejects_ineligible_accounts(server, chat_accounts, account, expected):
    headers, ids = chat_accounts
    auth = headers[account] if account else {}
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/chat/contacts", headers=auth).status_code == expected
        response = client.get(f'/api/chat/messages/{ids["leader"]}', headers=auth)
        assert response.status_code == expected
        assert response.headers["cache-control"] == "no-store"
        assert client.post("/api/chat/messages", json={"to_user_id": ids["leader"], "message": "Teste"}, headers=auth).status_code == expected
        assert asyncio.run(server.db.chat_messages.count_documents({})) == 0


def test_chat_delivers_both_directions_and_isolates_conversations(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        def send(sender, recipient, message):
            response = client.post("/api/chat/messages", json={"to_user_id": ids[recipient], "message": message}, headers=headers[sender])
            assert response.status_code == 200
            assert response.headers["cache-control"] == "no-store"
            assert response.json()["from_user_id"] == ids[sender]
            assert response.json()["to_user_id"] == ids[recipient]
            return response.json()
        send("leader", "ana", "  Olá Ana  ")
        reply = send("ana", "leader", "Confirmo o ensaio")
        assert reply["from_user_name"] == "Ana"
        send("leader", "bruno", "Conversa reservada com Bruno")
        ana_history = client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).json()
        leader_history = client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["leader"]).json()
        assert ana_history == leader_history
        assert [message["message"] for message in ana_history] == ["Olá Ana", "Confirmo o ensaio"]
        assert client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["admin"]).json() == []
        assert client.get(f'/api/chat/messages/{ids["bruno"]}', headers=headers["ana"]).status_code == 404
        assert client.post("/api/chat/messages", json={"to_user_id": ids["bruno"], "message": "Indevido"}, headers=headers["ana"]).status_code == 404


def test_chat_validates_recipient_content_and_sender(server, chat_accounts):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        for target in ["not-an-account", "0123456789abcdef01234567", ids["leader"], ids["leader"].upper(), ids["unlinked"], ids["unknown"]]:
            response = client.post("/api/chat/messages", json={"to_user_id": target, "message": "Teste"}, headers=headers["leader"])
            assert response.status_code == 404
            assert response.json()["detail"] == "Contato indisponível"
            assert client.get(f"/api/chat/messages/{target}", headers=headers["leader"]).status_code == 404
        for message in ["", " \n\t ", "a" * 2001]:
            assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": message}, headers=headers["leader"]).status_code == 422
        assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Teste", "from_user_id": ids["admin"]}, headers=headers["leader"]).status_code == 422
        assert asyncio.run(server.db.chat_messages.count_documents({})) == 0


@pytest.mark.parametrize("condition", ["unlinked", "Inativo", "Afastado", "unknown-role"])
def test_chat_access_is_revoked_with_account_eligibility(server, chat_accounts, condition):
    headers, ids = chat_accounts
    with TestClient(server.app, base_url="https://testserver") as client:
        client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Antes da revogação"}, headers=headers["leader"]).raise_for_status()
        if condition == "unlinked":
            client.delete("/api/volunteers/ana/account", headers=headers["leader"]).raise_for_status()
        elif condition == "unknown-role":
            asyncio.run(server.db.users.update_one({"email": "ana@example.com"}, {"$set": {"role": "unexpected"}}))
        else:
            asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": condition}}))
        assert client.get("/api/chat/contacts", headers=headers["ana"]).status_code == 403
        assert client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).status_code == 403
        assert client.get(f'/api/chat/messages/{ids["ana"]}', headers=headers["leader"]).status_code == 404
        assert client.post("/api/chat/messages", json={"to_user_id": ids["ana"], "message": "Depois"}, headers=headers["leader"]).status_code == 404
        assert ids["ana"] not in {contact["id"] for contact in client.get("/api/chat/contacts", headers=headers["leader"]).json()}


def test_chat_returns_recent_history_without_assigning_legacy_messages(server, chat_accounts):
    from datetime import datetime, timedelta, timezone
    headers, ids = chat_accounts
    async def seed():
        start = datetime(2027, 1, 1, tzinfo=timezone.utc)
        await server.db.chat_messages.insert_many([
            {"id": f"message-{index}", "from_user_id": ids["leader"], "to_user_id": ids["ana"],
             "message": str(index), "timestamp": start + timedelta(seconds=index)}
            for index in range(105)
        ])
        await server.db.chat_messages.insert_one({"id": "legacy", "from_user_id": ids["leader"],
            "to_user_id": "ana", "message": "Endereço antigo sem vínculo confiável", "timestamp": start + timedelta(days=1)})
    asyncio.run(seed())
    with TestClient(server.app, base_url="https://testserver") as client:
        history = client.get(f'/api/chat/messages/{ids["leader"]}', headers=headers["ana"]).json()
        assert [message["message"] for message in history] == [str(index) for index in range(5, 105)]
        assert asyncio.run(server.db.chat_messages.count_documents({"id": "legacy"})) == 1


@pytest.mark.parametrize("status, expected", [
    ("Em Validação", 1), ("Validado", 1), ("Fechada", 1),
    ("Rascunho", 0), ("Disponibilidade", 0), ("unexpected", 0), (None, 0),
])
def test_monthly_participation_uses_consistent_schedule_statuses(server, private_profiles, status, expected):
    async def prepare():
        await server.db.schedules.update_one({"id": "first"}, {"$set": {"status": status}})
        # Two functions in the same event still count as one schedule.
        await server.db.schedule_members.insert_one({"id": "ana-extra", "schedule_id": "first", "volunteer_id": "ana", "function": "Violão"})
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        count = client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"])
        assert count.status_code == 200
        assert count.json()["count"] == expected
        available = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        ana = next(person for person in available if person["id"] == "ana")
        assert ana["monthly_schedule_count"] == expected
        assert ana["is_exhausted"] is False


def test_monthly_participation_counts_distinct_events_and_month_boundaries(server, private_profiles):
    async def prepare():
        await server.db.schedules.insert_many([
            {"id": "same-day", "date": "2027-01-10", "status": "Fechada", "ministry": "Pulse Music"},
            {"id": "previous-month", "date": "2026-12-31", "status": "Validado"},
            {"id": "next-month", "date": "2027-02-01", "status": "Validado"},
            {"id": "other-year", "date": "2026-01-10", "status": "Validado"},
            {"id": "malformed", "date": "2027-010-10", "status": "Validado"},
        ])
        await server.db.volunteers.insert_one({"id": "clara", "name": "Clara", "status": "Ativo"})
        await server.db.schedule_members.insert_many([
            {"id": f"member-{schedule}", "schedule_id": schedule, "volunteer_id": "ana"}
            for schedule in ["same-day", "previous-month", "next-month", "other-year", "malformed", "deleted-schedule", "second"]
        ])
    asyncio.run(prepare())
    with TestClient(server.app, base_url="https://testserver") as client:
        counts = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        by_id = {person["id"]: person for person in counts}
        assert by_id["ana"]["monthly_schedule_count"] == 2
        assert by_id["ana"]["is_exhausted"] is True
        assert by_id["bruno"]["monthly_schedule_count"] == 1
        assert by_id["bruno"]["is_exhausted"] is False
        assert by_id["clara"]["monthly_schedule_count"] == 0
        for person in counts:
            result = client.get(f'/api/volunteers/{person["id"]}/monthly-count/2027-01', headers=private_profiles["leader"])
            assert result.json()["count"] == person["monthly_schedule_count"]
        assert client.get("/api/volunteers/ana/monthly-count/2026-12", headers=private_profiles["leader"]).json()["count"] == 1
        assert client.get("/api/volunteers/ana/monthly-count/2027-02", headers=private_profiles["leader"]).json()["count"] == 1
        # Status edits and removal must update both views immediately.
        client.put("/api/schedules/first", json={"status": "Rascunho"}, headers=private_profiles["leader"]).raise_for_status()
        assert client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"]).json()["count"] == 1
        client.delete("/api/schedules/same-day", headers=private_profiles["leader"]).raise_for_status()
        assert client.get("/api/volunteers/ana/monthly-count/2027-01", headers=private_profiles["leader"]).json()["count"] == 0
        available = client.get("/api/schedules/second/available-volunteers", headers=private_profiles["leader"]).json()
        assert next(person for person in available if person["id"] == "ana")["is_exhausted"] is False


@pytest.mark.parametrize("year_month", ["2027-00", "2027-13", "2027-1", "2027-01.*"])
def test_monthly_participation_rejects_invalid_months(server, private_profiles, year_month):
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get(f"/api/volunteers/ana/monthly-count/{year_month}", headers=private_profiles["leader"]).status_code == 422


@pytest.fixture
def streak_context(server, private_profiles, monkeypatch):
    from datetime import datetime, timezone
    reference = datetime(2027, 1, 31, 12, tzinfo=timezone.utc)
    class FixedClock:
        @classmethod
        def now(cls, tz=None):
            return reference
    monkeypatch.setattr(server, "datetime", FixedClock)
    asyncio.run(server.db.schedules.delete_many({}))
    asyncio.run(server.db.schedule_members.delete_many({}))

    def seed(events):
        async def insert():
            for index, item in enumerate(events):
                event = {"id": f"event-{index}", "status": "Validado", "ministry": "Red Music", "time": "19:00", **item}
                attendees = event.pop("attendees", ["ana"])
                await server.db.schedules.insert_one(event)
                for attendee_index, person in enumerate(attendees):
                    await server.db.schedule_members.insert_one({
                        "id": f'{event["id"]}-{person}-{attendee_index}', "schedule_id": event["id"],
                        "volunteer_id": person, "volunteer_name": "Nome antigo", "function": "Vocal",
                    })
        asyncio.run(insert())
    return private_profiles, seed


def test_streak_reports_current_sequence_with_dates_and_no_duplicate_functions(server, streak_context):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    asyncio.run(server.db.schedule_members.insert_one({"id": "duplicate-function", "schedule_id": "event-3", "volunteer_id": "ana", "function": "Violão"}))
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"])
        assert result.status_code == 200
        assert result.headers["cache-control"] == "no-store"
        assert result.json() == [{"volunteer_id": "ana", "name": "Ana", "consecutive_schedules": 4,
                                  "ministry": "Red Music", "first_date": "2027-01-10", "last_date": "2027-01-31"}]
        # A new program where Ana rests ends her current streak.
        asyncio.run(server.db.schedules.insert_one({"id": "rest", "date": "2027-02-07", "time": "19:00", "status": "Validado", "ministry": "Red Music"}))
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


@pytest.mark.parametrize("events", [
    [{"date": "2027-01-03"}, {"date": "2027-01-10"}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-03"}, {"date": "2027-01-10"}, {"date": "2027-01-17", "attendees": ["bruno"]}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-31", "attendees": ["ana"] * 4}],
    [{"date": "2027-01-17"}, {"date": "2027-01-24"}, {"date": "2027-01-31"}],
    [{"date": "2027-01-10"}, {"date": "2027-01-17"}, {"date": "2027-01-24"}, {"date": "2027-01-31", "ministry": "Pulse Music"}],
])
def test_streak_does_not_confuse_history_repetition_gaps_or_ministries(server, streak_context, events):
    headers, seed = streak_context
    seed(events)
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


@pytest.mark.parametrize("status, expected", [("Em Validação", 1), ("Validado", 1), ("Fechada", 1), ("Rascunho", 0), ("Disponibilidade", 0), ("unexpected", 0), (None, 0)])
def test_streak_uses_committed_schedule_statuses(server, streak_context, status, expected):
    headers, seed = streak_context
    seed([{"date": day, "status": status} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert len(client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()) == expected


def test_drafts_and_other_ministries_do_not_interrupt_a_real_streak(server, streak_context):
    headers, seed = streak_context
    seed(
        [{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]]
        + [{"date": "2027-01-29", "status": "Rascunho", "attendees": []},
           {"date": "2027-01-30", "ministry": "Pulse Music", "attendees": ["bruno"]}]
    )
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()
        assert len(result) == 1
        assert result[0]["ministry"] == "Red Music"
        assert result[0]["consecutive_schedules"] == 4


def test_streak_ignores_unrelated_events_and_chooses_longest_current_ministry(server, streak_context):
    headers, seed = streak_context
    seed(
        [{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]]
        + [{"date": "2027-01-28", "attendees": [], "status": "Rascunho"},
           {"date": "not-a-date", "attendees": []},
           {"date": "2027-01-28", "ministry": "Other Music", "attendees": ["bruno"]}]
        + [{"date": day, "ministry": "Pulse Music"} for day in ["2027-02-07", "2027-02-14", "2027-02-21", "2027-02-28", "2027-03-07"]]
    )
    with TestClient(server.app, base_url="https://testserver") as client:
        result = client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()
        assert len(result) == 1
        assert result[0]["ministry"] == "Pulse Music"
        assert result[0]["consecutive_schedules"] == 5


@pytest.mark.parametrize("days, expected", [
    (["2027-01-03", "2027-01-10", "2027-01-17", "2027-01-24"], 1),
    (["2027-01-02", "2027-01-09", "2027-01-16", "2027-01-23"], 0),
    (["2027-02-07", "2027-02-14", "2027-02-21", "2027-02-28"], 1),
])
def test_streak_only_reports_recent_or_future_sequences(server, streak_context, days, expected):
    headers, seed = streak_context
    seed([{"date": day} for day in days])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert len(client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json()) == expected


@pytest.mark.parametrize("status", ["Inativo", "Afastado", "deleted"])
def test_streak_excludes_inactive_and_deleted_people(server, streak_context, status):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    if status == "deleted":
        asyncio.run(server.db.volunteers.delete_one({"id": "ana"}))
    else:
        asyncio.run(server.db.volunteers.update_one({"id": "ana"}, {"$set": {"status": status}}))
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert", headers=headers["leader"]).json() == []


def test_streak_remains_restricted_to_leadership(server, streak_context):
    headers, seed = streak_context
    seed([{"date": day} for day in ["2027-01-10", "2027-01-17", "2027-01-24", "2027-01-31"]])
    with TestClient(server.app, base_url="https://testserver") as client:
        assert client.get("/api/dashboard/burnout-alert").status_code == 401
        for person in ["ana", "unknown"]:
            assert client.get("/api/dashboard/burnout-alert", headers=headers[person]).status_code == 403
