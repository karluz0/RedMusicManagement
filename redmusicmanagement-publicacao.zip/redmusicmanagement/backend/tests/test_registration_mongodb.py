"""Atomic public registration integration; disposable localhost database only."""
import asyncio
import importlib.util
import os
from pathlib import Path
import uuid
import pytest

@pytest.mark.skipif(os.environ.get('RUN_MONGO_TRANSACTION_TESTS') != '1', reason='Requires disposable local replica set')
def test_registration_race_and_rollback(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    monkeypatch.setenv('MONGO_URL', 'mongodb://127.0.0.1:27019/?replicaSet=codex-local-test')
    database = 'codex_registration_test_' + uuid.uuid4().hex
    monkeypatch.setenv('DB_NAME', database)
    monkeypatch.setenv('JWT_SECRET', 'isolated-registration-secret-at-least-32-characters')
    monkeypatch.delenv('ADMIN_EMAIL', raising=False)
    monkeypatch.delenv('ADMIN_PASSWORD', raising=False)
    async def exercise():
        spec = importlib.util.spec_from_file_location('registration_worker', Path(__file__).parents[1] / 'server.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.client.close()
        module.client = AsyncIOMotorClient(module.mongo_url, serverSelectionTimeoutMS=10000)
        module.db = module.client[database]
        try:
            await module.startup_event()
            # Isolate the registration transaction; quotas have a separate integration suite.
            async def no_quota(*args, **kwargs):
                pass
            monkeypatch.setattr(module, "consume_auth_limit", no_quota)
            data = module.PublicVolunteerRegister(name='Fictitious', email='race@example.com', password='local-test-password', birth_date='1995-01-01', phone='000')
            async def register():
                try:
                    await module.public_volunteer_register(data)
                    return 200
                except module.HTTPException as error:
                    return error.status_code
            assert sorted(await asyncio.gather(register(), register())) == [200, 400]
            assert await module.db.users.count_documents({'email': data.email}) == 1
            assert await module.db.volunteers.count_documents({'email': data.email}) == 1
            person = await module.db.volunteers.find_one({'email': data.email})
            account = await module.db.users.find_one({'email': data.email})
            assert account['volunteer_id'] == person['id'] and person['status'] == 'Pendente'
            collection = module.db.users
            monkeypatch.setattr(module.db, 'users', collection)
            original = collection.insert_one
            async def fail_after_write(document, **kwargs):
                await original(document, **kwargs)
                raise RuntimeError('injected failure after account write')
            monkeypatch.setattr(collection, 'insert_one', fail_after_write)
            failed = module.PublicVolunteerRegister(name='Rollback', email='rollback@example.com', password='local-test-password', birth_date='1995-01-01', phone='000')
            with pytest.raises(RuntimeError):
                await module.public_volunteer_register(failed)
            assert await module.db.users.count_documents({'email': failed.email}) == 0
            assert await module.db.volunteers.count_documents({'email': failed.email}) == 0
        finally:
            await module.client.drop_database(database)
            module.client.close()
    asyncio.run(exercise())
