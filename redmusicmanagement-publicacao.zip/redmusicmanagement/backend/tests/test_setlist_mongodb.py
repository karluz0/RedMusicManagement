"""Setlist uniqueness, concurrent editing, deletion races and migration rollback on local MongoDB."""
import asyncio
import importlib.util
import os
from pathlib import Path
import uuid
import pytest

@pytest.mark.skipif(os.environ.get('RUN_MONGO_TRANSACTION_TESTS') != '1', reason='Requires disposable local replica set')
def test_setlist_transactions_and_migration(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    monkeypatch.setenv('MONGO_URL','mongodb://127.0.0.1:27019/?replicaSet=codex-local-test')
    database='codex_setlist_test_'+uuid.uuid4().hex
    monkeypatch.setenv('DB_NAME',database)
    monkeypatch.setenv('JWT_SECRET','isolated-setlist-secret-at-least-32-characters')
    monkeypatch.delenv('ADMIN_EMAIL',raising=False)
    monkeypatch.delenv('ADMIN_PASSWORD',raising=False)
    async def exercise():
        workers=[]
        for i in range(2):
            spec=importlib.util.spec_from_file_location('setlist_worker_'+str(i),Path(__file__).parents[1]/'server.py')
            m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.client.close()
            m.client=AsyncIOMotorClient(m.mongo_url,serverSelectionTimeoutMS=10000);m.db=m.client[database];workers.append(m)
        first,second=workers
        leader={'_id':'local-leader','id':'local-leader','name':'Leader','role':'Líder'}
        try:
            # Migrate duplicates with colliding entry IDs without dropping either song or source metadata.
            for key in ['a','b']:
                await first.db.setlists.insert_one({'_id':key,'schedule_id':'legacy','marker':key,'songs':[{'id':'same','song_id':key,'notes':key,'order':1}]})
            await first.startup_event();await second.startup_event()
            assert await first.db.setlists.count_documents({'schedule_id':'legacy'})==1
            assert len((await first.db.setlists.find_one({'schedule_id':'legacy'}))['songs'])==2
            assert await first.db.setlist_migration_backups.count_documents({})==2
            await first.db.songs.insert_one({'id':'song','name':'Demo','original_key':'C'})
            async def add(worker,sid,key='D'):
                try:
                    return await worker.add_setlist_song(sid,worker.SetlistSongAdd(song_id='song',order=999,key_for_this_event=key),leader)
                except worker.HTTPException as error:
                    return error.status_code
            for number in range(5):
                sid='concurrent-'+str(number)
                await first.db.schedules.insert_one({'id':sid,'date':'2099-11-01','status':'Rascunho'})
                results=await asyncio.gather(add(first,sid,'D'),add(second,sid,'E'))
                assert all(isinstance(item,dict) for item in results),results
                assert await first.db.setlists.count_documents({'schedule_id':sid})==1
                entries=(await first.db.setlists.find_one({'schedule_id':sid}))['songs']
                assert len(entries)==2 and [item['order'] for item in entries]==[1,2]
                assert {item['key_for_this_event'] for item in entries}=={'D','E'}
            # Each race must leave no orphan after the delete commits.
            for number in range(5):
                sid='delete-race-'+str(number)
                await first.db.schedules.insert_one({'id':sid,'date':'2099-11-01','status':'Rascunho'})
                await asyncio.gather(add(first,sid),second.delete_schedule(sid,leader))
                assert await first.db.schedules.count_documents({'id':sid})==0
                assert await first.db.setlists.count_documents({'schedule_id':sid})==0
            # Whole-month deletion takes the same monthly lock as an add.
            plan=(await first.create_monthly_plan(first.MonthlyPlanCreate(year_month='2099-11',ministry='Pulse Music',dates=['2099-11-02']),leader))['id']
            team=await first.db.schedules.find_one({'plan_id':plan})
            await asyncio.gather(add(first,team['id']),second.delete_monthly_plan(plan,leader))
            assert await first.db.setlists.count_documents({'schedule_id':team['id']})==0
            # Inject a failure after the song is written: both song and lock revision must roll back.
            sid='rollback'
            await first.db.schedules.insert_one({'id':sid,'date':'2099-11-01','status':'Rascunho'})
            collection=first.db.setlists;monkeypatch.setattr(first.db,'setlists',collection)
            original=collection.update_one
            async def failing_update(query,update,*args,**kwargs):
                await original(query,update,*args,**kwargs)
                raise RuntimeError('injected setlist error')
            monkeypatch.setattr(collection,'update_one',failing_update)
            with pytest.raises(RuntimeError):
                await add(first,sid)
            assert await first.db.setlists.count_documents({'schedule_id':sid})==0
            assert '_assignment_revision' not in await first.db.schedules.find_one({'id':sid})
            monkeypatch.setattr(collection,'update_one',original)
            # A failed migration must roll back backups, merged data and removals together.
            await collection.drop_index('schedule_id_1')
            for key in ['c','d']:
                await collection.insert_one({'_id':key,'schedule_id':'migration-failure','songs':[{'id':key,'song_id':key}]})
            delete_original=collection.delete_many
            async def failing_delete(query,**kwargs):
                await delete_original(query,**kwargs)
                raise RuntimeError('injected migration error')
            monkeypatch.setattr(collection,'delete_many',failing_delete)
            with pytest.raises(RuntimeError):
                await first.ensure_unique_setlists()
            assert await collection.count_documents({'schedule_id':'migration-failure'})==2
            assert await first.db.setlist_migration_backups.count_documents({'_id':{'$in':['c','d']}})==0
            monkeypatch.setattr(collection,'delete_many',delete_original)
        finally:
            await first.client.drop_database(database)
            for worker in workers:worker.client.close()
    asyncio.run(exercise())

