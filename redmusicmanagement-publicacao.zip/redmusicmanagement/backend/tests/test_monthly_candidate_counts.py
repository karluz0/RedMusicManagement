import asyncio
from fastapi.testclient import TestClient
from test_deploy import server
from test_monthly_planning import people, create, view, stage, add


def test_candidate_count_combines_red_pulse_drafts_and_deduplicates_functions(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        red=create(client,people['leader'],dates=['2099-11-01','2099-11-08','2099-11-09','2099-11-15'])
        pulse=create(client,people['leader'],'Pulse Music',['2099-11-02','2099-11-09'])
        stage(client,red,people['leader'],'montar');stage(client,pulse,people['leader'],'montar')
        teams=view(client,red,people['leader'])['schedules']
        pulse_teams=view(client,pulse,people['leader'])['schedules']
        lookup=lambda day,city: next(item['id'] for item in teams if item['date']==day and item['location']==city)
        p2=next(item['id'] for item in pulse_teams if item['date']=='2099-11-02')
        p9=next(item['id'] for item in pulse_teams if item['date']=='2099-11-09')
        answers={'responses':[{'date':day,'available':True} for day in ['2099-11-01','2099-11-02','2099-11-08','2099-11-09','2099-11-15']]}
        assert client.put('/api/daily-availability',headers=people['ana'],json=answers).status_code==200
        r1=lookup('2099-11-01','Indaiatuba');r8=lookup('2099-11-08','Itu');r15=lookup('2099-11-15','Indaiatuba')
        vocal=add(client,r1,people['leader'],'ana')
        guitar=add(client,r1,people['leader'],'ana','Violão')
        add(client,r8,people['leader'],'ana');add(client,p9,people['leader'],'ana')
        async def other_month():
            await server.db.schedules.insert_one({'id':'other-month','date':'2099-12-01','ministry':'Pulse Music','status':'Rascunho'})
            await server.db.schedule_members.insert_one({'id':'outside','schedule_id':'other-month','volunteer_id':'ana','function':'Vocal'})
        asyncio.run(other_month())
        def count(sid):
            response=client.get(f'/api/schedules/{sid}/available-volunteers',headers=people['leader'])
            assert response.status_code==200
            return next(row for row in response.json() if row['id']=='ana')['monthly_schedule_count']
        assert count(r15)==3 and count(p2)==3  # Two Red cities plus Pulse, even before validation/publication.
        add(client,p2,people['leader'],'ana')
        assert count(r15)==4
        assert client.delete(f"/api/schedules/{r1}/members/{guitar['id']}",headers=people['leader']).status_code==200
        assert count(r15)==4  # A second function never adds a second participation.
        assert client.delete(f"/api/schedules/{r1}/members/{vocal['id']}",headers=people['leader']).status_code==200
        assert count(r15)==3
        conflict=lookup('2099-11-09','Indaiatuba')
        assert 'ana' not in [row['id'] for row in client.get(f'/api/schedules/{conflict}/available-volunteers',headers=people['leader']).json()]
        exception=next(row for row in client.get(f'/api/schedules/{conflict}/available-volunteers?include_exceptions=true',headers=people['leader']).json() if row['id']=='ana')
        assert exception['day_conflict'] is True and exception['monthly_schedule_count']==3
        add(client,conflict,people['leader'],'ana',reason='Exceção não ignora conflito',status=409)
