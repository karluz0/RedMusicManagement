import asyncio
import pytest
from fastapi.testclient import TestClient
from test_deploy import server, private_profiles, confirmation_accounts


@pytest.mark.parametrize('actor', ['leader', 'ana'])
def test_archived_song_keeps_historical_references(server, private_profiles, actor):
    song = {'id': 'historical-song', 'name': 'Canção de exemplo', 'artist': 'Artista exemplo',
            'original_key': 'C', 'bpm': 72, 'tempo': '4/4', 'notes': 'Introdução com violão',
            'link_original': 'https://example.com/original', 'link_pt_br': 'https://example.com/ptbr',
            'link_intro_arrangement': 'https://example.com/arranjo', 'sheet_music_url': 'https://example.com/cifra'}
    entry = {'id': 'entry', 'song_id': song['id'], 'song_name': song['name'], 'original_key': 'C',
             'key_for_this_event': 'D', 'main_vocal_volunteer_id': 'ana', 'order': 1}
    async def seed():
        await server.db.songs.insert_one(dict(song))
        await server.db.setlists.insert_one({'schedule_id': 'first', 'songs': [dict(entry), {'id': 'missing', 'song_id': 'removed', 'song_name': 'Referência antiga', 'order': 2}]})
    asyncio.run(seed())
    with TestClient(server.app, base_url='https://testserver') as client:
        path = '/api/schedules/first'
        before = client.get(path, headers=private_profiles[actor])
        assert before.status_code == 200
        assert before.json()['setlist'][0]['song_full'] == song
        assert client.delete('/api/songs/historical-song', headers=private_profiles['leader']).status_code == 200
        assert client.get('/api/songs', headers=private_profiles[actor]).json() == []
        after = client.get(path, headers=private_profiles[actor])
        assert after.status_code == 200
        historical = after.json()['setlist'][0]
        assert {key: historical[key] for key in entry} == entry
        assert {key: historical['song_full'][key] for key in song} == song
        assert historical['song_full']['archived'] is True
        assert '_id' not in historical['song_full']
        assert after.json()['setlist'][1]['song_name'] == 'Referência antiga'
        assert 'song_full' not in after.json()['setlist'][1]
        assert client.post('/api/setlists/second/songs', json={'song_id': song['id'], 'order': 1}, headers=private_profiles['leader']).status_code == 404
        assert client.get(path).status_code == 401
        asyncio.run(server.db.schedules.update_one({'id': 'first'}, {'$set': {'status': 'Rascunho'}}))
        assert client.get(path, headers=private_profiles['ana']).status_code == 404
    stored = asyncio.run(server.db.setlists.find_one({'schedule_id': 'first'}))
    assert stored['songs'][0] == entry  # Read enrichment must not overwrite the saved arrangement.
