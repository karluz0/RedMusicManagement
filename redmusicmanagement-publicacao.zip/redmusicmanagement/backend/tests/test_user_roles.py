import asyncio
import pytest
from fastapi.testclient import TestClient
from test_deploy import server
from test_monthly_planning import people, create, view

@pytest.fixture
def roles(server, people):
    async def seed():
        result = await server.db.users.insert_one({'email':'admin@example.com','name':'Admin','role':'Administrador'})
        return {'Authorization':'Bearer '+server.create_access_token(str(result.inserted_id),'admin@example.com','Administrador')}
    return {'admin':asyncio.run(seed()), **people}


def test_only_administrator_manages_roles_and_old_tokens_follow_current_role(server, roles):
    async def account():
        return await server.db.users.find_one({'email':'ana@example.com'})
    uid = str(asyncio.run(account())['_id'])
    with TestClient(server.app,base_url='https://testserver') as client:
        for actor in ['ana','leader']:
            assert client.get('/api/users',headers=roles[actor]).status_code == 403
            assert client.put(f'/api/users/{uid}/role',headers=roles[actor],json={'role':'Gestor'}).status_code == 403
        users = client.get('/api/users',headers=roles['admin'])
        assert users.status_code == 200
        assert all('password_hash' not in row and '_id' not in row for row in users.json())
        assert client.post('/api/schedules',headers=roles['ana'],json={'name':'Demo','date':'2099-11-01','time':'19:00','event_type':'Evento'}).status_code == 403
        assert client.put(f'/api/users/{uid}/role',headers=roles['admin'],json={'role':'Administrador'}).status_code == 422
        assert client.put(f'/api/users/{uid}/role',headers=roles['admin'],json={'role':'Gestor','volunteer_id':'bruno'}).status_code == 422
        assert client.put(f'/api/users/{uid}/role',headers=roles['admin'],json={'role':'Gestor'}).status_code == 200
        # The token was issued as Voluntário; authorization reads the current account from MongoDB.
        assert client.get('/api/dashboard/metrics',headers=roles['ana']).status_code == 200
        assert client.get('/api/users',headers=roles['ana']).status_code == 403
        assert asyncio.run(account())['volunteer_id'] == 'ana'
        assert client.put(f'/api/users/{uid}/role',headers=roles['admin'],json={'role':'Voluntário'}).status_code == 200
        assert client.get('/api/dashboard/metrics',headers=roles['ana']).status_code == 403
        admin = next(row for row in users.json() if row['role']=='Administrador')
        assert client.put(f"/api/users/{admin['id']}/role",headers=roles['admin'],json={'role':'Gestor'}).status_code == 409
        assert client.put('/api/users/invalid/role',headers=roles['admin'],json={'role':'Gestor'}).status_code == 404


def test_pending_or_unlinked_account_cannot_be_promoted(server, roles):
    async def seed():
        await server.db.volunteers.update_one({'id':'ana'},{'$set':{'status':'Pendente'}})
        return str((await server.db.users.find_one({'email':'ana@example.com'}))['_id'])
    uid=asyncio.run(seed())
    with TestClient(server.app,base_url='https://testserver') as client:
        assert client.put(f'/api/users/{uid}/role',headers=roles['admin'],json={'role':'Gestor'}).status_code == 409
        assert client.put('/api/volunteers/ana/account',headers=roles['admin'],json={'email':'admin@example.com'}).status_code == 403


def test_admin_never_answers_even_with_legacy_profile_and_gestor_can_serve(server, roles):
    async def link_admin():
        await server.db.users.update_one({'email':'bruno@example.com'},{'$unset':{'volunteer_id':''}})
        await server.db.users.update_one({'email':'admin@example.com'},{'$set':{'volunteer_id':'bruno'}})
        await server.db.users.update_one({'email':'ana@example.com'},{'$set':{'role':'Gestor'}})
    asyncio.run(link_admin())
    with TestClient(server.app,base_url='https://testserver') as client:
        pid=create(client,roles['admin'])
        admin=view(client,pid,roles['admin'])
        assert not admin.get('can_answer_availability') and not admin.get('participations') and not admin.get('own_availability')
        assert 'bruno' not in [row['id'] for row in admin['availability_overview']]
        assert client.get('/api/auth/me',headers=roles['admin']).json().get('volunteer_id') is None
        answers={'responses':[{'date':'2099-11-01','available':True}]}
        assert client.put(f'/api/monthly-plans/{pid}/availability',headers=roles['admin'],json=answers).status_code==403
        assert client.put(f'/api/monthly-plans/{pid}/availability',headers=roles['ana'],json=answers).status_code==200
        gestor=view(client,pid,roles['ana'])
        assert gestor['own_availability']['2099-11-01'] is True and gestor['can_answer_availability']
        sid=admin['schedules'][0]['id']
        assert client.post(f'/api/schedules/{sid}/members',headers=roles['admin'],json={'volunteer_id':'bruno','function':'Vocal'}).status_code==409
        assert asyncio.run(server.db.daily_availability.count_documents({'volunteer_id':'bruno'}))==0


def test_replacement_is_once_preserves_ministry_data_and_revokes_sessions(server, monkeypatch):
    old_id=None
    async def seed():
        result=await server.db.users.insert_one({'email':'old@example.com','role':'Administrador','password_hash':server.hash_password('old-test-password')})
        await server.db.auth_sessions.insert_one({'_id':'old-session','user_id':str(result.inserted_id)})
        await server.db.volunteers.insert_one({'id':'keep','name':'Preservar'})
        await server.db.schedules.insert_one({'id':'keep','name':'Preservar'})
        await server.db.songs.insert_one({'id':'keep','name':'Preservar'})
        return str(result.inserted_id)
    old_id=asyncio.run(seed())
    password='isolated-admin-password'
    asyncio.run(server.replace_accounts_once('isolated-reset',server.hash_password(password)))
    assert asyncio.run(server.db.users.count_documents({}))==1
    admin=asyncio.run(server.db.users.find_one({}))
    assert admin['email']=='admin@redmusic.com' and admin['role']=='Administrador' and 'volunteer_id' not in admin
    assert asyncio.run(server.db.auth_sessions.count_documents({}))==0
    for collection in ['volunteers','schedules','songs']:
        assert asyncio.run(server.db[collection].count_documents({'id':'keep'}))==1
    asyncio.run(server.db.users.insert_one({'email':'later@example.com','role':'Voluntário'}))
    asyncio.run(server.replace_accounts_once('isolated-reset',server.hash_password('must-not-reset-password')))
    assert asyncio.run(server.db.users.count_documents({}))==2
    monkeypatch.setenv('ADMIN_EMAIL','old@example.com'); monkeypatch.setenv('ADMIN_PASSWORD','old-bootstrap-password')
    with TestClient(server.app,base_url='https://testserver') as client:
        assert client.post('/api/auth/login',json={'email':'admin@redmusic.com','password':password}).status_code==200
        client.cookies.clear()
        assert client.get('/api/auth/me',headers={'Authorization':'Bearer '+server.create_access_token(old_id,'old@example.com','Administrador')}).status_code==401
    assert asyncio.run(server.db.users.count_documents({'email':'old@example.com'}))==0
