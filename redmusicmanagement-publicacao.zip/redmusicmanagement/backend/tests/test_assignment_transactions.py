"""Integration test: run against a disposable local replica set on port 27019.

Run this file separately with pytest. No Atlas credentials or production data.
"""
import asyncio
import importlib.util
from pathlib import Path
import uuid
import os
import pytest


@pytest.mark.skipif(os.environ.get("RUN_MONGO_TRANSACTION_TESTS") != "1", reason="Requires disposable local MongoDB replica set")
def test_real_mongodb_concurrency_and_rollback(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    monkeypatch.setenv("MONGO_URL", "mongodb://127.0.0.1:27019/?replicaSet=codex-local-test")
    monkeypatch.setenv("DB_NAME", "codex_assignment_test_" + uuid.uuid4().hex)
    monkeypatch.setenv("JWT_SECRET", "isolated-transaction-test-secret-at-least-32-characters")

    async def verify():
        modules = []
        for worker in range(2):
            spec = importlib.util.spec_from_file_location(f"assignment_worker_{worker}", Path(__file__).parents[1] / "server.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            module.client.close()
            module.client = AsyncIOMotorClient(module.mongo_url, serverSelectionTimeoutMS=10000)
            module.db = module.client[module.os.environ["DB_NAME"]]
            modules.append(module)
        first, second = modules
        db = first.db
        try:
            await db.command("ping")
            await db.volunteers.insert_many([
                {"id": person, "name": person, "status": "Ativo"}
                for person in ["ana", "bruno", "legacy"]
            ])
            for iteration in range(8):
                sid = f"race-{iteration}"
                await db.schedules.insert_one({"id": sid, "team_slots": {"Vocal": 2}})
                await db.schedule_members.insert_one({"id": f"legacy-{iteration}", "schedule_id": sid, "volunteer_id": "legacy", "function": " vocal "})
                ready = asyncio.Event()
                arrived = 0
                async def add(module, person, function):
                    nonlocal arrived
                    arrived += 1
                    if arrived == 2:
                        ready.set()
                    await ready.wait()
                    return await module.add_schedule_member(sid, module.ScheduleMemberAdd(volunteer_id=person, function=function), {"role": "Gestor"})
                results = await asyncio.gather(add(first, "ana", "Vocal"), add(second, "bruno", "Backing Vocal"), return_exceptions=True)
                assert sum(isinstance(result, dict) for result in results) == 1, results
                errors = [result for result in results if isinstance(result, first.HTTPException)]
                assert len(errors) == 1 and errors[0].status_code == 409, results
                assert await db.schedule_members.count_documents({"schedule_id": sid}) == 2
                # The rejected transaction must not change the shared revision.
                assert (await db.schedules.find_one({"id": sid}))["_assignment_revision"] == 1

            await db.schedules.insert_one({"id": "rollback"})
            collection = db.schedule_members
            monkeypatch.setattr(db, "schedule_members", collection)
            original_insert = collection.insert_one
            async def fail_after_insert(document, **kwargs):
                await original_insert(document, **kwargs)
                raise RuntimeError("isolated injected failure")
            monkeypatch.setattr(collection, "insert_one", fail_after_insert)
            try:
                await first.add_schedule_member("rollback", first.ScheduleMemberAdd(volunteer_id="ana", function="Baixo"), {"role": "Gestor"})
                raise AssertionError("Injected failure should abort")
            except RuntimeError as error:
                assert str(error) == "isolated injected failure"
            monkeypatch.setattr(collection, "insert_one", original_insert)
            assert await db.schedule_members.count_documents({"schedule_id": "rollback"}) == 0
            assert "_assignment_revision" not in await db.schedules.find_one({"id": "rollback"})
            for status in ["Pendente", "Inativo", "Afastado"]:
                await db.volunteers.update_one({"id": "ana"}, {"$set": {"status": status}})
                try:
                    await first.add_schedule_member("rollback", first.ScheduleMemberAdd(volunteer_id="ana", function="Baixo"), {"role": "Gestor"})
                    raise AssertionError("Inactive volunteer must be rejected")
                except first.HTTPException as error:
                    assert error.status_code == 409
                assert "_assignment_revision" not in await db.schedules.find_one({"id": "rollback"})
            await db.volunteers.update_one({"id": "ana"}, {"$set": {"status": "Ativo"}})
            added = await first.add_schedule_member("rollback", first.ScheduleMemberAdd(volunteer_id="ana", function="Baixo"), {"role": "Gestor"})
            await first.delete_schedule_member("rollback", added["id"], {"role": "Gestor"})
            await second.add_schedule_member("rollback", second.ScheduleMemberAdd(volunteer_id="bruno", function="Baixo"), {"role": "Gestor"})
            assert await db.schedule_members.count_documents({"schedule_id": "rollback"}) == 1
        finally:
            await first.client.drop_database(db.name)
            for module in modules:
                module.client.close()
    asyncio.run(verify())
