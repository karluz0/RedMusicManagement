"""Account replacement concurrency and rollback on an isolated local replica set."""
import asyncio
import importlib.util
import os
from pathlib import Path
import uuid
import pytest

@pytest.mark.skipif(os.environ.get('RUN_MONGO_TRANSACTION_TESTS') != '1', reason='Requires disposable local replica set')
def test_account_replacement_atomic_and_idempotent(monkeypatch):
    from motor.motor_asyncio import AsyncIOMotorClient
    database='codex_account_reset_test_'+uuid.uuid4().hex
    monkeypatch.setenv('MONGO_URL','mongodb://127.0.0.1:27019/?replicaSet=codex-local-test')
    monkeypatch.setenv('DB_NAME',database)
    monkeypatch.setenv('JWT_SECRET','isolated-reset-secret-at-least-32-characters')
    monkeypatch.delenv('ADMIN_EMAIL',raising=False);monkeypatch.delenv('ADMIN_PASSWORD',raising=False)
    async def exercise():
        workers=[]
        for index in range(2):
            spec=importlib.util.spec_from_file_location('reset_worker_'+str(index),Path(__file__).parents[1]/'server.py')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.client.close()
            module.client=AsyncIOMotorClient(module.mongo_url,serverSelectionTimeoutMS=10000);module.db=module.client[database];workers.append(module)
        first,second=workers
        try:
            await first.startup_event()
            assert await first.db.users.count_documents({})==0  # Deployment reset is scoped to the intended DB only.
            await first.db.users.insert_many([{'email':'old@example.com','role':'Administrador'},{'email':'other@example.com','role':'Voluntário'}])
            await first.db.auth_sessions.insert_one({'_id':'old','user_id':'old'})
            await first.db.volunteers.insert_one({'id':'keep','name':'Keep'})
            await first.db.schedules.insert_one({'id':'keep'})
            await first.db.songs.insert_one({'id':'keep'})
            migrations=first.db.system_migrations;monkeypatch.setattr(first.db,'system_migrations',migrations)
            original=migrations.update_one
            async def failing_update(query, update, *args, **kwargs):
                result=await original(query,update,*args,**kwargs)
                if update.get('$set',{}).get('applied'):
                    raise RuntimeError('injected error after account replacement')
                return result
            monkeypatch.setattr(migrations,'update_one',failing_update)
            with pytest.raises(RuntimeError):
                await first.replace_accounts_once('isolated-reset','test-only-verifier')
            assert await first.db.users.count_documents({})==2
            assert await first.db.users.find_one({'email':'old@example.com'})
            assert await first.db.auth_sessions.count_documents({})==1
            assert not (await migrations.find_one({'_id':'isolated-reset'}))['applied']
            monkeypatch.setattr(migrations,'update_one',original)
            await asyncio.gather(first.replace_accounts_once('isolated-reset','test-only-verifier'),second.replace_accounts_once('isolated-reset','test-only-verifier'))
            assert await first.db.users.count_documents({})==1
            account=await first.db.users.find_one({})
            assert account['email']=='admin@redmusic.com' and 'volunteer_id' not in account
            assert await first.db.auth_sessions.count_documents({})==0
            for collection in ['volunteers','schedules','songs']:
                assert await first.db[collection].count_documents({'id':'keep'})==1
            await first.db.users.insert_one({'email':'later@example.com','role':'Voluntário'})
            await first.replace_accounts_once('isolated-reset','different-verifier')
            assert await first.db.users.count_documents({})==2
            assert (await first.db.users.find_one({'email':'admin@redmusic.com'}))['_id']==account['_id']
            assert (await first.db.users.find_one({'email':'admin@redmusic.com'}))['password_hash']=='test-only-verifier'
        finally:
            await first.client.drop_database(database)
            for worker in workers: worker.client.close()
    asyncio.run(exercise())
