import asyncio
import pytest
from fastapi.testclient import TestClient
from test_deploy import server


@pytest.fixture
def people(server):
    async def seed():
        headers = {}
        for name, role, ministries in [('leader', 'Líder', []), ('ana', 'Voluntário', ['Red Music', 'Pulse Music']), ('bruno', 'Voluntário', ['Red Music']), ('clara', 'Voluntário', ['Red Music']), ('pulse', 'Voluntário', ['Pulse Music'])]:
            user = {'email': name + '@example.com', 'role': role, 'name': name.title()}
            if role == 'Voluntário':
                await server.db.volunteers.insert_one({'id': name, 'name': name.title(), 'status': 'Ativo', 'ministries': ministries, 'instruments': ['Vocal', 'Violão']})
                user['volunteer_id'] = name
            result = await server.db.users.insert_one(user)
            headers[name] = {'Authorization': 'Bearer ' + server.create_access_token(str(result.inserted_id), user['email'], role)}
        return headers
    return asyncio.run(seed())


def create(client, headers, ministry='Red Music', dates=None):
    response = client.post('/api/monthly-plans', headers=headers, json={'year_month': '2099-11', 'ministry': ministry, 'dates': dates or ['2099-11-01', '2099-11-08']})
    assert response.status_code == 200, response.text
    return response.json()['id']


def view(client, pid, headers):
    response = client.get('/api/monthly-plans/' + pid, headers=headers)
    assert response.status_code == 200, response.text
    return response.json()


def stage(client, pid, headers, action, status=200):
    response = client.post(f'/api/monthly-plans/{pid}/stage', json={'action': action}, headers=headers)
    assert response.status_code == status, response.text


def add(client, sid, headers, who, function='Vocal', reason='', status=200):
    response = client.post(f'/api/schedules/{sid}/members', headers=headers, json={'volunteer_id': who, 'function': function, 'exception_reason': reason})
    assert response.status_code == status, response.text
    return response.json()


def populated(client, server, people):
    pid = create(client, people['leader'])
    schedules = view(client, pid, people['leader'])['schedules']
    stage(client, pid, people['leader'], 'montar')
    for schedule, who in zip(schedules, ['ana', 'bruno', 'clara', 'bruno']):
        add(client, schedule['id'], people['leader'], who, reason='Contato realizado pela liderança')
    return pid, schedules


def test_month_creates_two_cities_and_one_pulse_team_without_touching_individuals(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        red = create(client, people['leader'])
        pulse = create(client, people['leader'], 'Pulse Music', ['2099-11-01'])
        red_view, pulse_view = view(client, red, people['leader']), view(client, pulse, people['leader'])
        assert len(red_view['schedules']) == 4 and len(pulse_view['schedules']) == 1
        assert {row['location'] for row in red_view['schedules']} == {'Itu', 'Indaiatuba'}
        assert red_view['stage'] == 'Coleta'
        assert all(row['status'] == 'Rascunho' for row in red_view['schedules'])
        assert client.get('/api/schedules', headers=people['ana']).json() == []
        assert client.get(f'/api/monthly-plans/{red}', headers=people['pulse']).status_code == 404
        assert 'members' not in view(client, red, people['ana'])
        duplicate = client.post('/api/monthly-plans', headers=people['leader'], json={'year_month': '2099-11', 'ministry': 'Red Music', 'dates': ['2099-11-15']})
        assert duplicate.status_code == 409
        assert asyncio.run(server.db.schedules.count_documents({})) == 5


@pytest.mark.parametrize('body', [
    {'dates': []}, {'dates': ['2099-11-01', '2099-11-01']}, {'dates': ['2099-12-01']},
    {'dates': ['2099-11-31']}, {'ministry': 'Other'}, {'availability_deadline': '2099-11-02'},
])
def test_invalid_month_is_rejected_before_any_creation(server, people, body):
    with TestClient(server.app, base_url='https://testserver') as client:
        response = client.post('/api/monthly-plans', headers=people['leader'], json={'year_month': '2099-11', 'ministry': 'Red Music', 'dates': ['2099-11-01'], **body})
        assert response.status_code == 422
        assert asyncio.run(server.db.monthly_plans.count_documents({})) == 0
        assert asyncio.run(server.db.schedules.count_documents({})) == 0


def test_daily_response_shared_between_ministries_and_only_owner_can_write(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        red = create(client, people['leader'])
        pulse = create(client, people['leader'], 'Pulse Music', ['2099-11-01'])
        body = {'responses': [{'date': '2099-11-01', 'available': True}, {'date': '2099-11-08', 'available': False}]}
        assert client.put('/api/daily-availability', json=body).status_code == 401
        assert client.put('/api/daily-availability', headers=people['leader'], json=body).status_code == 403
        assert client.put('/api/daily-availability', headers=people['ana'], json=body).status_code == 200
        assert view(client, red, people['ana'])['own_availability'] == {'2099-11-01': True, '2099-11-08': False}
        assert view(client, pulse, people['ana'])['own_availability'] == {'2099-11-01': True}
        assert view(client, red, people['bruno'])['own_availability'] == {}
        assert client.put('/api/daily-availability', headers=people['ana'], json={**body, 'volunteer_id': 'bruno'}).status_code == 422
        assert asyncio.run(server.db.daily_availability.count_documents({})) == 2


@pytest.mark.parametrize('responses', [
    [{'date': '2099-11-01', 'available': 'yes'}], [{'date': '2099-12-01', 'available': True}],
    [{'date': '2099-11-01', 'available': True}, {'date': '2099-11-01', 'available': False}],
])
def test_daily_response_rejects_bad_dates_and_duplicates(server, people, responses):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid = create(client, people['leader'])
        response = client.put(f'/api/monthly-plans/{pid}/availability', headers=people['ana'], json={'responses': responses})
        assert response.status_code == 422
        assert asyncio.run(server.db.daily_availability.count_documents({})) == 0


def test_candidates_default_to_available_and_exceptions_never_override_day_conflicts(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        red = create(client, people['leader'], dates=['2099-11-01'])
        pulse = create(client, people['leader'], 'Pulse Music', ['2099-11-01'])
        schedules = view(client, red, people['leader'])['schedules']
        for who, available in [('ana', True), ('bruno', False)]:
            assert client.put('/api/daily-availability', headers=people[who], json={'responses': [{'date': '2099-11-01', 'available': available}]}).status_code == 200
        sid = schedules[0]['id']
        add(client, sid, people['leader'], 'ana', status=409)  # Collection is still open.
        stage(client, red, people['leader'], 'montar')
        stage(client, pulse, people['leader'], 'montar')
        path = f'/api/schedules/{sid}/available-volunteers'
        assert [row['id'] for row in client.get(path, headers=people['leader']).json()] == ['ana']
        exceptions = client.get(path + '?include_exceptions=true', headers=people['leader']).json()
        assert {row['id']: row['availability_status'] for row in exceptions} == {'ana': 'Disponível', 'bruno': 'Indisponível', 'clara': 'Sem resposta'}
        add(client, sid, people['leader'], 'bruno', status=409)
        add(client, sid, people['leader'], 'ana')
        add(client, sid, people['leader'], 'ana', 'Violão')  # Two functions in the same team.
        add(client, schedules[1]['id'], people['leader'], 'ana', reason='Cannot override', status=409)
        pulse_sid = view(client, pulse, people['leader'])['schedules'][0]['id']
        add(client, pulse_sid, people['leader'], 'ana', reason='Cannot override either', status=409)
        add(client, schedules[1]['id'], people['leader'], 'bruno', reason='Combinado pessoalmente')
        add(client, schedules[1]['id'], people['leader'], 'pulse', reason='Wrong ministry', status=409)
        response = client.get(f'/api/schedules/{schedules[1]["id"]}/available-volunteers?include_exceptions=true', headers=people['leader']).json()
        assert next(row for row in response if row['id'] == 'ana')['day_conflict'] is True
        assert client.get(f'/api/schedules/{sid}/available-volunteers', headers=people['ana']).status_code == 403


def test_month_validation_adjustment_resolution_and_revalidation_only_for_changed_participation(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid, schedules = populated(client, server, people)
        stage(client, pid, people['leader'], 'validar')
        own = view(client, pid, people['ana'])['participations'][0]
        response = {'schedule_id': own['schedule_id'], 'expected_version': own['validation_version'], 'decision': 'Preciso de Substituto', 'note': 'Observação particular da Ana'}
        assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people['ana'], json={'responses': [{**response, 'note': ''}]}).status_code == 422
        assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people['ana'], json={'responses': [response]}).status_code == 200
        assert 'Observação particular' in str(view(client, pid, people['leader']))
        assert 'Observação particular' not in str(view(client, pid, people['bruno']))
        private_sid = own['schedule_id']
        assert 'Observação particular' not in client.get(f'/api/schedules/{private_sid}', headers=people['bruno']).text
        stage(client, pid, people['leader'], 'publicar', 409)
        current = view(client, pid, people['ana'])['participations'][0]
        assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people['ana'], json={'responses': [{**response, 'expected_version': current['validation_version'], 'decision': 'Confirmado'}]}).status_code == 409
        stage(client, pid, people['leader'], 'reabrir')
        assert client.put(f'/api/monthly-plans/{pid}/resolve', headers=people['leader'], json={'schedule_id': current['schedule_id'], 'volunteer_id': 'ana', 'expected_version': current['validation_version'], 'resolution': 'Ajuste combinado com a Ana'}).status_code == 200
        stage(client, pid, people['leader'], 'validar')
        for who in ['ana', 'bruno', 'clara']:
            participations = view(client, pid, people[who])['participations']
            body = {'responses': [{'schedule_id': row['schedule_id'], 'expected_version': row['validation_version'], 'decision': 'Confirmado'} for row in participations]}
            assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people[who], json=body).status_code == 200
            assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people[who], json=body).status_code == 409  # Stale tab.
        stage(client, pid, people['leader'], 'publicar')
        plan = view(client, pid, people['leader'])
        assert plan['stage'] == 'Concluído' and plan['summary']['confirmed'] == 4
        token = asyncio.run(server.db.schedules.find_one({'id': private_sid}))['share_token']
        public = client.get('/api/public/schedules/' + token)
        assert public.status_code == 200
        for sensitive in ['response_note', 'adjustment_resolution', 'exception_reason', 'validation_version']:
            assert sensitive not in public.text
            assert sensitive not in client.get('/api/public/monthly/Red%20Music/2099-11').text
        stage(client, pid, people['leader'], 'reabrir')
        add(client, private_sid, people['leader'], 'ana', 'Violão', reason='Já conversado')
        changed = view(client, pid, people['leader'])
        assert changed['summary']['pending'] == 1 and changed['summary']['confirmed'] == 3
        assert client.get('/api/public/schedules/' + token).status_code == 404
        assert len([row for row in changed['members'] if row['volunteer_id'] == 'ana']) == 2
        assert all(row['confirmation_status'] == 'Pendente' for row in changed['members'] if row['volunteer_id'] == 'ana')


def test_own_response_batch_checks_every_item_before_writing(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid, schedules = populated(client, server, people)
        stage(client, pid, people['leader'], 'validar')
        own = view(client, pid, people['ana'])['participations'][0]
        body = {'responses': [{'schedule_id': own['schedule_id'], 'expected_version': own['validation_version'], 'decision': 'Confirmado'}, {'schedule_id': schedules[-1]['id'], 'expected_version': 'other', 'decision': 'Confirmado'}]}
        assert client.put(f'/api/monthly-plans/{pid}/responses', headers=people['ana'], json=body).status_code == 403
        assert view(client, pid, people['ana'])['participations'][0]['confirmation_status'] == 'Pendente'
        assert client.put(f'/api/schedules/{own["schedule_id"]}/members/' + view(client, pid, people['leader'])['members'][0]['id'], headers=people['leader'], json={'confirmation_status': 'Confirmado'}).status_code == 409


def test_individual_scale_can_publish_without_validation_and_still_blocks_double_booking(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        ids = []
        for day in ['2099-12-01', '2099-12-02']:
            response = client.post('/api/schedules', headers=people['leader'], json={'name': 'Evento autônomo', 'date': day, 'time': '19:00'})
            assert response.status_code == 200 and response.json()['validation_required'] is False
            ids.append(response.json()['id'])
            result = add(client, ids[-1], people['leader'], 'ana')
            assert result['confirmation_status'] == 'Dispensada'
        assert client.put(f'/api/schedules/{ids[0]}', headers=people['leader'], json={'status': 'Validado'}).status_code == 200
        detail = client.get(f'/api/schedules/{ids[0]}', headers=people['ana']).json()
        assert not detail['members'][0]['can_confirm']
        assert client.put(f'/api/schedules/{ids[0]}/members/{detail["members"][0]["id"]}', headers=people['ana'], json={'confirmation_status': 'Confirmado'}).status_code == 409
        assert client.get('/api/public/schedules/' + detail['share_token']).status_code == 200
        assert client.put(f'/api/schedules/{ids[1]}', headers=people['leader'], json={'date': '2099-12-01'}).status_code == 409
        assert client.get(f'/api/schedules/{ids[1]}', headers=people['leader']).json()['date'] == '2099-12-02'


def test_month_permissions_missing_links_and_generic_routes_cannot_bypass_stage(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        assert client.post('/api/monthly-plans', headers=people['ana'], json={'year_month': '2099-11', 'ministry': 'Red Music', 'dates': ['2099-11-01']}).status_code == 403
        pid = create(client, people['leader'], dates=['2099-11-01'])
        sid = view(client, pid, people['leader'])['schedules'][0]['id']
        assert client.put('/api/schedules/' + sid, headers=people['leader'], json={'status': 'Fechada'}).status_code == 409
        assert client.delete('/api/schedules/' + sid, headers=people['leader']).status_code == 409
        assert client.post(f'/api/monthly-plans/{pid}/stage', headers=people['ana'], json={'action': 'montar'}).status_code == 403
        stage(client, pid, people['leader'], 'montar')
        stage(client, pid, people['leader'], 'validar', 409)  # Empty teams.
        for index, schedule in enumerate(view(client, pid, people['leader'])['schedules']):
            add(client, schedule['id'], people['leader'], ['ana', 'bruno'][index], reason='Contato feito')
        asyncio.run(server.db.users.update_one({'email': 'ana@example.com'}, {'$unset': {'volunteer_id': ''}}))
        stage(client, pid, people['leader'], 'validar', 409)
        assert client.get('/api/monthly-plans').status_code == 401
        assert client.get('/api/monthly-plans', headers=people['leader']).headers['cache-control'] == 'no-store'


def test_profile_date_block_requires_exception_even_with_positive_daily_answer(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid = create(client, people['leader'], dates=['2099-11-01'])
        asyncio.run(server.db.volunteers.update_one({'id': 'ana'}, {'$set': {'unavailability_dates': [{'date': '2099-11-01', 'reason': 'Private family commitment'}]}}))
        assert client.put('/api/daily-availability', headers=people['ana'], json={'responses': [{'date': '2099-11-01', 'available': True}]}).status_code == 200
        stage(client, pid, people['leader'], 'montar')
        sid = view(client, pid, people['leader'])['schedules'][0]['id']
        assert not client.get(f'/api/schedules/{sid}/available-volunteers', headers=people['leader']).json()
        add(client, sid, people['leader'], 'ana', status=409)
        add(client, sid, people['leader'], 'ana', reason='Novo acordo com a Ana')
        row = view(client, pid, people['leader'])['members'][0]
        assert row['availability_warning'] and row['availability_exception']
        assert asyncio.run(server.db.daily_availability.find_one({'volunteer_id': 'ana'}))['available'] is True


def test_availability_changes_are_visible_to_leader_and_do_not_remove_assignments(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid = create(client, people['leader'], dates=['2099-11-01'])
        body = {'responses': [{'date': '2099-11-01', 'available': True}]}
        assert client.put('/api/daily-availability', headers=people['ana'], json=body).status_code == 200
        stage(client, pid, people['leader'], 'montar')
        sid = view(client, pid, people['leader'])['schedules'][0]['id']
        add(client, sid, people['leader'], 'ana')
        assert not view(client, pid, people['leader'])['members'][0]['availability_warning']
        body['responses'][0]['available'] = False
        assert client.put('/api/daily-availability', headers=people['ana'], json=body).status_code == 200
        result = view(client, pid, people['leader'])
        assert len(result['members']) == 1 and result['members'][0]['availability_warning']
        assert result['availability_overview'][0]['responses']['2099-11-01'] is False


def test_deadline_and_mixed_daily_batch_do_not_allow_partial_responses(server, people, monkeypatch):
    with TestClient(server.app, base_url='https://testserver') as client:
        result = client.post('/api/monthly-plans', headers=people['leader'], json={'year_month': '2099-11', 'ministry': 'Red Music', 'dates': ['2099-11-01'], 'availability_deadline': '2099-11-01'})
        pid = result.json()['id']
        body = {'responses': [{'date': '2099-11-01', 'available': True}, {'date': '2099-12-01', 'available': True}]}
        assert client.put('/api/daily-availability', headers=people['ana'], json=body).status_code == 409
        assert asyncio.run(server.db.daily_availability.count_documents({})) == 0
        monkeypatch.setattr(server, 'local_today', lambda: server.date(2099, 11, 2))
        assert not view(client, pid, people['ana'])['can_answer_availability']
        body['responses'].pop()
        assert client.put('/api/daily-availability', headers=people['ana'], json=body).status_code == 409
        assert client.put(f'/api/monthly-plans/{pid}/availability', headers=people['ana'], json=body).status_code == 409


def test_removing_one_function_invalidates_only_that_person_team_group(server, people):
    with TestClient(server.app, base_url='https://testserver') as client:
        pid, schedules = populated(client, server, people)
        sid = schedules[0]['id']
        instrument = add(client, sid, people['leader'], 'ana', 'Violão', reason='Acordo confirmado')
        asyncio.run(server.db.schedule_members.update_many({'plan_id': pid}, {'$set': {'confirmation_status': 'Confirmado'}}))
        stage(client, pid, people['leader'], 'validar')
        assert client.delete(f'/api/schedules/{sid}/members/{instrument["id"]}', headers=people['leader']).status_code == 409
        stage(client, pid, people['leader'], 'reabrir')
        assert client.delete(f'/api/schedules/{sid}/members/{instrument["id"]}', headers=people['leader']).status_code == 200
        result = view(client, pid, people['leader'])
        assert result['summary'] == {'total': 4, 'confirmed': 3, 'adjustments': 0, 'pending': 1}
        assert next(row for row in result['members'] if row['volunteer_id'] == 'ana')['function'] == 'Vocal'


@pytest.mark.parametrize('ministries', [[], ['Unknown']])
def test_ministry_membership_requires_known_nonempty_values(server, people, ministries):
    with TestClient(server.app, base_url='https://testserver') as client:
        response = client.put('/api/volunteers/ana', headers=people['leader'], json={'ministries': ministries})
        assert response.status_code == 422
        assert asyncio.run(server.db.volunteers.find_one({'id': 'ana'}))['ministries'] == ['Red Music', 'Pulse Music']
