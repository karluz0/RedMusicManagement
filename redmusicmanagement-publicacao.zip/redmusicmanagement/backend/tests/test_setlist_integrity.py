import asyncio
import pytest
from fastapi.testclient import TestClient
from test_deploy import server, private_profiles, confirmation_accounts


def test_setlist_appends_to_single_document_with_server_order(server, private_profiles):
    async def seed():
        await server.db.songs.insert_one({'id':'song','name':'Demo','original_key':'C'})
    asyncio.run(seed())
    with TestClient(server.app, base_url='https://testserver') as client:
        body={'song_id':'song','order':999,'key_for_this_event':'D','main_vocal_volunteer_id':'ana'}
        assert client.post('/api/setlists/first/songs',json=body,headers=private_profiles['ana']).status_code == 403
        one=client.post('/api/setlists/first/songs',json=body,headers=private_profiles['leader'])
        two=client.post('/api/setlists/first/songs',json=body,headers=private_profiles['leader'])
        assert [one.json()['order'],two.json()['order']]==[1,2]
        assert one.json()['id'] != two.json()['id']
        assert one.json()['key_for_this_event']=='D' and one.json()['main_vocal_volunteer_id']=='ana'
        assert asyncio.run(server.db.setlists.count_documents({'schedule_id':'first'}))==1
        assert len(client.get('/api/setlists/first',headers=private_profiles['leader']).json()['songs'])==2
        assert client.post('/api/setlists/missing/songs',json=body,headers=private_profiles['leader']).status_code==404
        assert asyncio.run(server.db.setlists.count_documents({'schedule_id':'missing'}))==0
        assert client.delete('/api/setlists/missing/songs/no-entry',headers=private_profiles['leader']).status_code==404


def test_duplicate_migration_backs_up_sources_and_keeps_every_entry(server):
    async def seed():
        for label,key in [('a','C'),('b','D')]:
            await server.db.setlists.insert_one({'_id':label,'schedule_id':'legacy','custom':'source-'+label,'songs':[{'id':'same-id','song_id':'song','key_for_this_event':key,'notes':'keep-'+label,'order':9}]})
    asyncio.run(seed())
    with TestClient(server.app, base_url='https://testserver'):
        stored=asyncio.run(server.db.setlists.find_one({'schedule_id':'legacy'}))
        assert asyncio.run(server.db.setlists.count_documents({'schedule_id':'legacy'}))==1
        assert len(stored['songs'])==2
        assert len({item['id'] for item in stored['songs']})==2
        assert {item['notes'] for item in stored['songs']}=={'keep-a','keep-b'}
        assert [item['order'] for item in stored['songs']]==[1,2]
        backups=asyncio.run(server.db.setlist_migration_backups.find({}).to_list(None))
        assert len(backups)==2
        assert {item['original']['custom'] for item in backups}=={'source-a','source-b'}
        asyncio.run(server.ensure_unique_setlists())
        assert asyncio.run(server.db.setlist_migration_backups.count_documents({}))==2
        from pymongo.errors import DuplicateKeyError
        with pytest.raises(DuplicateKeyError):
            asyncio.run(server.db.setlists.insert_one({'schedule_id':'legacy','songs':[]}))


def test_invalid_duplicate_migration_preserves_original_records(server):
    async def seed():
        await server.db.setlists.insert_one({'schedule_id':'invalid','songs':None})
        await server.db.setlists.insert_one({'schedule_id':'invalid','songs':[]})
    asyncio.run(seed())
    with pytest.raises(RuntimeError):
        asyncio.run(server.ensure_unique_setlists())
    assert asyncio.run(server.db.setlists.count_documents({'schedule_id':'invalid'}))==2
    assert asyncio.run(server.db.setlist_migration_backups.count_documents({}))==0



def test_append_preserves_legacy_order_gaps(server, private_profiles):
    async def seed():
        await server.db.songs.insert_one({'id':'song','name':'Demo','original_key':'C'})
        await server.db.setlists.insert_one({'schedule_id':'first','songs':[{'id':'old','song_id':'song','order':12,'notes':'preserved'}]})
    asyncio.run(seed())
    with TestClient(server.app, base_url='https://testserver') as client:
        response=client.post('/api/setlists/first/songs',json={'song_id':'song','order':1},headers=private_profiles['leader'])
        assert response.status_code==200 and response.json()['order']==13
        assert asyncio.run(server.db.setlists.find_one({'schedule_id':'first'}))['songs'][0]['notes']=='preserved'
