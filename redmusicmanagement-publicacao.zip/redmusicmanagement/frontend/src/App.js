import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { Layout } from '@/components/Layout';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { UserAccountsPage } from '@/pages/UserAccountsPage';
import { VolunteersPage } from '@/pages/VolunteersPage';
import { VolunteerDetailPage } from '@/pages/VolunteerDetailPage';
import { SchedulesPage } from '@/pages/SchedulesPage';
import { ScheduleDetailPage } from '@/pages/ScheduleDetailPage';
import { SongsPage } from '@/pages/SongsPage';
import { PublicSchedulePage } from '@/pages/PublicSchedulePage';
import { PublicRegisterPage } from '@/pages/PublicRegisterPage';
import { PublicMonthlyPage } from '@/pages/PublicMonthlyPage';
import { MonthlyPlanningPage, PlanningDashboard } from '@/pages/MonthlyPlanningPage';
import { Toaster } from 'sonner';

const AdminRoute = ({ children }) => {
  const { user } = useAuth();
  if (!['Administrador', 'Gestor'].includes(user?.role)) return <Navigate to="/schedules" replace />;
  return children;
};

const OwnerRoute = ({ children }) => {
  const { user } = useAuth();
  return user?.role === 'Administrador' ? children : <Navigate to="/dashboard" replace />;
};

const HomeRedirect = () => {
  return <Navigate to="/dashboard" replace />;
};

const DashboardHome = () => {
  const { user } = useAuth();
  return user?.role === 'Voluntário' ? <PlanningDashboard /> : <DashboardPage />;
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<Navigate to="/cadastro-voluntario" replace />} />
          <Route path="/cadastro-voluntario" element={<PublicRegisterPage />} />
          <Route path="/public/schedule/:token" element={<PublicSchedulePage />} />
          <Route path="/public/mes/:ministry/:yearMonth" element={<PublicMonthlyPage />} />

          <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route index element={<HomeRedirect />} />
            <Route path="dashboard" element={<DashboardHome />} />
            <Route path="planning" element={<MonthlyPlanningPage />} />
            <Route path="planning/:id" element={<MonthlyPlanningPage />} />
            <Route path="users" element={<OwnerRoute><UserAccountsPage /></OwnerRoute>} />
            <Route path="volunteers" element={<AdminRoute><VolunteersPage /></AdminRoute>} />
            <Route path="volunteers/:id" element={<AdminRoute><VolunteerDetailPage /></AdminRoute>} />
            <Route path="schedules" element={<SchedulesPage />} />
            <Route path="schedules/:id" element={<ScheduleDetailPage />} />
            <Route path="songs" element={<SongsPage />} />
            <Route path="chat" element={<Navigate to="/dashboard" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
      <Toaster position="top-right" richColors />
    </AuthProvider>
  );
}

export default App;
