// All protected API requests share one renewal, including concurrent requests.
export function installSessionRefresh(client, api, { onRefresh, onExpired }) {
  let renewal = null;
  let epoch = 0;
  let suspended = false;
  let disposed = false;
  const base = new URL(api, window.location.origin);
  const isProtected = config => {
    const url = new URL(config.url, config.baseURL || window.location.origin);
    return url.origin === base.origin && url.pathname.startsWith(`${base.pathname}/`)
      && !url.pathname.startsWith(`${base.pathname}/public/`)
      && !['login', 'register', 'refresh', 'logout'].some(action => url.pathname === `${base.pathname}/auth/${action}`);
  };
  const expire = () => {
    suspended = true;
    epoch += 1;
    onExpired();
  };
  const requestId = client.interceptors.request.use(config => {
    if (config._authEpoch === undefined) config._authEpoch = epoch;
    return config;
  });
  const responseId = client.interceptors.response.use(response => response, async error => {
    const config = error.config;
    if (error.response?.status !== 401 || !config || !isProtected(config)
        || disposed || suspended || config._authEpoch !== epoch) throw error;
    if (config._sessionRetried) {
      expire();
      throw error;
    }
    config._sessionRetried = true;
    const attemptEpoch = epoch;
    if (!renewal) {
      const work = client.post(`${api}/auth/refresh`, {}, { withCredentials: true })
        .then(response => {
          if (!disposed && !suspended && epoch === attemptEpoch) onRefresh(response.data);
          return response;
        })
        .catch(refreshError => {
          if (!disposed && !suspended && epoch === attemptEpoch && refreshError.response?.status === 401) expire();
          throw refreshError;
        })
        .finally(() => { if (renewal === work) renewal = null; });
      renewal = work;
    }
    await renewal;
    if (disposed || suspended || epoch !== attemptEpoch) throw error;
    return client(config);
  });
  return {
    async suspend() {
      suspended = true;
      epoch += 1;
      // Drain an in-flight renewal before login/logout can change the cookies.
      try { await renewal; } catch (_) { /* Authentication action decides the next state. */ }
    },
    resume() { suspended = false; epoch += 1; },
    dispose() {
      disposed = true;
      epoch += 1;
      client.interceptors.request.eject(requestId);
      client.interceptors.response.eject(responseId);
    }
  };
}
