import axios from 'axios';
import { installSessionRefresh } from './sessionRefresh';

function reject(config, status) {
  const error = new Error('isolated test failure');
  error.config = config;
  if (status) error.response = { status, config };
  return Promise.reject(error);
}
const ok = (config, data = {}) => ({ config, data, status: 200, headers: {}, statusText: 'OK' });
const tick = () => new Promise(resolve => setTimeout(resolve, 0));

test('concurrent expired requests share one renewal and each retries once', async () => {
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  const onRefresh = jest.fn();
  const onExpired = jest.fn();
  let renewals = 0;
  const attempts = {};
  const client = axios.create({ adapter: async config => {
    if (config.url === '/api/auth/refresh') {
      renewals += 1;
      await gate;
      return ok(config, { role: 'Voluntário', access_approved: true });
    }
    attempts[config.url] = (attempts[config.url] || 0) + 1;
    return config._sessionRetried ? ok(config) : reject(config, 401);
  } });
  const control = installSessionRefresh(client, '/api', { onRefresh, onExpired });
  const requests = Array.from({ length: 8 }, (_, index) => client.get(`/api/schedules/${index}`));
  await tick();
  expect(renewals).toBe(1);
  release();
  await Promise.all(requests);
  expect(Object.values(attempts)).toEqual(Array(8).fill(2));
  expect(onRefresh).toHaveBeenCalledTimes(1);
  expect(onExpired).not.toHaveBeenCalled();
  control.dispose();
});

test('expired renewal ends the session once, with no retry loop', async () => {
  let renewals = 0;
  const onExpired = jest.fn();
  const client = axios.create({ adapter: config => {
    if (config.url.endsWith('/auth/refresh')) renewals += 1;
    return reject(config, 401);
  } });
  const control = installSessionRefresh(client, '/api', { onRefresh: jest.fn(), onExpired });
  await Promise.allSettled([client.get('/api/schedules'), client.get('/api/songs')]);
  await expect(client.get('/api/schedules')).rejects.toBeDefined();
  expect(renewals).toBe(1);
  expect(onExpired).toHaveBeenCalledTimes(1);
  control.dispose();
});

test('permission denials, failed login, public and external requests never renew', async () => {
  const adapter = jest.fn(config => reject(config, config.url === '/api/volunteers' ? 403 : 401));
  const client = axios.create({ adapter });
  const onExpired = jest.fn();
  const control = installSessionRefresh(client, '/api', { onRefresh: jest.fn(), onExpired });
  const paths = ['/api/volunteers', '/api/auth/login', '/api/auth/register', '/api/auth/refresh', '/api/auth/logout', '/api/public/schedules/demo', 'https://example.com/api/schedules'];
  await Promise.allSettled(paths.map(path => client.get(path)));
  expect(adapter).toHaveBeenCalledTimes(paths.length);
  expect(onExpired).not.toHaveBeenCalled();
  control.dispose();
});

test('temporary network failure during renewal does not terminate the session', async () => {
  const onExpired = jest.fn();
  const client = axios.create({ adapter: config => reject(config, config.url.endsWith('/auth/refresh') ? undefined : 401) });
  const control = installSessionRefresh(client, '/api', { onRefresh: jest.fn(), onExpired });
  await expect(client.get('/api/schedules')).rejects.toBeDefined();
  expect(onExpired).not.toHaveBeenCalled();
  control.dispose();
});

test('a request still unauthorized after renewal is not retried indefinitely', async () => {
  let requests = 0;
  const onExpired = jest.fn();
  const client = axios.create({ adapter: config => {
    requests += 1;
    return config.url.endsWith('/auth/refresh') ? Promise.resolve(ok(config)) : reject(config, 401);
  } });
  const control = installSessionRefresh(client, '/api', { onRefresh: jest.fn(), onExpired });
  await expect(client.get('/api/schedules')).rejects.toBeDefined();
  expect(requests).toBe(3);
  expect(onExpired).toHaveBeenCalledTimes(1);
  control.dispose();
});

test('logout drains renewal and prevents old requests from being retried', async () => {
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  const onRefresh = jest.fn();
  const adapter = jest.fn(async config => {
    if (config.url.endsWith('/auth/refresh')) { await gate; return ok(config); }
    return reject(config, 401);
  });
  const client = axios.create({ adapter });
  const control = installSessionRefresh(client, '/api', { onRefresh, onExpired: jest.fn() });
  const result = client.get('/api/schedules').catch(error => error);
  await tick();
  const drained = control.suspend();
  release();
  await drained;
  await result;
  expect(onRefresh).not.toHaveBeenCalled();
  expect(adapter).toHaveBeenCalledTimes(2);
  control.dispose();
});
