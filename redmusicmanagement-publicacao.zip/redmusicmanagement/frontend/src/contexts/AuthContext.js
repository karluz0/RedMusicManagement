import React, { createContext, useState, useContext, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import { installSessionRefresh } from './sessionRefresh';
import { apiErrorMessage } from '@/lib/apiError';

const AuthContext = createContext(null);
const API = `${process.env.REACT_APP_BACKEND_URL || ''}/api`;

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const sessionControl = useRef(null);
  const checkAuth = useCallback(async (isCurrent = () => true) => {
    try {
      const { data } = await axios.get(`${API}/auth/me`, { withCredentials: true });
      if (isCurrent()) setUser(data);
    } catch (error) {
      if (isCurrent()) setUser(false);
    } finally {
      if (isCurrent()) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const control = installSessionRefresh(axios, API, { onRefresh: setUser, onExpired: () => setUser(false) });
    sessionControl.current = control;
    let active = true;
    checkAuth(() => active);
    return () => { active = false; control.dispose(); };
  }, [checkAuth]);

  const login = async (email, password) => {
    await sessionControl.current?.suspend();
    try {
      const { data } = await axios.post(
        `${API}/auth/login`,
        { email, password },
        { withCredentials: true }
      );
      sessionControl.current?.resume();
      setUser(data);
      return { success: true };
    } catch (e) {
      return { success: false, error: apiErrorMessage(e, 'Não foi possível entrar. Tente novamente.') };
    }
  };

  const register = async (email, password, name, role = "Voluntário") => {
    await sessionControl.current?.suspend();
    try {
      const { data } = await axios.post(
        `${API}/auth/register`,
        { email, password, name, role },
        { withCredentials: true }
      );
      sessionControl.current?.resume();
      setUser(data);
      return { success: true };
    } catch (e) {
      return { success: false, error: apiErrorMessage(e, 'Não foi possível criar a conta. Tente novamente.') };
    }
  };

  const logout = async () => {
    await sessionControl.current?.suspend();
    try {
      await axios.post(`${API}/auth/logout`, {}, { withCredentials: true });
      setUser(false);
    } catch (e) {
      console.error(e);
      sessionControl.current?.resume();
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, checkAuth }}>
      {children}
    </AuthContext.Provider>
  );
};
