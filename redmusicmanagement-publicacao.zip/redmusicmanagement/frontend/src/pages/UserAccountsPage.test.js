import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import axios from 'axios';
import { toast } from 'sonner';
import { UserAccountsPage } from './UserAccountsPage';
jest.mock('axios');
jest.mock('sonner', () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
let root, container;
const accounts = [
  { id: 'admin', email: 'admin@redmusic.com', name: 'Admin', role: 'Administrador', can_change_role: false },
  { id: 'ana', email: 'ana@example.com', name: 'Ana', role: 'Voluntário', volunteer_name: 'Ana', can_change_role: true },
  { id: 'pending', email: 'pending@example.com', name: 'Pendente', role: 'Voluntário', can_change_role: false }
];
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true; jest.clearAllMocks();
  axios.get.mockResolvedValue({ data: accounts }); axios.put.mockResolvedValue({ data: {} });
  container = document.createElement('div'); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });
test('administrator is fixed, pending accounts are disabled, and approved volunteers can become managers', async () => {
  await act(async () => root.render(<UserAccountsPage />));
  expect(container.querySelector('[aria-label="Tipo de acesso de admin@redmusic.com"]')).toBeNull();
  expect(container.querySelector('[aria-label="Tipo de acesso de pending@example.com"]').disabled).toBe(true);
  const select = container.querySelector('[aria-label="Tipo de acesso de ana@example.com"]');
  await act(async () => { select.value = 'Gestor'; select.dispatchEvent(new Event('change', { bubbles: true })); });
  const save = [...container.querySelectorAll('button')].find(item => item.textContent==='Salvar acesso' && !item.disabled);
  await act(async () => save.click());
  expect(axios.put).toHaveBeenCalledWith('/api/users/ana/role', { role:'Gestor' }, { withCredentials:true });
  expect(toast.success).toHaveBeenCalledWith('Tipo de acesso atualizado');
});
test('loading failure shows retry and does not expose stale controls', async () => {
  axios.get.mockRejectedValue(new Error('network failure'));
  await act(async () => root.render(<UserAccountsPage />));
  expect(container.querySelector('[role="alert"]')).not.toBeNull(); expect(container.querySelector('select')).toBeNull();
  axios.get.mockResolvedValue({ data:accounts });
  await act(async () => [...container.querySelectorAll('button')].find(item=>item.textContent==='Tentar novamente').click());
  expect(container.querySelector('[aria-label="Tipo de acesso de ana@example.com"]')).not.toBeNull();
});
