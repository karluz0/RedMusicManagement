import { MonthlyGridView } from "@/pages/MonthlyGridView";
import { ministryStyle } from "@/lib/ministryTheme";
import { BandLeader, ConfirmRemoval } from "@/components/StaffActions";
import { useState, useEffect, useCallback, useRef } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { apiErrorMessage } from "@/lib/apiError";
import {
  MONTHLY_FUNCTIONS,
  monthDays,
  groupParticipations,
  dailyPrompts,
  dayLabel,
} from "@/lib/monthlyPlanning";

const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api`;
const config = { withCredentials: true };
const field = "w-full border rounded-md p-2 bg-white text-sm";
const accent = "bg-[#c72137] hover:bg-[#a91c2e] text-white";
const statusLabel = (status) =>
  status === "Preciso de Substituto"
    ? "Ajuste solicitado"
    : status === "Pendente"
      ? "Aguardando confirmação"
      : status;

function usePlanningRefresh(reload) {
  useEffect(() => {
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") reload();
    }, 30000);
    const refresh = () => reload();
    window.addEventListener("focus", refresh);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", refresh);
    };
  }, [reload]);
}

function DailyAvailability({ plans, reload }) {
  const prompts = dailyPrompts(plans);
  const [changes, setChanges] = useState({});
  const [saving, setSaving] = useState(false);
  if (!prompts.length) return null;
  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await axios.put(
        `${API}/daily-availability`,
        {
          responses: Object.entries(changes).map(([date, available]) => ({
            date,
            available,
          })),
        },
        config,
      );
      setChanges({});
      await reload();
      toast.success("Disponibilidade salva para todos os seus ministérios");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      setChanges({});
      await reload();
    } finally {
      setSaving(false);
    }
  };
  return (
    <Card data-testid="daily-availability-panel">
      <CardHeader>
        <CardTitle>Sua disponibilidade</CardTitle>
        <p className="text-sm text-gray-600">
          Responda uma vez por dia. A resposta vale para Red e Pulse; ela não
          inclui você automaticamente em uma equipe.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={save} className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            <Button
              type="button"
              variant="outline"
              disabled={saving}
              onClick={() =>
                setChanges(
                  Object.fromEntries(prompts.map((item) => [item.date, true])),
                )
              }
            >
              Marcar todos como disponíveis
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={saving}
              onClick={() =>
                setChanges(
                  Object.fromEntries(prompts.map((item) => [item.date, false])),
                )
              }
            >
              Marcar todos como indisponíveis
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {prompts.map((item) => {
              const value = changes[item.date] ?? item.available;
              return (
                <label
                  key={item.date}
                  className="border rounded-lg p-3 space-y-2"
                >
                  <span className="block font-semibold">
                    {dayLabel(item.date)}
                  </span>
                  <span className="block text-xs text-gray-500">
                    {item.ministries.join(" e ")}
                  </span>
                  <select
                    aria-label={`Disponibilidade ${item.date}`}
                    className={field}
                    disabled={saving}
                    value={value === true ? "yes" : value === false ? "no" : ""}
                    onChange={(event) =>
                      setChanges((previous) => ({
                        ...previous,
                        [item.date]: event.target.value === "yes",
                      }))
                    }
                  >
                    <option value="" disabled>
                      Ainda não respondi
                    </option>
                    <option value="yes">Disponível</option>
                    <option value="no">Indisponível</option>
                  </select>
                </label>
              );
            })}
          </div>
          <Button
            className={accent}
            disabled={saving || !Object.keys(changes).length}
            type="submit"
          >
            {saving ? "Salvando..." : "Salvar disponibilidade"}
          </Button>
          <p className="text-xs text-gray-500">
            Mudanças aparecem para a liderança. Se já estiver escalado, avise
            também pelo pedido de ajuste da sua participação.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}

function ParticipationValidation({ plan, reload }) {
  const [notes, setNotes] = useState({});
  const [saving, setSaving] = useState(false);
  const rows = plan.participations || [];
  if (!rows.length) return null;
  const respond = async (responses) => {
    setSaving(true);
    try {
      await axios.put(
        `${API}/monthly-plans/${plan.id}/responses`,
        { responses },
        config,
      );
      await reload();
      setNotes({});
      toast.success("Resposta enviada à liderança");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      await reload();
    } finally {
      setSaving(false);
    }
  };
  const body = (row, decision) => ({
    schedule_id: row.schedule_id,
    expected_version: row.validation_version,
    decision,
    note: notes[row.schedule_id] || "",
  });
  const pending = rows.filter((row) => row.confirmation_status === "Pendente");
  return (
    <Card data-testid={`validation-${plan.id}`}>
      <CardHeader>
        <CardTitle>
          {plan.ministry} · {plan.year_month}
        </CardTitle>
        <p className="text-sm text-gray-600">
          {plan.stage === "Concluído"
            ? "Planejamento concluído"
            : "Confira suas participações. Uma resposta confirma todas as suas funções na mesma equipe."}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {plan.stage === "Em Validação" && pending.length > 0 && (
          <Button
            disabled={saving}
            className={accent}
            onClick={() =>
              respond(pending.map((row) => body(row, "Confirmado")))
            }
          >
            Confirmar todas as pendentes
          </Button>
        )}
        {rows.map((row) => {
          const schedule = plan.schedules.find(
            (item) => item.id === row.schedule_id,
          );
          return (
            <section
              className="border rounded-lg p-4 space-y-3"
              key={row.schedule_id}
            >
              <div className="flex justify-between gap-2 flex-wrap">
                <h3 className="font-semibold">
                  {dayLabel(schedule.date)} · {schedule.location}
                </h3>
                <span className="text-sm">
                  {statusLabel(row.confirmation_status)}
                </span>
              </div>
              <p className="text-sm">{row.functions.join(" · ")}</p>
              {row.response_note && (
                <p className="bg-amber-50 p-3 rounded text-sm">
                  Sua observação: {row.response_note}
                </p>
              )}
              {row.adjustment_resolution && (
                <p className="bg-blue-50 p-3 rounded text-sm">
                  Solução da liderança: {row.adjustment_resolution}
                </p>
              )}
              {plan.stage === "Em Validação" &&
                row.confirmation_status !== "Preciso de Substituto" && (
                  <>
                    <Textarea
                      aria-label={`Observação ${schedule.date} ${schedule.location}`}
                      placeholder="Se precisar de ajuste, explique aqui"
                      maxLength={1000}
                      value={notes[row.schedule_id] || ""}
                      disabled={saving}
                      onChange={(event) =>
                        setNotes((previous) => ({
                          ...previous,
                          [row.schedule_id]: event.target.value,
                        }))
                      }
                    />
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        className={accent}
                        disabled={
                          saving || row.confirmation_status === "Confirmado"
                        }
                        onClick={() => respond([body(row, "Confirmado")])}
                      >
                        Confirmar participação
                      </Button>
                      <Button
                        variant="outline"
                        disabled={saving || !notes[row.schedule_id]?.trim()}
                        onClick={() =>
                          respond([body(row, "Preciso de Substituto")])
                        }
                      >
                        Solicitar ajuste
                      </Button>
                    </div>
                  </>
                )}
              {row.confirmation_status === "Preciso de Substituto" && (
                <p className="text-sm text-amber-800">
                  A liderança recebeu sua observação. Aguarde a solução para
                  confirmar novamente.
                </p>
              )}
            </section>
          );
        })}
      </CardContent>
    </Card>
  );
}

export function PlanningDashboard() {
  const { user } = useAuth();
  const leader = ["Administrador", "Gestor"].includes(user?.role);
  const [plans, setPlans] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/monthly-plans`, config);
      setPlans(response.data);
      setError("");
    } catch (error) {
      setError(
        apiErrorMessage(error, "Não foi possível carregar seus planejamentos."),
      );
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    reload();
  }, [reload]);
  usePlanningRefresh(reload);
  if (!leader)
    return (
      <VolunteerDashboard
        plans={plans}
        reload={reload}
        error={error}
        loading={loading}
      />
    );
  return (
    <section className="space-y-5" data-testid="planning-dashboard">
      <div className="flex justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold">
            {leader ? "Planejamento dos próximos meses" : "Meu painel"}
          </h2>
          <p className="text-sm text-gray-500">
            {user?.role === "Administrador" ? "Acompanhe a montagem e as respostas da equipe." : "Disponibilidade, validações e suas participações em um só lugar."}
          </p>
        </div>
        <Button variant="outline" onClick={reload}>
          Atualizar respostas
        </Button>
        <Button asChild variant="outline">
          <Link to="/planning">
            {leader ? "Gerenciar planejamentos" : "Ver planejamentos"}
          </Link>
        </Button>
      </div>
      {loading && <p role="status">Carregando planejamentos...</p>}
      {error && (
        <p role="alert" className="text-red-700">
          {error}{" "}
          <button className="underline" onClick={reload}>
            Tentar novamente
          </button>
        </p>
      )}
      {!loading && !error && !plans.length && (
        <p className="p-5 rounded-lg bg-[#fcf7f6] text-gray-600">
          {leader
            ? "Nenhum planejamento mensal criado. As escalas individuais continuam disponíveis em Escalas."
            : "Nenhum planejamento disponível para seus ministérios. A liderança precisa conferir os ministérios no seu perfil."}
        </p>
      )}
      {leader && (
        <div className="grid md:grid-cols-2 gap-3">
          {plans.map((plan) => (
            <Link
              key={plan.id}
              to={`/planning/${plan.id}`}
              className="border rounded-lg p-4 hover:bg-[#fcf7f6]"
            >
              <p className="font-semibold">
                {plan.ministry} · {plan.year_month}
              </p>
              <p className="text-sm">
                {plan.stage} · {plan.schedules.length} equipes
              </p>
              <p className="text-sm text-gray-500">
                {plan.summary?.pending || 0} pendentes ·{" "}
                {plan.summary?.adjustments || 0} ajustes ·{" "}
                {
                  (plan.members || []).filter((row) => row.availability_warning)
                    .length
                }{" "}
                avisos de disponibilidade
              </p>
            </Link>
          ))}
        </div>
      )}
      {user?.role !== "Administrador" && <>
        <DailyAvailability plans={plans} reload={reload} />
        {plans.map((plan) => <ParticipationValidation key={plan.id} plan={plan} reload={reload} />)}
      </>}
      {!leader &&
        plans.length > 0 &&
        !plans.some((plan) => plan.participations?.length) && (
          <p className="text-gray-500 text-sm">
            Suas participações aparecerão aqui quando a liderança enviar o mês
            para validação.
          </p>
        )}
    </section>
  );
}

function VolunteerDashboard({ plans, reload, error, loading }) {
  const [month, setMonth] = useState(() =>
    new Date().toLocaleDateString("sv-SE").slice(0, 7),
  );
  const [filter, setFilter] = useState("Todos");
  const [location, setLocation] = useState("Todos");
  const [scope, setScope] = useState("Todas as escalas");
  const [schedules, setSchedules] = useState([]);
  const [scheduleError, setScheduleError] = useState("");
  const [busy, setBusy] = useState(true);
  const load = useCallback(async () => {
    setBusy(true);
    try {
      const { data } = await axios.get(`${API}/volunteer-dashboard`, {
        ...config,
        params: { year_month: month },
      });
      return data;
    } catch (err) {
      throw err;
    }
  }, [month]);
  useEffect(() => {
    let active = true;
    load()
      .then((data) => {
        if (active) {
          setSchedules(data);
          setScheduleError("");
        }
      })
      .catch((err) => {
        if (active) setScheduleError(apiErrorMessage(err));
      })
      .finally(() => {
        if (active) setBusy(false);
      });
    return () => {
      active = false;
    };
  }, [load, plans]);
  const visible = schedules.filter(
    (item) =>
      (filter === "Todos" || (item.ministry || "Red Music") === filter) &&
      (filter !== "Red Music" ||
        location === "Todos" ||
        item.location === location) &&
      (scope === "Todas as escalas" ||
        (scope === "Minhas participações"
          ? item.functions.length > 0
          : item.available === true)),
  );
  const pending = plans.filter(
    (plan) =>
      plan.stage === "Em Validação" &&
      plan.participations?.some(
        (row) => row.confirmation_status === "Pendente",
      ),
  );
  const prompts = dailyPrompts(plans);
  return (
    <section className="space-y-6" data-testid="volunteer-dashboard">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Meu painel</h1>
          <p className="text-gray-500 mt-1">
            Suas músicas e participações, em um só lugar.
          </p>
        </div>
        <Button variant="outline" onClick={reload}>
          Atualizar
        </Button>
      </div>
      {error && (
        <p role="alert" className="text-red-700">
          {error}
        </p>
      )}
      {prompts.length > 0 && (
        <details className="rounded-xl border bg-white p-4">
          <summary className="cursor-pointer font-medium">
            Disponibilidade ·{" "}
            {prompts.filter((row) => row.available == null).length
              ? "Há datas para responder"
              : "Editar minhas respostas"}
          </summary>
          <div className="mt-4">
            <DailyAvailability plans={plans} reload={reload} />
          </div>
        </details>
      )}
      {pending.map((plan) => (
        <details
          key={plan.id}
          className="rounded-xl border border-amber-200 bg-white p-4"
        >
          <summary className="cursor-pointer font-medium">
            Confirmar participações · {plan.ministry} · {plan.year_month}
          </summary>
          <div className="mt-4">
            <ParticipationValidation plan={plan} reload={reload} />
          </div>
        </details>
      ))}
      {plans
        .filter(
          (plan) =>
            plan.participations?.length &&
            !pending.some((item) => item.id === plan.id),
        )
        .map((plan) => (
          <details key={plan.id} className="rounded-xl border bg-white p-4">
            <summary className="cursor-pointer text-sm">
              Minhas respostas · {plan.ministry} · {plan.year_month}
            </summary>
            <div className="mt-4">
              <ParticipationValidation plan={plan} reload={reload} />
            </div>
          </details>
        ))}
      <div className="flex flex-wrap gap-3 items-end">
        <label className="text-sm">
          Mês
          <Input
            type="month"
            value={month}
            onChange={(event) => {
              if (event.target.value) setMonth(event.target.value);
            }}
          />
        </label>
        <label className="text-sm">
          Ministério
          <select
            className={field}
            value={filter}
            onChange={(event) => setFilter(event.target.value)}
          >
            <option>Todos</option>
            <option>Red Music</option>
            <option>Pulse Music</option>
          </select>
        </label>
        {filter === "Red Music" && (
          <label className="text-sm">
            Local
            <select
              aria-label="Local"
              className={field}
              value={location}
              onChange={(event) => setLocation(event.target.value)}
            >
              <option>Todos</option>
              <option>Indaiatuba</option>
              <option>Itu</option>
            </select>
          </label>
        )}
        <label className="text-sm">
          Mostrar
          <select
            className={field}
            value={scope}
            onChange={(event) => setScope(event.target.value)}
          >
            <option>Todas as escalas</option>
            <option>Minhas participações</option>
            <option>Dias em que estou disponível</option>
          </select>
        </label>
      </div>
      {scope === "Dias em que estou disponível" && (
        <p className="text-sm text-gray-500">
          Disponibilidade informada não significa que você foi escalado.
        </p>
      )}
      {busy || loading ? (
        <p role="status">Carregando escalas...</p>
      ) : scheduleError ? (
        <p role="alert" className="text-red-700">
          {scheduleError}
        </p>
      ) : (
        <MonthlyGridView schedules={visible} hydrated volunteer />
      )}
    </section>
  );
}

function MemberPool({
  schedules,
  target,
  setTarget,
  selectedPerson,
  setSelectedPerson,
  version,
  onDragBegin,
  onDragMove,
  onDragEnd,
}) {
  const schedule = schedules.find((item) => item.id === target) || schedules[0];
  const scheduleId = schedule?.id;
  const [exceptions, setExceptions] = useState(false);
  const [reason, setReason] = useState("");
  const [people, setPeople] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    setSelectedPerson(null);
    if (!scheduleId) return;
    let active = true;
    setLoading(true);
    setPeople([]);
    setError("");
    axios
      .get(
        `${API}/schedules/${scheduleId}/available-volunteers?include_exceptions=${exceptions}`,
        config,
      )
      .then(({ data }) => {
        if (active) setPeople(data);
      })
      .catch((err) => {
        if (active) setError(apiErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [scheduleId, exceptions, version, setSelectedPerson]);
  if (!schedule) return null;
  const groups = [...MONTHLY_FUNCTIONS, "Outras funções"];
  const functions = (person) => [
    ...(person.instruments || []),
    ...(person.functions || []),
  ];
  return (
    <Card data-testid="member-pool">
      <CardContent className="p-4 space-y-4">
        <div className="flex gap-4 flex-wrap items-end">
          <label className="text-sm flex-1">
            Pessoas para a equipe
            <select
              aria-label="Equipe para montagem"
              className={field}
              value={schedule.id}
              onChange={(event) => {
                setSelectedPerson(null);
                setTarget(event.target.value);
              }}
            >
              {schedules.map((item) => (
                <option key={item.id} value={item.id}>
                  {dayLabel(item.date)} · {item.location}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm flex items-center gap-2">
            <input
              type="checkbox"
              checked={exceptions}
              onChange={(event) => {
                setExceptions(event.target.checked);
                setSelectedPerson(null);
              }}
            />
            Mostrar exceções
          </label>
        </div>
        <p className="text-sm text-gray-500">
          Arraste um nome até uma função da equipe selecionada. No celular ou
          teclado, selecione o nome e toque em “Adicionar” na grade.
        </p>
        {exceptions && (
          <Textarea
            aria-label="Justificativa da exceção"
            placeholder="Justificativa para incluir alguém fora da disponibilidade"
            maxLength={500}
            value={reason}
            onChange={(event) => {
              setReason(event.target.value);
              setSelectedPerson(null);
            }}
          />
        )}
        {loading && <p role="status">Carregando pessoas...</p>}
        {error && (
          <p role="alert" className="text-red-700">
            {error}
          </p>
        )}
        {!loading && !error && !people.length && (
          <p className="text-sm text-gray-500">
            Nenhuma pessoa disponível para esta equipe. Consulte as exceções se
            necessário.
          </p>
        )}
        <div className="flex gap-5 overflow-x-auto pb-2">
          {groups.map((func) => {
            const rows = people.filter((person) =>
              func === "Outras funções"
                ? !functions(person).some((value) =>
                    MONTHLY_FUNCTIONS.includes(value),
                  )
                : functions(person).includes(func),
            );
            if (!rows.length) return null;
            return (
              <div key={func} className="min-w-40">
                <h3 className="text-xs uppercase font-semibold text-gray-500 mb-2">
                  {func}
                </h3>
                <div className="space-y-2">
                  {rows.map((person) => {
                    const disabled =
                      person.day_conflict ||
                      (!person.explicitly_available && !reason.trim());
                    const payload = { ...person, source: schedule.id, reason };
                    return (
                      <button
                        type="button"
                        key={person.id}
                        disabled={disabled}
                        style={{
                          touchAction: "none",
                          cursor: disabled ? "default" : "grab",
                        }}
                        onPointerDown={(event) => {
                          if (disabled) return;
                          event.currentTarget.setPointerCapture(
                            event.pointerId,
                          );
                          onDragBegin(payload, event.clientX, event.clientY);
                        }}
                        onPointerMove={(event) =>
                          onDragMove(event.clientX, event.clientY)
                        }
                        onPointerUp={(event) =>
                          onDragEnd(event.clientX, event.clientY)
                        }
                        onPointerCancel={() => onDragEnd(null, null)}
                        onClick={() => setSelectedPerson(payload)}
                        aria-pressed={selectedPerson?.id === person.id}
                        className={`block w-full rounded-lg border p-3 text-left text-sm disabled:opacity-40 ${selectedPerson?.id === person.id ? "border-[#c72137] bg-red-50" : "bg-white hover:border-gray-400"}`}
                      >
                        <span>{person.name}</span>
                        {!person.explicitly_available && (
                          <span className="block text-xs text-amber-800">
                            {person.availability_status}
                          </span>
                        )}
                        {person.day_conflict && (
                          <span className="block text-xs text-red-700">
                            Outra equipe neste dia
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        {selectedPerson && (
          <p role="status" className="text-sm text-[#c72137]">
            {selectedPerson.name} selecionado. Escolha uma função na equipe.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function CreatePlan({ onCreated }) {
  const [month, setMonth] = useState(() =>
    new Date().toLocaleDateString("sv-SE").slice(0, 7),
  );
  const [ministry, setMinistry] = useState("Red Music");
  const [dates, setDates] = useState([]);
  const [deadline, setDeadline] = useState("");
  const [saving, setSaving] = useState(false);
  const today = new Date().toLocaleDateString("sv-SE");
  const days = monthDays(month);
  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const { data } = await axios.post(
        `${API}/monthly-plans`,
        {
          year_month: month,
          ministry,
          dates,
          availability_deadline: deadline || null,
        },
        config,
      );
      toast.success(
        "Planejamento aberto. As datas já aparecem no painel dos voluntários.",
      );
      onCreated(data.id);
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setSaving(false);
    }
  };
  return (
    <form
      onSubmit={save}
      className="space-y-5"
      data-testid="create-monthly-plan"
    >
      <div className="grid sm:grid-cols-3 gap-4">
        <label className="text-sm space-y-2">
          Mês
          <Input
            type="month"
            required
            value={month}
            disabled={saving}
            onChange={(event) => {
              setMonth(event.target.value);
              setDates([]);
              setDeadline("");
            }}
          />
        </label>
        <label className="text-sm space-y-2">
          Ministério
          <select
            className={field}
            value={ministry}
            disabled={saving}
            onChange={(event) => setMinistry(event.target.value)}
          >
            <option>Red Music</option>
            <option>Pulse Music</option>
          </select>
        </label>
        <label className="text-sm space-y-2">
          Prazo de resposta (opcional)
          <Input
            type="date"
            min={today}
            max={dates.length ? [...dates].sort()[0] : undefined}
            value={deadline}
            disabled={saving}
            onChange={(event) => setDeadline(event.target.value)}
          />
        </label>
      </div>
      <p className="p-3 rounded bg-[#fcf7f6] text-sm">
        {ministry === "Red Music"
          ? "Serão criadas duas equipes por data: Indaiatuba e Itu."
          : "Será criada uma equipe por data."}{" "}
        Cada pessoa poderá ocupar apenas uma equipe por dia, incluindo os dois
        ministérios.
      </p>
      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          disabled={saving}
          onClick={() =>
            setDates(
              days.filter(
                (day) =>
                  day >= today && new Date(`${day}T12:00:00`).getDay() === 0,
              ),
            )
          }
        >
          Selecionar domingos
        </Button>
        <Button
          type="button"
          variant="ghost"
          disabled={saving}
          onClick={() => setDates([])}
        >
          Limpar datas
        </Button>
      </div>
      <fieldset>
        <legend className="text-sm font-medium mb-3">Datas do mês</legend>
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
          {days.map((day) => (
            <label
              key={day}
              className={`border rounded p-2 text-center text-sm ${dates.includes(day) ? "bg-[#f7e1e1] border-[#c72137]" : ""} ${day < today ? "opacity-40" : "cursor-pointer"}`}
            >
              <input
                type="checkbox"
                className="mr-1"
                disabled={saving || day < today}
                checked={dates.includes(day)}
                onChange={() =>
                  setDates((previous) =>
                    previous.includes(day)
                      ? previous.filter((value) => value !== day)
                      : [...previous, day],
                  )
                }
              />
              {dayLabel(day)}
            </label>
          ))}
        </div>
      </fieldset>
      <Button
        type="submit"
        disabled={saving || !dates.length}
        className={accent}
      >
        {saving ? "Criando..." : `Abrir coleta · ${dates.length} data(s)`}
      </Button>
    </form>
  );
}

function LeaderPlan({ plan, reload }) {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [solutions, setSolutions] = useState({});
  const [city, setCity] = useState("Todos");
  const [target, setTarget] = useState(null);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [poolVersion, setPoolVersion] = useState(0);
  const [dragOver, setDragOver] = useState("");
  const [inspectedMember, setInspectedMember] = useState(null);
  const [pointerDrag, setPointerDrag] = useState(null);
  const dragRef = useRef(null);
  const editable = plan.stage === "Montagem";
  const actions = {
    Coleta: [["montar", "Iniciar montagem das equipes"]],
    Montagem: [["validar", "Enviar mês para validação"]],
    "Em Validação": [
      ["reabrir", "Voltar à montagem"],
      ["publicar", "Concluir e publicar mês"],
    ],
    Concluído: [["reabrir", "Reabrir para alterações"]],
  };
  const mutate = async (operation) => {
    if (saving) return;
    setSaving(true);
    try {
      await operation();
      await reload();
      toast.success("Planejamento atualizado");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      await reload();
    } finally {
      setSaving(false);
    }
  };
  const includePerson = async (person, schedule, func) => {
    if (
      person.day_conflict ||
      (!person.explicitly_available && !person.reason?.trim())
    )
      return;
    await mutate(() =>
      axios.post(
        `${API}/schedules/${schedule.id}/members`,
        {
          volunteer_id: person.id,
          function: func,
          exception_reason: person.reason || "",
        },
        config,
      ),
    );
    setSelectedPerson(null);
    setPoolVersion((value) => value + 1);
  };
  const adjustments = groupParticipations(plan.members).filter(
    (row) => row.confirmation_status === "Preciso de Substituto",
  );
  return (
    <div
      className="ministry-theme space-y-6"
      style={ministryStyle(plan.ministry)}
    >
      <Card>
        <CardContent className="p-5 space-y-4">
          <div className="flex justify-between gap-3 flex-wrap">
            <div>
              <p className="font-semibold text-lg">Etapa: {plan.stage}</p>
              {["Em Validação", "Concluído"].includes(plan.stage) && (
                <p className="text-sm text-gray-500">
                  {plan.summary.confirmed} confirmadas · {plan.summary.pending}{" "}
                  pendentes · {plan.summary.adjustments} ajustes
                </p>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {actions[plan.stage]?.map(([action, label]) => (
                <Button
                  key={action}
                  className={action === "reabrir" ? "" : accent}
                  variant={action === "reabrir" ? "outline" : "default"}
                  disabled={saving}
                  onClick={() =>
                    mutate(() =>
                      axios.post(
                        `${API}/monthly-plans/${plan.id}/stage`,
                        { action },
                        config,
                      ),
                    )
                  }
                >
                  {label}
                </Button>
              ))}
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {plan.stage === "Coleta"
              ? "As datas já aparecem no painel dos voluntários. Encerre a coleta para começar a montagem."
              : plan.stage === "Montagem"
                ? "Monte as equipes na grade. Ao reenviar o mês, confirmações das participações que não mudaram serão mantidas."
                : plan.stage === "Em Validação"
                  ? "Acompanhe as respostas. Para corrigir equipes ou resolver observações, volte à montagem."
                  : "O mês está publicado. Alterações exigem reabertura; somente participações alteradas precisam confirmar novamente."}
          </p>
          {plan.availability_deadline && (
            <p className="text-sm">
              Prazo da disponibilidade: {dayLabel(plan.availability_deadline)}
            </p>
          )}
        </CardContent>
      </Card>
      {plan.ministry === "Red Music" && (
        <label className="block max-w-xs text-sm">
          Local
          <select
            className={field}
            aria-label="Filtrar cidade"
            value={city}
            onChange={(event) => setCity(event.target.value)}
          >
            <option>Todos</option>
            <option>Indaiatuba</option>
            <option>Itu</option>
          </select>
        </label>
      )}
      {editable && (
        <MemberPool
          key={plan.id}
          schedules={plan.schedules.filter(
            (item) => city === "Todos" || item.location === city,
          )}
          target={target}
          setTarget={setTarget}
          selectedPerson={selectedPerson}
          setSelectedPerson={setSelectedPerson}
          version={poolVersion}
          onDragBegin={(person, x, y) => {
            dragRef.current = { person, x, y, startX: x, startY: y };
          }}
          onDragMove={(x, y) => {
            if (dragRef.current) {
              const value = { ...dragRef.current, x, y };
              dragRef.current = value;
              if (Math.hypot(x - value.startX, y - value.startY) > 8)
                setPointerDrag(value);
            }
          }}
          onDragEnd={(x, y) => {
            const value = dragRef.current;
            dragRef.current = null;
            setPointerDrag(null);
            if (
              !value ||
              x === null ||
              Math.hypot(x - value.startX, y - value.startY) <= 8 ||
              saving
            )
              return;
            const slot = document
              .elementFromPoint(x, y)
              ?.closest("[data-drop-schedule]");
            if (!slot) return;
            const schedule = plan.schedules.find(
              (item) => item.id === slot.dataset.dropSchedule,
            );
            if (schedule?.id !== value.person.source)
              return toast.error(
                "Selecione essa equipe no painel de pessoas antes de arrastar.",
              );
            includePerson(value.person, schedule, slot.dataset.dropFunction);
          }}
        />
      )}
      <ConfirmRemoval
        label="Excluir planejamento inteiro"
        title={`Excluir ${plan.ministry} · ${plan.year_month}?`}
        description={`Todas as ${plan.schedules.length} equipes deste planejamento, suas participações, repertórios e histórico do mês serão removidos. Escalas individuais e o outro ministério permanecem.`}
        onConfirm={async () => {
          await axios.delete(`${API}/monthly-plans/${plan.id}`, config);
          toast.success("Planejamento excluído");
          navigate("/planning");
        }}
      />
      <div className="overflow-x-auto pb-4" data-testid="planning-grid">
        <div className="flex gap-4 items-start">
          {plan.schedules
            .filter((item) => city === "Todos" || item.location === city)
            .map((schedule) => (
              <section
                key={schedule.id}
                className="w-64 shrink-0 border rounded-lg overflow-hidden bg-white"
              >
                <header className="bg-[#c72137] text-white p-4">
                  <h3 className="font-bold text-lg">
                    {dayLabel(schedule.date)}
                  </h3>
                  <p>{schedule.location}</p>
                  <Link
                    className="text-xs underline"
                    to={`/schedules/${schedule.id}`}
                  >
                    Abrir repertório e detalhes
                  </Link>
                </header>
                <div className="px-3">
                  <BandLeader schedule={schedule} reload={reload} />
                </div>
                <div className="p-3 space-y-3">
                  {MONTHLY_FUNCTIONS.map((func) => (
                    <div
                      key={func}
                      data-drop-schedule={schedule.id}
                      data-drop-function={func}
                      className={`rounded p-1 ${editable ? "border border-dashed min-h-16" : ""} ${dragOver === schedule.id + func ? "bg-red-50 border-red-500" : ""}`}
                      onDragOver={(event) => {
                        if (editable && !saving) {
                          event.preventDefault();
                          setDragOver(schedule.id + func);
                        }
                      }}
                      onDragLeave={() => setDragOver("")}
                      onDrop={(event) => {
                        event.preventDefault();
                        setDragOver("");
                        if (!editable || saving) return;
                        try {
                          const person = JSON.parse(
                            event.dataTransfer.getData(
                              "application/redmusic-person",
                            ),
                          );
                          if (person.source !== schedule.id)
                            return toast.error(
                              "Selecione essa equipe no painel de pessoas antes de arrastar.",
                            );
                          includePerson(person, schedule, func);
                        } catch {
                          toast.error("Selecione uma pessoa no painel.");
                        }
                      }}
                    >
                      <p className="text-xs font-semibold uppercase text-[#c72137]">
                        {func}
                      </p>
                      {plan.members
                        .filter(
                          (member) =>
                            member.schedule_id === schedule.id &&
                            member.function === func,
                        )
                        .map((member) => (
                          <div
                            className="border rounded p-2 my-1 text-sm space-y-1"
                            key={member.id}
                          >
                            <div className="flex justify-between items-start gap-1">
                              <button
                                type="button"
                                className="font-medium text-left hover:underline"
                                onClick={() => setInspectedMember(member)}
                              >
                                {member.volunteer_name}
                              </button>
                              {editable && (
                                <button
                                  className="text-red-700 px-1"
                                  disabled={saving}
                                  aria-label={`Remover ${member.volunteer_name} ${member.function} ${schedule.location} ${schedule.date}`}
                                  onClick={() =>
                                    mutate(() =>
                                      axios.delete(
                                        `${API}/schedules/${schedule.id}/members/${member.id}`,
                                        config,
                                      ),
                                    )
                                  }
                                >
                                  ×
                                </button>
                              )}
                            </div>
                            {["Em Validação", "Concluído"].includes(
                              plan.stage,
                            ) && (
                              <span
                                className={`inline-block rounded-full px-2 py-0.5 text-xs ${member.confirmation_status === "Confirmado" ? "bg-green-50 text-green-800" : member.confirmation_status === "Preciso de Substituto" ? "bg-red-50 text-red-800" : "bg-amber-50 text-amber-800"}`}
                              >
                                {member.confirmation_status === "Pendente"
                                  ? "Pendente"
                                  : statusLabel(member.confirmation_status)}
                              </span>
                            )}
                          </div>
                        ))}
                      {!plan.members.some(
                        (member) =>
                          member.schedule_id === schedule.id &&
                          member.function === func,
                      ) && <div className="text-gray-300 text-xs py-1">—</div>}
                      {editable && (
                        <button
                          type="button"
                          className="text-xs text-gray-500 hover:text-[#c72137] w-full text-left py-2"
                          disabled={saving}
                          onClick={() => {
                            if (selectedPerson?.source === schedule.id)
                              includePerson(selectedPerson, schedule, func);
                            else {
                              setTarget(schedule.id);
                              setSelectedPerson(null);
                            }
                          }}
                          aria-label={`Adicionar ${func} ${schedule.location} ${schedule.date}`}
                        >
                          {selectedPerson?.source === schedule.id
                            ? `Incluir ${selectedPerson.name}`
                            : "+ Adicionar"}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            ))}
        </div>
      </div>
      {pointerDrag && (
        <div
          className="fixed z-50 pointer-events-none bg-[#c72137] text-white rounded-lg shadow-lg px-3 py-2 text-sm"
          style={{ left: pointerDrag.x + 10, top: pointerDrag.y + 10 }}
        >
          {pointerDrag.person.name}
        </div>
      )}
      <Dialog
        open={!!inspectedMember}
        onOpenChange={(open) => {
          if (!open) setInspectedMember(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{inspectedMember?.volunteer_name}</DialogTitle>
          </DialogHeader>
          <p>{inspectedMember?.function}</p>
          {inspectedMember?.exception_reason && (
            <p className="text-sm">
              Exceção: {inspectedMember.exception_reason}
            </p>
          )}
          {inspectedMember?.availability_warning && (
            <p className="text-sm text-amber-800">
              Disponibilidade não confirmada para este dia.
            </p>
          )}
          {inspectedMember && !inspectedMember.account_ready && (
            <Link
              className="underline text-sm"
              to={`/volunteers/${inspectedMember.volunteer_id}`}
            >
              Conferir perfil e conta vinculada
            </Link>
          )}
        </DialogContent>
      </Dialog>
      {adjustments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Solicitações de ajuste</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {adjustments.map((row) => {
              const schedule = plan.schedules.find(
                (item) => item.id === row.schedule_id,
              );
              const key = `${row.schedule_id}:${row.volunteer_id}`;
              return (
                <section key={key} className="border rounded p-4 space-y-3">
                  <p className="font-semibold">
                    {row.volunteer_name} · {dayLabel(schedule.date)} ·{" "}
                    {schedule.location}
                  </p>
                  <p className="text-sm">{row.response_note}</p>
                  <Textarea
                    aria-label={`Solução para ${row.volunteer_name}`}
                    placeholder="Descreva o ajuste combinado. Se trocar a pessoa, remova e adicione pela grade."
                    value={solutions[key] || ""}
                    maxLength={1000}
                    disabled={!editable || saving}
                    onChange={(event) =>
                      setSolutions((previous) => ({
                        ...previous,
                        [key]: event.target.value,
                      }))
                    }
                  />
                  <Button
                    variant="outline"
                    disabled={!editable || saving || !solutions[key]?.trim()}
                    onClick={() =>
                      mutate(() =>
                        axios.put(
                          `${API}/monthly-plans/${plan.id}/resolve`,
                          {
                            schedule_id: row.schedule_id,
                            volunteer_id: row.volunteer_id,
                            expected_version: row.validation_version,
                            resolution: solutions[key],
                          },
                          config,
                        ),
                      )
                    }
                  >
                    Registrar solução e pedir nova confirmação
                  </Button>
                </section>
              );
            })}
          </CardContent>
        </Card>
      )}
      <details className="border rounded p-4">
        <summary className="cursor-pointer font-semibold">
          Disponibilidade recebida por voluntário
        </summary>
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th className="text-left p-2">Voluntário</th>
                {plan.dates.map((day) => (
                  <th className="p-2 whitespace-nowrap" key={day}>
                    {dayLabel(day)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {plan.availability_overview.map((person) => (
                <tr className="border-t" key={person.id}>
                  <th className="text-left p-2 whitespace-nowrap font-normal">
                    {person.name}
                  </th>
                  {plan.dates.map((day) => (
                    <td className="p-2 text-center" key={day}>
                      {person.responses[day] === true
                        ? "Disponível"
                        : person.responses[day] === false
                          ? "Indisponível"
                          : "Sem resposta"}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
      <details className="border rounded p-4">
        <summary className="cursor-pointer font-semibold">
          Histórico de alterações e respostas
        </summary>
        <div className="space-y-3 mt-4">
          {plan.events.map((event, index) => (
            <div key={index} className="text-sm border-t pt-2">
              <p className="font-medium">{event.title}</p>
              <p className="text-gray-600 break-words">{event.detail}</p>
              <p className="text-xs text-gray-400">
                {new Date(event.created_at).toLocaleString("pt-BR")}
              </p>
            </div>
          ))}
          {!plan.events.length && (
            <p className="text-sm text-gray-500">
              Nenhuma alteração registrada ainda.
            </p>
          )}
        </div>
      </details>
    </div>
  );
}

export function MonthlyPlanningPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const leader = ["Administrador", "Gestor"].includes(user?.role);
  const [plans, setPlans] = useState([]);
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [creating, setCreating] = useState(false);
  const currentId = useRef(id);
  currentId.current = id;
  const loadVersion = useRef(0);
  const reload = useCallback(async () => {
    const version = ++loadVersion.current;
    const isCurrent = () =>
      currentId.current === id && version === loadVersion.current;
    try {
      const response = await axios.get(
        `${API}/monthly-plans${id ? "/" + id : ""}`,
        config,
      );
      if (!isCurrent()) return;
      if (id) setPlan(response.data);
      else setPlans(response.data);
      setError("");
    } catch (error) {
      if (isCurrent())
        setError(
          apiErrorMessage(error, "Não foi possível carregar o planejamento."),
        );
    } finally {
      if (isCurrent()) setLoading(false);
    }
  }, [id]);
  useEffect(() => {
    setLoading(true);
    setPlan(null);
    reload();
  }, [reload]);
  usePlanningRefresh(reload);
  return (
    <div className="space-y-6" data-testid="monthly-planning-page">
      <div className="flex justify-between items-start gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">
            {plan
              ? `${plan.ministry} · ${plan.year_month}`
              : "Planejamento mensal"}
          </h1>
          <p className="text-gray-500 mt-1">
            Coleta → montagem das equipes → validação → conclusão
          </p>
        </div>
        {id ? (
          <Button asChild variant="outline">
            <Link to="/planning">Todos os planejamentos</Link>
          </Button>
        ) : (
          leader && (
            <Button
              className={accent}
              onClick={() => setCreating((value) => !value)}
            >
              {creating ? "Fechar formulário" : "Criar planejamento"}
            </Button>
          )
        )}
      </div>
      <Button variant="outline" onClick={reload}>
        Atualizar respostas
      </Button>
      <p className="text-sm bg-[#fcf7f6] rounded p-3">
        Eventos autônomos continuam em{" "}
        <Link to="/schedules" className="underline text-[#c72137]">
          Escalas → Nova escala individual
        </Link>
        , sem necessidade de validação dos voluntários.
      </p>
      {creating && !id && (
        <Card>
          <CardHeader>
            <CardTitle>Abrir um mês</CardTitle>
          </CardHeader>
          <CardContent>
            <CreatePlan
              onCreated={(newId) => {
                setCreating(false);
                navigate(`/planning/${newId}`);
              }}
            />
          </CardContent>
        </Card>
      )}
      {loading && <p role="status">Carregando...</p>}
      {error && (
        <p role="alert" className="text-red-700">
          {error}{" "}
          <button className="underline" onClick={reload}>
            Tentar novamente
          </button>
        </p>
      )}
      {!loading && !error && !id && (
        <div className="grid md:grid-cols-2 gap-4">
          {plans.map((item) => (
            <Link
              className="border rounded-lg p-5 hover:bg-[#fcf7f6]"
              to={`/planning/${item.id}`}
              key={item.id}
            >
              <h2 className="font-semibold text-lg">
                {item.ministry} · {item.year_month}
              </h2>
              <p className="text-sm text-gray-500 mt-2">
                {item.stage} · {item.dates.length} datas ·{" "}
                {item.schedules.length} equipes
              </p>
            </Link>
          ))}
          {!plans.length && (
            <p className="text-gray-500 py-6">
              Nenhum planejamento disponível.
            </p>
          )}
        </div>
      )}
      {!loading &&
        !error &&
        plan &&
        (leader ? (
          <LeaderPlan plan={plan} reload={reload} />
        ) : (
          <div className="space-y-5">
            <p className="font-semibold">Etapa: {plan.stage}</p>
            <DailyAvailability plans={[plan]} reload={reload} />
            <ParticipationValidation plan={plan} reload={reload} />
            {!plan.participations?.length && (
              <p className="text-sm text-gray-500">
                Suas participações aparecerão após o envio para validação.
              </p>
            )}
          </div>
        ))}
    </div>
  );
}
