import { useState, useEffect, useCallback, useRef } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { apiErrorMessage } from "@/lib/apiError";
import {
  MONTHLY_FUNCTIONS,
  monthDays,
  groupParticipations,
  dailyPrompts,
  dayLabel,
} from "@/lib/monthlyPlanning";

const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api`;
const config = { withCredentials: true };
const field = "w-full border rounded-md p-2 bg-white text-sm";
const accent = "bg-[#c72137] hover:bg-[#a91c2e] text-white";
const statusLabel = (status) =>
  status === "Preciso de Substituto"
    ? "Ajuste solicitado"
    : status === "Pendente"
      ? "Aguardando confirmação"
      : status;

function usePlanningRefresh(reload) {
  useEffect(() => {
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") reload();
    }, 30000);
    const refresh = () => reload();
    window.addEventListener("focus", refresh);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", refresh);
    };
  }, [reload]);
}

function DailyAvailability({ plans, reload }) {
  const prompts = dailyPrompts(plans);
  const [changes, setChanges] = useState({});
  const [saving, setSaving] = useState(false);
  if (!prompts.length) return null;
  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await axios.put(
        `${API}/daily-availability`,
        {
          responses: Object.entries(changes).map(([date, available]) => ({
            date,
            available,
          })),
        },
        config,
      );
      setChanges({});
      await reload();
      toast.success("Disponibilidade salva para todos os seus ministérios");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      setChanges({});
      await reload();
    } finally {
      setSaving(false);
    }
  };
  return (
    <Card data-testid="daily-availability-panel">
      <CardHeader>
        <CardTitle>Sua disponibilidade</CardTitle>
        <p className="text-sm text-gray-600">
          Responda uma vez por dia. A resposta vale para Red e Pulse; ela não
          inclui você automaticamente em uma equipe.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={save} className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            <Button
              type="button"
              variant="outline"
              disabled={saving}
              onClick={() =>
                setChanges(
                  Object.fromEntries(prompts.map((item) => [item.date, true])),
                )
              }
            >
              Marcar todos como disponíveis
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={saving}
              onClick={() =>
                setChanges(
                  Object.fromEntries(prompts.map((item) => [item.date, false])),
                )
              }
            >
              Marcar todos como indisponíveis
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {prompts.map((item) => {
              const value = changes[item.date] ?? item.available;
              return (
                <label
                  key={item.date}
                  className="border rounded-lg p-3 space-y-2"
                >
                  <span className="block font-semibold">
                    {dayLabel(item.date)}
                  </span>
                  <span className="block text-xs text-gray-500">
                    {item.ministries.join(" e ")}
                  </span>
                  <select
                    aria-label={`Disponibilidade ${item.date}`}
                    className={field}
                    disabled={saving}
                    value={value === true ? "yes" : value === false ? "no" : ""}
                    onChange={(event) =>
                      setChanges((previous) => ({
                        ...previous,
                        [item.date]: event.target.value === "yes",
                      }))
                    }
                  >
                    <option value="" disabled>
                      Ainda não respondi
                    </option>
                    <option value="yes">Disponível</option>
                    <option value="no">Indisponível</option>
                  </select>
                </label>
              );
            })}
          </div>
          <Button
            className={accent}
            disabled={saving || !Object.keys(changes).length}
            type="submit"
          >
            {saving ? "Salvando..." : "Salvar disponibilidade"}
          </Button>
          <p className="text-xs text-gray-500">
            Mudanças aparecem para a liderança. Se já estiver escalado, avise
            também pelo pedido de ajuste da sua participação.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}

function ParticipationValidation({ plan, reload }) {
  const [notes, setNotes] = useState({});
  const [saving, setSaving] = useState(false);
  const rows = plan.participations || [];
  if (!rows.length) return null;
  const respond = async (responses) => {
    setSaving(true);
    try {
      await axios.put(
        `${API}/monthly-plans/${plan.id}/responses`,
        { responses },
        config,
      );
      await reload();
      setNotes({});
      toast.success("Resposta enviada à liderança");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      await reload();
    } finally {
      setSaving(false);
    }
  };
  const body = (row, decision) => ({
    schedule_id: row.schedule_id,
    expected_version: row.validation_version,
    decision,
    note: notes[row.schedule_id] || "",
  });
  const pending = rows.filter((row) => row.confirmation_status === "Pendente");
  return (
    <Card data-testid={`validation-${plan.id}`}>
      <CardHeader>
        <CardTitle>
          {plan.ministry} · {plan.year_month}
        </CardTitle>
        <p className="text-sm text-gray-600">
          {plan.stage === "Concluído"
            ? "Planejamento concluído"
            : "Confira suas participações. Uma resposta confirma todas as suas funções na mesma equipe."}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {plan.stage === "Em Validação" && pending.length > 0 && (
          <Button
            disabled={saving}
            className={accent}
            onClick={() =>
              respond(pending.map((row) => body(row, "Confirmado")))
            }
          >
            Confirmar todas as pendentes
          </Button>
        )}
        {rows.map((row) => {
          const schedule = plan.schedules.find(
            (item) => item.id === row.schedule_id,
          );
          return (
            <section
              className="border rounded-lg p-4 space-y-3"
              key={row.schedule_id}
            >
              <div className="flex justify-between gap-2 flex-wrap">
                <h3 className="font-semibold">
                  {dayLabel(schedule.date)} · {schedule.location}
                </h3>
                <span className="text-sm">
                  {statusLabel(row.confirmation_status)}
                </span>
              </div>
              <p className="text-sm">{row.functions.join(" · ")}</p>
              {row.response_note && (
                <p className="bg-amber-50 p-3 rounded text-sm">
                  Sua observação: {row.response_note}
                </p>
              )}
              {row.adjustment_resolution && (
                <p className="bg-blue-50 p-3 rounded text-sm">
                  Solução da liderança: {row.adjustment_resolution}
                </p>
              )}
              {plan.stage === "Em Validação" &&
                row.confirmation_status !== "Preciso de Substituto" && (
                  <>
                    <Textarea
                      aria-label={`Observação ${schedule.date} ${schedule.location}`}
                      placeholder="Se precisar de ajuste, explique aqui"
                      maxLength={1000}
                      value={notes[row.schedule_id] || ""}
                      disabled={saving}
                      onChange={(event) =>
                        setNotes((previous) => ({
                          ...previous,
                          [row.schedule_id]: event.target.value,
                        }))
                      }
                    />
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        className={accent}
                        disabled={
                          saving || row.confirmation_status === "Confirmado"
                        }
                        onClick={() => respond([body(row, "Confirmado")])}
                      >
                        Confirmar participação
                      </Button>
                      <Button
                        variant="outline"
                        disabled={saving || !notes[row.schedule_id]?.trim()}
                        onClick={() =>
                          respond([body(row, "Preciso de Substituto")])
                        }
                      >
                        Solicitar ajuste
                      </Button>
                    </div>
                  </>
                )}
              {row.confirmation_status === "Preciso de Substituto" && (
                <p className="text-sm text-amber-800">
                  A liderança recebeu sua observação. Aguarde a solução para
                  confirmar novamente.
                </p>
              )}
            </section>
          );
        })}
      </CardContent>
    </Card>
  );
}

export function PlanningDashboard() {
  const { user } = useAuth();
  const leader = ["Administrador", "Líder"].includes(user?.role);
  const [plans, setPlans] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/monthly-plans`, config);
      setPlans(response.data);
      setError("");
    } catch (error) {
      setError(
        apiErrorMessage(error, "Não foi possível carregar seus planejamentos."),
      );
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    reload();
  }, [reload]);
  usePlanningRefresh(reload);
  return (
    <section className="space-y-5" data-testid="planning-dashboard">
      <div className="flex justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold">
            {leader ? "Planejamento dos próximos meses" : "Meu painel"}
          </h2>
          <p className="text-sm text-gray-500">
            Disponibilidade, validações e suas participações em um só lugar.
          </p>
        </div>
        <Button variant="outline" onClick={reload}>
          Atualizar respostas
        </Button>
        <Button asChild variant="outline">
          <Link to="/planning">
            {leader ? "Gerenciar planejamentos" : "Ver planejamentos"}
          </Link>
        </Button>
      </div>
      {loading && <p role="status">Carregando planejamentos...</p>}
      {error && (
        <p role="alert" className="text-red-700">
          {error}{" "}
          <button className="underline" onClick={reload}>
            Tentar novamente
          </button>
        </p>
      )}
      {!loading && !error && !plans.length && (
        <p className="p-5 rounded-lg bg-[#fcf7f6] text-gray-600">
          {leader
            ? "Nenhum planejamento mensal criado. As escalas individuais continuam disponíveis em Escalas."
            : "Nenhum planejamento disponível para seus ministérios. A liderança precisa conferir os ministérios no seu perfil."}
        </p>
      )}
      {leader && (
        <div className="grid md:grid-cols-2 gap-3">
          {plans.map((plan) => (
            <Link
              key={plan.id}
              to={`/planning/${plan.id}`}
              className="border rounded-lg p-4 hover:bg-[#fcf7f6]"
            >
              <p className="font-semibold">
                {plan.ministry} · {plan.year_month}
              </p>
              <p className="text-sm">
                {plan.stage} · {plan.schedules.length} equipes
              </p>
              <p className="text-sm text-gray-500">
                {plan.summary?.pending || 0} pendentes ·{" "}
                {plan.summary?.adjustments || 0} ajustes ·{" "}
                {
                  (plan.members || []).filter((row) => row.availability_warning)
                    .length
                }{" "}
                avisos de disponibilidade
              </p>
            </Link>
          ))}
        </div>
      )}
      <DailyAvailability plans={plans} reload={reload} />
      {plans.map((plan) => (
        <ParticipationValidation key={plan.id} plan={plan} reload={reload} />
      ))}
      {!leader &&
        plans.length > 0 &&
        !plans.some((plan) => plan.participations?.length) && (
          <p className="text-gray-500 text-sm">
            Suas participações aparecerão aqui quando a liderança enviar o mês
            para validação.
          </p>
        )}
    </section>
  );
}

function CreatePlan({ onCreated }) {
  const [month, setMonth] = useState(() =>
    new Date().toLocaleDateString("sv-SE").slice(0, 7),
  );
  const [ministry, setMinistry] = useState("Red Music");
  const [dates, setDates] = useState([]);
  const [deadline, setDeadline] = useState("");
  const [saving, setSaving] = useState(false);
  const today = new Date().toLocaleDateString("sv-SE");
  const days = monthDays(month);
  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      const { data } = await axios.post(
        `${API}/monthly-plans`,
        {
          year_month: month,
          ministry,
          dates,
          availability_deadline: deadline || null,
        },
        config,
      );
      toast.success(
        "Planejamento aberto. As datas já aparecem no painel dos voluntários.",
      );
      onCreated(data.id);
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setSaving(false);
    }
  };
  return (
    <form
      onSubmit={save}
      className="space-y-5"
      data-testid="create-monthly-plan"
    >
      <div className="grid sm:grid-cols-3 gap-4">
        <label className="text-sm space-y-2">
          Mês
          <Input
            type="month"
            required
            value={month}
            disabled={saving}
            onChange={(event) => {
              setMonth(event.target.value);
              setDates([]);
              setDeadline("");
            }}
          />
        </label>
        <label className="text-sm space-y-2">
          Ministério
          <select
            className={field}
            value={ministry}
            disabled={saving}
            onChange={(event) => setMinistry(event.target.value)}
          >
            <option>Red Music</option>
            <option>Pulse Music</option>
          </select>
        </label>
        <label className="text-sm space-y-2">
          Prazo de resposta (opcional)
          <Input
            type="date"
            min={today}
            max={dates.length ? [...dates].sort()[0] : undefined}
            value={deadline}
            disabled={saving}
            onChange={(event) => setDeadline(event.target.value)}
          />
        </label>
      </div>
      <p className="p-3 rounded bg-[#fcf7f6] text-sm">
        {ministry === "Red Music"
          ? "Serão criadas duas equipes por data: Indaiatuba e Itu."
          : "Será criada uma equipe por data."}{" "}
        Cada pessoa poderá ocupar apenas uma equipe por dia, incluindo os dois
        ministérios.
      </p>
      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          disabled={saving}
          onClick={() =>
            setDates(
              days.filter(
                (day) =>
                  day >= today && new Date(`${day}T12:00:00`).getDay() === 0,
              ),
            )
          }
        >
          Selecionar domingos
        </Button>
        <Button
          type="button"
          variant="ghost"
          disabled={saving}
          onClick={() => setDates([])}
        >
          Limpar datas
        </Button>
      </div>
      <fieldset>
        <legend className="text-sm font-medium mb-3">Datas do mês</legend>
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
          {days.map((day) => (
            <label
              key={day}
              className={`border rounded p-2 text-center text-sm ${dates.includes(day) ? "bg-[#f7e1e1] border-[#c72137]" : ""} ${day < today ? "opacity-40" : "cursor-pointer"}`}
            >
              <input
                type="checkbox"
                className="mr-1"
                disabled={saving || day < today}
                checked={dates.includes(day)}
                onChange={() =>
                  setDates((previous) =>
                    previous.includes(day)
                      ? previous.filter((value) => value !== day)
                      : [...previous, day],
                  )
                }
              />
              {dayLabel(day)}
            </label>
          ))}
        </div>
      </fieldset>
      <Button
        type="submit"
        disabled={saving || !dates.length}
        className={accent}
      >
        {saving ? "Criando..." : `Abrir coleta · ${dates.length} data(s)`}
      </Button>
    </form>
  );
}

function AddMonthlyMember({ schedule, reload }) {
  const [open, setOpen] = useState(false);
  const [exceptions, setExceptions] = useState(false);
  const [candidates, setCandidates] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedFunction, setSelectedFunction] = useState("Vocal");
  const [reason, setReason] = useState("");
  useEffect(() => {
    if (!open) return;
    let active = true;
    setLoading(true);
    setError("");
    axios
      .get(
        `${API}/schedules/${schedule.id}/available-volunteers?include_exceptions=${exceptions}`,
        config,
      )
      .then(({ data }) => {
        if (active) setCandidates(data);
      })
      .catch((error) => {
        if (active) setError(apiErrorMessage(error));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [open, exceptions, schedule.id]);
  const add = async (person) => {
    setSaving(true);
    try {
      await axios.post(
        `${API}/schedules/${schedule.id}/members`,
        {
          volunteer_id: person.id,
          function: selectedFunction,
          exception_reason: person.explicitly_available ? "" : reason,
        },
        config,
      );
      await reload();
      setOpen(false);
      setReason("");
      toast.success("Pessoa incluída na equipe");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      await reload();
    } finally {
      setSaving(false);
    }
  };
  return (
    <>
      <Button
        variant="outline"
        className="w-full mt-3"
        onClick={() => {
          setExceptions(false);
          setOpen(true);
        }}
      >
        Adicionar pessoa
      </Button>
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!saving) setOpen(value);
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {dayLabel(schedule.date)} · {schedule.location}
            </DialogTitle>
          </DialogHeader>
          <label className="text-sm">
            Função
            <select
              className={field}
              disabled={saving}
              value={selectedFunction}
              onChange={(event) => setSelectedFunction(event.target.value)}
            >
              {MONTHLY_FUNCTIONS.map((value) => (
                <option key={value}>{value}</option>
              ))}
            </select>
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={exceptions}
              disabled={saving}
              onChange={(event) => setExceptions(event.target.checked)}
            />
            Mostrar também indisponíveis e sem resposta
          </label>
          {exceptions && (
            <Textarea
              aria-label="Justificativa da exceção"
              placeholder="Justificativa obrigatória para incluir alguém fora da disponibilidade"
              maxLength={500}
              value={reason}
              onChange={(event) => setReason(event.target.value)}
            />
          )}
          <p className="text-xs text-gray-500">
            O vínculo com o ministério é definido no perfil. Conflitos com outra
            equipe no mesmo dia não podem ser ignorados.
          </p>
          {loading && <p role="status">Carregando pessoas...</p>}
          {error && (
            <p role="alert" className="text-red-700">
              {error}
            </p>
          )}
          {!loading && !error && !candidates.length && (
            <p>
              Nenhuma pessoa disponível. Confira os vínculos com o ministério ou
              consulte as exceções.
            </p>
          )}
          {!loading &&
            candidates.map((person) => (
              <div
                className="border rounded p-3 flex items-center justify-between gap-3"
                key={person.id}
              >
                <div>
                  <p className="font-semibold text-sm">{person.name}</p>
                  <p className="text-xs text-gray-500">
                    {person.availability_status} ·{" "}
                    {person.monthly_schedule_count} participação(ões) no mês
                  </p>
                  {person.day_conflict && (
                    <p className="text-xs text-red-700">
                      Já está em outra equipe neste dia
                    </p>
                  )}
                </div>
                <Button
                  className={accent}
                  disabled={
                    saving ||
                    person.day_conflict ||
                    (!person.explicitly_available && !reason.trim())
                  }
                  onClick={() => add(person)}
                  aria-label={`Incluir ${person.name}`}
                >
                  Incluir
                </Button>
              </div>
            ))}
        </DialogContent>
      </Dialog>
    </>
  );
}

function LeaderPlan({ plan, reload }) {
  const [saving, setSaving] = useState(false);
  const [solutions, setSolutions] = useState({});
  const editable = plan.stage === "Montagem";
  const actions = {
    Coleta: [["montar", "Iniciar montagem das equipes"]],
    Montagem: [["validar", "Enviar mês para validação"]],
    "Em Validação": [
      ["reabrir", "Voltar à montagem"],
      ["publicar", "Concluir e publicar mês"],
    ],
    Concluído: [["reabrir", "Reabrir para alterações"]],
  };
  const mutate = async (operation) => {
    if (saving) return;
    setSaving(true);
    try {
      await operation();
      await reload();
      toast.success("Planejamento atualizado");
    } catch (error) {
      toast.error(apiErrorMessage(error));
      await reload();
    } finally {
      setSaving(false);
    }
  };
  const adjustments = groupParticipations(plan.members).filter(
    (row) => row.confirmation_status === "Preciso de Substituto",
  );
  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-5 space-y-4">
          <div className="flex justify-between gap-3 flex-wrap">
            <div>
              <p className="font-semibold text-lg">Etapa: {plan.stage}</p>
              <p className="text-sm text-gray-500">
                {plan.summary.confirmed} confirmadas · {plan.summary.pending}{" "}
                pendentes · {plan.summary.adjustments} ajustes
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {actions[plan.stage]?.map(([action, label]) => (
                <Button
                  key={action}
                  className={action === "reabrir" ? "" : accent}
                  variant={action === "reabrir" ? "outline" : "default"}
                  disabled={saving}
                  onClick={() =>
                    mutate(() =>
                      axios.post(
                        `${API}/monthly-plans/${plan.id}/stage`,
                        { action },
                        config,
                      ),
                    )
                  }
                >
                  {label}
                </Button>
              ))}
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {plan.stage === "Coleta"
              ? "As datas já aparecem no painel dos voluntários. Encerre a coleta para começar a montagem."
              : plan.stage === "Montagem"
                ? "Monte as equipes na grade. Ao reenviar o mês, confirmações das participações que não mudaram serão mantidas."
                : plan.stage === "Em Validação"
                  ? "Acompanhe as respostas. Para corrigir equipes ou resolver observações, volte à montagem."
                  : "O mês está publicado. Alterações exigem reabertura; somente participações alteradas precisam confirmar novamente."}
          </p>
          {plan.availability_deadline && (
            <p className="text-sm">
              Prazo da disponibilidade: {dayLabel(plan.availability_deadline)}
            </p>
          )}
        </CardContent>
      </Card>
      <div className="overflow-x-auto pb-4" data-testid="planning-grid">
        <div className="flex gap-4 items-start">
          {plan.schedules.map((schedule) => (
            <section
              key={schedule.id}
              className="w-64 shrink-0 border rounded-lg overflow-hidden bg-white"
            >
              <header className="bg-[#c72137] text-white p-4">
                <h3 className="font-bold text-lg">{dayLabel(schedule.date)}</h3>
                <p>{schedule.location}</p>
                <Link
                  className="text-xs underline"
                  to={`/schedules/${schedule.id}`}
                >
                  Abrir repertório e detalhes
                </Link>
              </header>
              <div className="p-3 space-y-3">
                {MONTHLY_FUNCTIONS.map((func) => (
                  <div key={func}>
                    <p className="text-xs font-semibold uppercase text-[#c72137]">
                      {func}
                    </p>
                    {plan.members
                      .filter(
                        (member) =>
                          member.schedule_id === schedule.id &&
                          member.function === func,
                      )
                      .map((member) => (
                        <div
                          className="border rounded p-2 my-1 text-sm space-y-1"
                          key={member.id}
                        >
                          <div className="flex justify-between items-start gap-1">
                            <span className="font-medium">
                              {member.volunteer_name}
                            </span>
                            {editable && (
                              <button
                                className="text-red-700 px-1"
                                disabled={saving}
                                aria-label={`Remover ${member.volunteer_name} ${member.function} ${schedule.location} ${schedule.date}`}
                                onClick={() =>
                                  mutate(() =>
                                    axios.delete(
                                      `${API}/schedules/${schedule.id}/members/${member.id}`,
                                      config,
                                    ),
                                  )
                                }
                              >
                                ×
                              </button>
                            )}
                          </div>
                          <p
                            className={`text-xs ${member.confirmation_status === "Confirmado" ? "text-green-700" : member.confirmation_status === "Preciso de Substituto" ? "text-red-700" : "text-amber-700"}`}
                          >
                            {statusLabel(member.confirmation_status)}
                          </p>
                          {member.availability_exception && (
                            <p className="text-xs text-amber-800">
                              Exceção: {member.exception_reason}
                            </p>
                          )}
                          {member.availability_warning && (
                            <p className="text-xs text-amber-800">
                              Atenção: disponibilidade não confirmada para este
                              dia.
                            </p>
                          )}
                          {!member.account_ready && (
                            <Link
                              className="text-xs text-red-700 underline"
                              to={`/volunteers/${member.volunteer_id}`}
                            >
                              Conferir perfil e conta vinculada
                            </Link>
                          )}
                        </div>
                      ))}
                    {!plan.members.some(
                      (member) =>
                        member.schedule_id === schedule.id &&
                        member.function === func,
                    ) && <div className="text-gray-300 text-xs py-1">—</div>}
                  </div>
                ))}
                {editable && (
                  <AddMonthlyMember schedule={schedule} reload={reload} />
                )}
              </div>
            </section>
          ))}
        </div>
      </div>
      {adjustments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Solicitações de ajuste</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {adjustments.map((row) => {
              const schedule = plan.schedules.find(
                (item) => item.id === row.schedule_id,
              );
              const key = `${row.schedule_id}:${row.volunteer_id}`;
              return (
                <section key={key} className="border rounded p-4 space-y-3">
                  <p className="font-semibold">
                    {row.volunteer_name} · {dayLabel(schedule.date)} ·{" "}
                    {schedule.location}
                  </p>
                  <p className="text-sm">{row.response_note}</p>
                  <Textarea
                    aria-label={`Solução para ${row.volunteer_name}`}
                    placeholder="Descreva o ajuste combinado. Se trocar a pessoa, remova e adicione pela grade."
                    value={solutions[key] || ""}
                    maxLength={1000}
                    disabled={!editable || saving}
                    onChange={(event) =>
                      setSolutions((previous) => ({
                        ...previous,
                        [key]: event.target.value,
                      }))
                    }
                  />
                  <Button
                    variant="outline"
                    disabled={!editable || saving || !solutions[key]?.trim()}
                    onClick={() =>
                      mutate(() =>
                        axios.put(
                          `${API}/monthly-plans/${plan.id}/resolve`,
                          {
                            schedule_id: row.schedule_id,
                            volunteer_id: row.volunteer_id,
                            expected_version: row.validation_version,
                            resolution: solutions[key],
                          },
                          config,
                        ),
                      )
                    }
                  >
                    Registrar solução e pedir nova confirmação
                  </Button>
                </section>
              );
            })}
          </CardContent>
        </Card>
      )}
      <details className="border rounded p-4">
        <summary className="cursor-pointer font-semibold">
          Disponibilidade recebida por voluntário
        </summary>
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-sm">
            <thead>
              <tr>
                <th className="text-left p-2">Voluntário</th>
                {plan.dates.map((day) => (
                  <th className="p-2 whitespace-nowrap" key={day}>
                    {dayLabel(day)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {plan.availability_overview.map((person) => (
                <tr className="border-t" key={person.id}>
                  <th className="text-left p-2 whitespace-nowrap font-normal">
                    {person.name}
                  </th>
                  {plan.dates.map((day) => (
                    <td className="p-2 text-center" key={day}>
                      {person.responses[day] === true
                        ? "Disponível"
                        : person.responses[day] === false
                          ? "Indisponível"
                          : "Sem resposta"}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
      <details className="border rounded p-4">
        <summary className="cursor-pointer font-semibold">
          Histórico de alterações e respostas
        </summary>
        <div className="space-y-3 mt-4">
          {plan.events.map((event, index) => (
            <div key={index} className="text-sm border-t pt-2">
              <p className="font-medium">{event.title}</p>
              <p className="text-gray-600 break-words">{event.detail}</p>
              <p className="text-xs text-gray-400">
                {new Date(event.created_at).toLocaleString("pt-BR")}
              </p>
            </div>
          ))}
          {!plan.events.length && (
            <p className="text-sm text-gray-500">
              Nenhuma alteração registrada ainda.
            </p>
          )}
        </div>
      </details>
    </div>
  );
}

export function MonthlyPlanningPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const leader = ["Administrador", "Líder"].includes(user?.role);
  const [plans, setPlans] = useState([]);
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [creating, setCreating] = useState(false);
  const currentId = useRef(id);
  currentId.current = id;
  const loadVersion = useRef(0);
  const reload = useCallback(async () => {
    const version = ++loadVersion.current;
    const isCurrent = () =>
      currentId.current === id && version === loadVersion.current;
    try {
      const response = await axios.get(
        `${API}/monthly-plans${id ? "/" + id : ""}`,
        config,
      );
      if (!isCurrent()) return;
      if (id) setPlan(response.data);
      else setPlans(response.data);
      setError("");
    } catch (error) {
      if (isCurrent())
        setError(
          apiErrorMessage(error, "Não foi possível carregar o planejamento."),
        );
    } finally {
      if (isCurrent()) setLoading(false);
    }
  }, [id]);
  useEffect(() => {
    setLoading(true);
    setPlan(null);
    reload();
  }, [reload]);
  usePlanningRefresh(reload);
  return (
    <div className="space-y-6" data-testid="monthly-planning-page">
      <div className="flex justify-between items-start gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">
            {plan
              ? `${plan.ministry} · ${plan.year_month}`
              : "Planejamento mensal"}
          </h1>
          <p className="text-gray-500 mt-1">
            Coleta → montagem das equipes → validação → conclusão
          </p>
        </div>
        {id ? (
          <Button asChild variant="outline">
            <Link to="/planning">Todos os planejamentos</Link>
          </Button>
        ) : (
          leader && (
            <Button
              className={accent}
              onClick={() => setCreating((value) => !value)}
            >
              {creating ? "Fechar formulário" : "Criar planejamento"}
            </Button>
          )
        )}
      </div>
      <Button variant="outline" onClick={reload}>
        Atualizar respostas
      </Button>
      <p className="text-sm bg-[#fcf7f6] rounded p-3">
        Eventos autônomos continuam em{" "}
        <Link to="/schedules" className="underline text-[#c72137]">
          Escalas → Nova escala individual
        </Link>
        , sem necessidade de validação dos voluntários.
      </p>
      {creating && !id && (
        <Card>
          <CardHeader>
            <CardTitle>Abrir um mês</CardTitle>
          </CardHeader>
          <CardContent>
            <CreatePlan
              onCreated={(newId) => {
                setCreating(false);
                navigate(`/planning/${newId}`);
              }}
            />
          </CardContent>
        </Card>
      )}
      {loading && <p role="status">Carregando...</p>}
      {error && (
        <p role="alert" className="text-red-700">
          {error}{" "}
          <button className="underline" onClick={reload}>
            Tentar novamente
          </button>
        </p>
      )}
      {!loading && !error && !id && (
        <div className="grid md:grid-cols-2 gap-4">
          {plans.map((item) => (
            <Link
              className="border rounded-lg p-5 hover:bg-[#fcf7f6]"
              to={`/planning/${item.id}`}
              key={item.id}
            >
              <h2 className="font-semibold text-lg">
                {item.ministry} · {item.year_month}
              </h2>
              <p className="text-sm text-gray-500 mt-2">
                {item.stage} · {item.dates.length} datas ·{" "}
                {item.schedules.length} equipes
              </p>
            </Link>
          ))}
          {!plans.length && (
            <p className="text-gray-500 py-6">
              Nenhum planejamento disponível.
            </p>
          )}
        </div>
      )}
      {!loading &&
        !error &&
        plan &&
        (leader ? (
          <LeaderPlan plan={plan} reload={reload} />
        ) : (
          <div className="space-y-5">
            <p className="font-semibold">Etapa: {plan.stage}</p>
            <DailyAvailability plans={[plan]} reload={reload} />
            <ParticipationValidation plan={plan} reload={reload} />
            {!plan.participations?.length && (
              <p className="text-sm text-gray-500">
                Suas participações aparecerão após o envio para validação.
              </p>
            )}
          </div>
        ))}
    </div>
  );
}
