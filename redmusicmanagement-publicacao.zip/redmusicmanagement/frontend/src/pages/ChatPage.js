import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageSquare, Send, Users } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

const API = `${process.env.REACT_APP_BACKEND_URL || ''}/api`;
const errorDetail = (error, fallback) => typeof error.response?.data?.detail === 'string'
  ? error.response.data.detail : fallback;

export const ChatPage = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [loadingContacts, setLoadingContacts] = useState(true);
  const [contactsError, setContactsError] = useState('');
  const [conversationError, setConversationError] = useState('');
  const [contactsVersion, setContactsVersion] = useState(0);
  const [conversationVersion, setConversationVersion] = useState(0);
  const messagesEndRef = useRef(null);
  const selectedId = selectedUser?.id;
  const lastMessageId = messages[messages.length - 1]?.id;

  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    setLoadingContacts(true);
    setContactsError('');
    setUsers([]);
    setSelectedUser(null);
    setMessages([]);
    setNewMessage('');
    axios.get(`${API}/chat/contacts`, { withCredentials: true, signal: controller.signal })
      .then(({ data }) => { if (active) setUsers(data); })
      .catch(error => {
        if (active && !axios.isCancel(error)) setContactsError(errorDetail(error, 'Erro ao carregar contatos. Tente novamente.'));
      })
      .finally(() => { if (active) setLoadingContacts(false); });
    return () => { active = false; controller.abort(); };
  }, [user?.id, contactsVersion]);

  useEffect(() => {
    if (!selectedId) return;
    let active = true;
    let timer;
    const controller = new AbortController();
    setLoading(true);
    setConversationError('');
    const poll = async () => {
      try {
        const { data } = await axios.get(`${API}/chat/messages/${selectedId}`, {
          withCredentials: true, signal: controller.signal,
        });
        if (!active) return;
        setMessages(data);
        timer = setTimeout(poll, 5000);
      } catch (error) {
        if (active && !axios.isCancel(error)) {
          setMessages([]);
          setConversationError(errorDetail(error, 'Não foi possível atualizar a conversa. Tente novamente.'));
        }
      } finally { if (active) setLoading(false); }
    };
    poll();
    return () => { active = false; controller.abort(); clearTimeout(timer); };
  }, [selectedId, conversationVersion]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lastMessageId]);

  const selectContact = contact => {
    if (sending || contact.id === selectedId) return;
    setMessages([]);
    setNewMessage('');
    setConversationError('');
    setSelectedUser(contact);
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (sending || loading || conversationError || !newMessage.trim() || !selectedUser) return;

    setSending(true);
    try {
      await axios.post(
        `${API}/chat/messages`,
        { to_user_id: selectedUser.id, message: newMessage.trim() },
        { withCredentials: true }
      );
      setNewMessage('');
      setConversationVersion(version => version + 1);
    } catch (error) {
      toast.error(errorDetail(error, 'Erro ao enviar mensagem. O texto foi mantido para você tentar novamente.'));
      if ([401, 403, 404].includes(error.response?.status)) {
        setMessages([]);
        setConversationError(errorDetail(error, 'Conversa indisponível. Atualize os contatos.'));
      }
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="chat-page">
      <div>
        <h1 className="text-3xl font-bold text-[#111111] tracking-tight flex items-center gap-3">
          <MessageSquare className="w-8 h-8 text-[#c72137]" />
          Mensagens
        </h1>
        <p className="text-base text-[#6b7280] mt-2">{user?.role === 'Voluntário' ? 'Converse com a liderança do ministério' : 'Converse com a liderança e os voluntários com conta vinculada'}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[480px]">
        <Card className="border-[#e28b95]/20 lg:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4 pb-4 border-b border-[#e28b95]/20">
              <Users className="w-5 h-5 text-[#c72137]" />
              <h2 className="font-semibold text-[#111111]">Contatos</h2>
            </div>
            <Button variant="outline" size="sm" className="mb-3" onClick={() => setContactsVersion(version => version + 1)} disabled={sending || loadingContacts}>Atualizar contatos</Button>
            {loadingContacts && <p className="text-sm text-[#6b7280]">Carregando contatos...</p>}
            {contactsError && <p role="alert" className="text-sm text-red-700">{contactsError}</p>}
            {!loadingContacts && !contactsError && users.length === 0 && <p className="text-sm text-[#6b7280]">Nenhum contato disponível. Voluntários precisam de conta vinculada pela liderança e cadastro ativo.</p>}
            <ScrollArea className="h-[340px]">
              <div className="space-y-2">
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => selectContact(u)}
                    disabled={sending}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      selectedUser?.id === u.id
                        ? 'bg-[#f7e1e1] border border-[#c72137]'
                        : 'hover:bg-[#fcf7f6] border border-transparent'
                    }`}
                    data-testid={`contact-${u.id}`}
                  >
                    <div className="w-10 h-10 rounded-full bg-[#f7e1e1] flex items-center justify-center text-[#c72137] font-bold">
                      {u.name.charAt(0)}
                    </div>
                    <div className="text-left flex-1 min-w-0">
                      <p className="font-medium text-[#111111] truncate">{u.name}</p>
                      <p className="text-xs text-[#6b7280] truncate">{u.role}</p>
                    </div>
                  </button>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card className="border-[#e28b95]/20 lg:col-span-3 flex flex-col min-w-0">
          {!selectedUser ? (
            <div className="flex-1 flex items-center justify-center" data-testid="no-chat-selected">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 text-[#e28b95] mx-auto mb-4" />
                <p className="text-[#6b7280]">Selecione um contato para iniciar uma conversa</p>
              </div>
            </div>
          ) : (
            <>
              <div className="p-4 border-b border-[#e28b95]/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#f7e1e1] flex items-center justify-center text-[#c72137] font-bold">
                    {selectedUser.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-[#111111]">{selectedUser.name}</p>
                    <p className="text-sm text-[#6b7280]">{selectedUser.role}</p>
                    <p className="text-xs text-[#6b7280] mt-1">Até 100 mensagens mais recentes. Novas respostas aparecem automaticamente.</p>
                  </div>
                </div>
              </div>

              <ScrollArea className="h-[340px] p-4">
                <div className="space-y-4" data-testid="chat-messages" aria-live="polite">
                  {conversationError ? (
                    <div className="space-y-2">
                      <p role="alert" className="text-sm text-red-700">{conversationError}</p>
                      <Button variant="outline" onClick={() => setConversationVersion(version => version + 1)}>Tentar novamente</Button>
                    </div>
                  ) : loading && messages.length === 0 ? <p className="text-[#6b7280]">Carregando conversa...</p> : messages.length === 0 ? (
                    <p className="text-center text-[#6b7280] py-8">Nenhuma mensagem ainda. Inicie a conversa!</p>
                  ) : (
                    messages.map((msg) => {
                      const isOwn = msg.from_user_id === user.id;
                      return (
                        <div
                          key={msg.id}
                          className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                          data-testid={`message-${msg.id}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-3 ${
                              isOwn
                                ? 'bg-[#c72137] text-white'
                                : 'bg-[#fcf7f6] text-[#111111] border border-[#e28b95]/20'
                            }`}
                          >
                            {!isOwn && (
                              <p className="text-xs font-medium mb-1 text-[#c72137]">
                                {msg.from_user_name}
                              </p>
                            )}
                            <p className="text-sm break-words whitespace-pre-wrap">{msg.message}</p>
                            <p
                              className={`text-xs mt-1 ${
                                isOwn ? 'text-white/70' : 'text-[#6b7280]'
                              }`}
                            >
                              {new Date(msg.timestamp).toLocaleString('pt-BR', {
                                day: '2-digit', month: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <form onSubmit={sendMessage} className="p-4 border-t border-[#e28b95]/20 mt-auto">
                <div className="flex gap-2">
                  <Input
                    placeholder="Digite sua mensagem..."
                    aria-label="Mensagem"
                    maxLength={2000}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    data-testid="chat-input"
                    className="flex-1"
                    disabled={sending || loading || Boolean(conversationError)}
                  />
                  <Button
                    type="submit"
                    aria-label="Enviar mensagem"
                    data-testid="chat-send-button"
                    className="bg-[#c72137] hover:bg-[#cf3f57]"
                    disabled={!newMessage.trim() || sending || loading || Boolean(conversationError)}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-[#6b7280] mt-2">{newMessage.length}/2000 caracteres</p>
              </form>
            </>
          )}
        </Card>
      </div>
    </div>
  );
};
