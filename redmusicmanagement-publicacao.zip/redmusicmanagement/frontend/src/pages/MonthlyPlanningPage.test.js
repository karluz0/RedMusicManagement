import React, { act } from "react";
import { createRoot } from "react-dom/client";
import axios from "axios";
import { toast } from "sonner";
import { MonthlyPlanningPage } from "./MonthlyPlanningPage";
jest.mock("axios");
jest.mock("sonner", () => ({
  toast: { success: jest.fn(), error: jest.fn() },
}));
jest.mock("@/contexts/AuthContext", () => ({
  useAuth: () => ({
    user: { role: "Administrador", email: "admin@example.com" },
  }),
}));
jest.mock("react-router-dom", () => ({
  useParams: () => ({ id: "plan" }),
  useNavigate: () => jest.fn(),
  Link: ({ to, children, ...rest }) =>
    require("react").createElement("a", { href: to, ...rest }, children),
}));
jest.mock("@/pages/MonthlyGridView", () => ({ MonthlyGridView: () => null }));
let root, container, plan;
const findButton = (label) =>
  [...container.querySelectorAll("button")].find(
    (item) =>
      item.getAttribute("aria-label") === label ||
      item.textContent.trim() === label,
  );
async function click(item) {
  expect(item).toBeDefined();
  await act(async () => item.click());
}
const open = (func = "Vocal", date = "2099-11-01") =>
  click(findButton(`Adicionar ${func} Indaiatuba ${date}`));
const candidate = () =>
  container.querySelector('[data-testid="monthly-slot-picker"] li button');
const picker = () =>
  container.querySelector('[data-testid="monthly-slot-picker"]');
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  jest.clearAllMocks();
  plan = {
    id: "plan",
    ministry: "Red Music",
    year_month: "2099-11",
    stage: "Montagem",
    dates: ["2099-11-01", "2099-11-08"],
    members: [],
    summary: { pending: 0, adjustments: 0, confirmed: 0 },
    events: [],
    availability_overview: [],
    schedules: [
      {
        id: "red-1",
        date: "2099-11-01",
        location: "Indaiatuba",
        ministry: "Red Music",
      },
      {
        id: "red-8",
        date: "2099-11-08",
        location: "Indaiatuba",
        ministry: "Red Music",
      },
    ],
  };
  axios.get.mockImplementation(async (url) => ({
    data: url.includes("/available-volunteers")
      ? [
          {
            id: "ana",
            name: "Ana",
            instruments: ["Vocal", "Violão"],
            explicitly_available: true,
            day_conflict: false,
            monthly_schedule_count:
              1 +
              new Set(
                plan.members
                  .filter((row) => row.volunteer_id === "ana")
                  .map((row) => row.schedule_id),
              ).size,
          },
        ]
      : { ...plan, members: [...plan.members] },
  }));
  axios.post.mockImplementation(async (url, body) => {
    const entry = {
      id: "entry-" + plan.members.length,
      schedule_id: url.split("/")[3],
      volunteer_id: body.volunteer_id,
      volunteer_name: "Ana",
      function: body.function,
      confirmation_status: "Pendente",
    };
    plan.members.push(entry);
    return { data: entry };
  });
  axios.delete.mockImplementation(async (url) => {
    plan.members = plan.members.filter((row) => !url.endsWith("/" + row.id));
    return { data: {} };
  });
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});
afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("clicking slots replaces drag and drop and refreshes total counts after additions and removal", async () => {
  await act(async () => root.render(<MonthlyPlanningPage />));
  expect(container.querySelector('[data-testid="member-pool"]')).toBeNull();
  expect(container.querySelector("[data-drop-schedule]")).toBeNull();
  await open();
  expect(
    container.querySelector('[data-testid="planning-grid"]').contains(picker()),
  ).toBe(true);
  expect(document.querySelector('[role="dialog"]')).toBeNull();
  expect(picker().textContent).toContain("1 escala no mês");
  await click(candidate());
  expect(axios.post).toHaveBeenLastCalledWith(
    "/api/schedules/red-1/members",
    { volunteer_id: "ana", function: "Vocal", exception_reason: "" },
    { withCredentials: true },
  );
  expect(picker()).toBeNull();
  await open("Violão");
  expect(picker().textContent).toContain("2 escalas no mês");
  await click(candidate());
  await open("Vocal", "2099-11-08");
  expect(picker().textContent).toContain("2 escalas no mês");
  await click(candidate());
  await open("Vocal", "2099-11-08");
  expect(picker().textContent).toContain("3 escalas no mês");
  expect(candidate().disabled).toBe(true);
  await click(findButton("Remover Ana Vocal Indaiatuba 2099-11-08"));
  if (picker()) await click(findButton("Fechar lista"));
  await open("Vocal", "2099-11-08");
  expect(picker().textContent).toContain("2 escalas no mês");
  expect(candidate().disabled).toBe(false);
});

test("switching vacancies opens only the requested inline list", async () => {
  await act(async () => root.render(<MonthlyPlanningPage />));
  await open();
  await open("Violão");
  expect(
    container.querySelectorAll('[data-testid="monthly-slot-picker"]').length,
  ).toBe(1);
  expect(picker().getAttribute("aria-label")).toContain("Violão");
});

test("inclusion failure refreshes candidates and preserves the grid for retry", async () => {
  await act(async () => root.render(<MonthlyPlanningPage />));
  await open();
  axios.post.mockRejectedValueOnce({
    response: { status: 409, data: { detail: "Equipe alterada. Atualize." } },
  });
  await click(candidate());
  expect(toast.error).toHaveBeenCalled();
  expect(plan.members).toHaveLength(0);
  expect(picker().textContent).toContain("1 escala no mês");
  expect(candidate().disabled).toBe(false);
});

test("validation stage offers no editable vacancy dropdowns", async () => {
  plan.stage = "Em Validação";
  await act(async () => root.render(<MonthlyPlanningPage />));
  expect(
    [...container.querySelectorAll("button")].some((item) =>
      item.getAttribute("aria-label")?.startsWith("Adicionar "),
    ),
  ).toBe(false);
  expect(picker()).toBeNull();
  expect(
    axios.get.mock.calls.some(([url]) => url.includes("/available-volunteers")),
  ).toBe(false);
});
