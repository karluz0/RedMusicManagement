import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import axios from 'axios';
import { toast } from 'sonner';
import { ScheduleDetailPage } from './ScheduleDetailPage';

let mockId = 'a';
const mockNavigate = jest.fn();
let mockUser = { email: 'leader@example.com', role: 'Gestor' };
jest.mock('react-router-dom', () => ({ useParams: () => ({ id: mockId }), useNavigate: () => mockNavigate }));
jest.mock('@/contexts/AuthContext', () => ({ useAuth: () => ({ user: mockUser }) }));
jest.mock('axios');
jest.mock('sonner', () => ({ toast: { success: jest.fn(), error: jest.fn(), warning: jest.fn() } }));
jest.mock('jspdf', () => jest.fn());
jest.mock('react-beautiful-dnd', () => ({
  DragDropContext: ({children}) => children,
  Droppable: ({children}) => children({ innerRef: () => {}, droppableProps: {}, placeholder: null }),
  Draggable: ({children}) => children({ innerRef: () => {}, draggableProps: {}, dragHandleProps: {} }, {})
}));

const deferred = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };
let root, container, gets;
const data = id => ({ id, name: `Escala ${id.toUpperCase()}`, date: '2026-11-01', time: '19:00', ministry: 'Red Music', status: 'Rascunho', members: [], setlist: [], validation_required: false });
async function render(id) { mockId = id; await act(async () => root.render(<ScheduleDetailPage />)); }
async function finish(batch, id, fail = false) {
  await act(async () => {
    batch.forEach(request => {
      if (request.url === `/api/schedules/${id}`) {
        if (fail) request.reject(new Error('late failure')); else request.resolve({ data: data(id) });
      } else request.resolve({ data: [] });
    });
  });
}
function button(label) { return [...document.querySelectorAll('button')].find(item => item.textContent.trim() === label); }
async function click(item) { expect(item).toBeDefined(); await act(async () => item.click()); }
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  jest.clearAllMocks(); mockId = 'a'; mockUser = { email: 'leader@example.com', role: 'Gestor' }; gets = [];
  axios.get.mockImplementation((url, config) => {
    const request = { ...deferred(), url, config }; gets.push(request); return request.promise;
  });
  container = document.createElement('div'); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });

test.each([false, true])('late schedule A result cannot replace B or redirect it (failure=%s)', async fail => {
  await render('a'); const first = gets.slice();
  await render('b'); const second = gets.slice(first.length);
  expect(first.every(item => item.config.signal.aborted)).toBe(true);
  expect(container.querySelector('[aria-label="Carregando escala"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="validate-button"]')).toBeNull();
  await finish(second, 'b');
  expect(container.textContent).toContain('Escala B');
  // The mocked transport deliberately ignores AbortSignal: the version/lifetime guard still applies.
  await finish(first, 'a', fail);
  expect(container.textContent).toContain('Escala B'); expect(container.textContent).not.toContain('Escala A');
  expect(mockNavigate).not.toHaveBeenCalled(); expect(toast.error).not.toHaveBeenCalled();
});

test('navigation removes old data and open dialogs until the next scale is loaded', async () => {
  await render('a'); await finish(gets.slice(), 'a');
  await click(button('Excluir escala'));
  expect(document.body.textContent).toContain('Excluir Escala A?');
  const offset = gets.length; await render('b');
  expect(document.body.textContent).not.toContain('Escala A');
  expect(button('Confirmar exclusão')).toBeUndefined();
  expect(container.querySelector('[data-testid="export-pdf-button"]')).toBeNull();
  await finish(gets.slice(offset), 'b');
  expect(container.textContent).toContain('Escala B'); expect(axios.delete).not.toHaveBeenCalled();
});

test.each([false, true])('in-flight deletion of A cannot navigate, notify or reload B (failure=%s)', async fail => {
  await render('a'); await finish(gets.slice(), 'a');
  const write = deferred(); axios.delete.mockReturnValue(write.promise);
  await click(button('Excluir escala')); await click(button('Confirmar exclusão'));
  expect(axios.delete.mock.calls[0][0]).toBe('/api/schedules/a');
  const offset = gets.length; await render('b'); await finish(gets.slice(offset), 'b');
  const total = gets.length;
  await act(async () => fail ? write.reject(new Error('old write failed')) : write.resolve({ data: {} }));
  expect(container.textContent).toContain('Escala B'); expect(gets.length).toBe(total);
  expect(mockNavigate).not.toHaveBeenCalled(); expect(toast.success).not.toHaveBeenCalled(); expect(toast.error).not.toHaveBeenCalled();
});

test('current load failure still reports the error and redirects normally', async () => {
  await render('a'); await finish(gets.slice(), 'a', true);
  expect(toast.error).toHaveBeenCalledWith('Erro ao carregar escala'); expect(mockNavigate).toHaveBeenCalledWith('/schedules');
});

test('leaving the page aborts requests and ignores their late failure', async () => {
  await render('a'); const batch = gets.slice(); await act(async () => root.render(null));
  expect(batch.every(item => item.config.signal.aborted)).toBe(true);
  await finish(batch, 'a', true);
  expect(toast.error).not.toHaveBeenCalled(); expect(mockNavigate).not.toHaveBeenCalled();
});

test('role change starts a fresh load and drops previously loaded management controls', async () => {
  await render('a'); await finish(gets.slice(), 'a');
  const offset = gets.length; mockUser = { email: 'leader@example.com', role: 'Voluntário', volunteer_id: 'ana' };
  await render('a');
  expect(button('Excluir escala')).toBeUndefined();
  expect(gets.slice(offset).map(item => item.url)).toEqual(['/api/schedules/a', '/api/songs']);
  await finish(gets.slice(offset), 'a'); expect(button('Excluir escala')).toBeUndefined();
});

test('overlapping reloads on the same scale apply only the latest snapshot and hide actions while loading', async () => {
  await render('a'); await finish(gets.slice(), 'a');
  const firstWrite = deferred(), secondWrite = deferred();
  axios.put.mockReturnValueOnce(firstWrite.promise).mockReturnValueOnce(secondWrite.promise);
  const publish = container.querySelector('[data-testid="validate-button"]');
  await click(publish); await click(publish);
  const firstOffset = gets.length;
  await act(async () => firstWrite.resolve({ data: {} }));
  const firstReload = gets.slice(firstOffset);
  expect(container.querySelector('[aria-label="Carregando escala"]')).not.toBeNull();
  expect(button('Excluir escala')).toBeUndefined();
  const secondOffset = gets.length;
  await act(async () => secondWrite.resolve({ data: {} }));
  const secondReload = gets.slice(secondOffset);
  expect(firstReload.every(item => item.config.signal.aborted)).toBe(true);
  await act(async () => secondReload.forEach(request => request.resolve({ data: request.url === '/api/schedules/a' ? {...data('a'), name: 'Snapshot mais recente'} : [] })));
  expect(container.textContent).toContain('Snapshot mais recente');
  await finish(firstReload, 'a', true);
  expect(container.textContent).toContain('Snapshot mais recente');
  expect(mockNavigate).not.toHaveBeenCalled(); expect(toast.error).not.toHaveBeenCalled();
});

test('band leader save finishing after navigation does not reload or notify the new scale', async () => {
  await render('a'); await finish(gets.slice(), 'a');
  const write = deferred(); axios.put.mockReturnValue(write.promise);
  await click(button('Definir ou alterar líder'));
  const input = document.querySelector('[aria-label="Nome do líder externo"]');
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, 'Líder de exemplo');
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await click(button('Salvar líder'));
  expect(axios.put.mock.calls[0][0]).toBe('/api/schedules/a/band-leader');
  const offset = gets.length; await render('b'); await finish(gets.slice(offset), 'b');
  const total = gets.length;
  await act(async () => write.resolve({ data: {} }));
  expect(container.textContent).toContain('Escala B'); expect(gets.length).toBe(total);
  expect(toast.success).not.toHaveBeenCalled(); expect(mockNavigate).not.toHaveBeenCalled();
});
