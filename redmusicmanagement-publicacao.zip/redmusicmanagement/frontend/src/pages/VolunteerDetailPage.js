import {ConfirmRemoval} from "@/components/StaffActions";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  ArrowLeft,
  Upload,
  Calendar,
  Trash2,
  Mail,
  Phone,
  Cake,
  Edit,
} from "lucide-react";
import { toast } from "sonner";
import { apiErrorMessage } from "@/lib/apiError";
import { useAuth } from "@/contexts/AuthContext";
import { MinistryPicker } from "@/components/MinistryPicker";

const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const INSTRUMENT_OPTIONS = [
  "Vocal",
  "Violão",
  "Guitarra",
  "Baixo",
  "Bateria",
  "Teclado",
  "Percussão",
];

export const VolunteerDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const isAdmin = ["Administrador", "Líder"].includes(user?.role);
  const navigate = useNavigate();
  const [volunteer, setVolunteer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [unavailDialogOpen, setUnavailDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [unavailDate, setUnavailDate] = useState("");
  const [unavailReason, setUnavailReason] = useState("");
  const [participationHistory, setParticipationHistory] = useState([]);
  const [editForm, setEditForm] = useState({});
  const [accountEmail, setAccountEmail] = useState("");
  const [linkedEmail, setLinkedEmail] = useState(null);
  const [accountReady, setAccountReady] = useState(false);
  const [savingAccount, setSavingAccount] = useState(false);
  const [approvalPhase, setApprovalPhase] = useState("");
  const [approving, setApproving] = useState(false);

  useEffect(() => {
    loadVolunteer();
    loadParticipationHistory();
  }, [id]);

  useEffect(() => {
    if (!isAdmin) return;
    setAccountReady(false);
    axios
      .get(`${API}/volunteers/${id}/account`, { withCredentials: true })
      .then(({ data }) => {
        setLinkedEmail(data.email);
        setAccountReady(true);
      })
      .catch(() =>
        toast.error("Erro ao carregar conta vinculada. Atualize a página."),
      );
  }, [id, isAdmin]);

  const approveRegistration = async () => {
    if (!approvalPhase || approving) return;
    setApproving(true);
    try {
      await axios.post(
        `${API}/volunteers/${id}/approve`,
        { phase: approvalPhase },
        { withCredentials: true },
      );
      await loadVolunteer();
      toast.success(
        "Cadastro aprovado. O voluntário já pode acessar o sistema.",
      );
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setApproving(false);
    }
  };

  const saveAccountLink = async (event) => {
    event.preventDefault();
    setSavingAccount(true);
    try {
      const { data } = await axios.put(
        `${API}/volunteers/${id}/account`,
        { email: accountEmail },
        { withCredentials: true },
      );
      setLinkedEmail(data.email);
      setAccountEmail("");
      await loadVolunteer();
      toast.success(
        "Conta vinculada. Confira a aprovação do cadastro para liberar o acesso.",
      );
    } catch (error) {
      toast.error(error.response?.data?.detail || "Erro ao vincular conta");
    } finally {
      setSavingAccount(false);
    }
  };

  const removeAccountLink = async () => {
    setSavingAccount(true);
    try {
      await axios.delete(`${API}/volunteers/${id}/account`, {
        withCredentials: true,
      });
      setLinkedEmail(null);
      toast.success("Vínculo removido");
    } catch (error) {
      toast.error("Erro ao remover vínculo");
    } finally {
      setSavingAccount(false);
    }
  };

  const loadVolunteer = async () => {
    try {
      const { data } = await axios.get(`${API}/volunteers/${id}`, {
        withCredentials: true,
      });
      setVolunteer(data);
    } catch (error) {
      toast.error("Erro ao carregar voluntário");
      navigate("/volunteers");
    } finally {
      setLoading(false);
    }
  };

  const loadParticipationHistory = async () => {
    try {
      const { data } = await axios.get(
        `${API}/volunteers/${id}/participation-history`,
        { withCredentials: true },
      );
      setParticipationHistory(data);
    } catch (error) {
      console.error("Erro ao carregar histórico:", error);
    }
  };

  const openEditDialog = () => {
    setEditForm({
      name: volunteer.name,
      birth_date: volunteer.birth_date,
      email: volunteer.email,
      phone: volunteer.phone || "",
      instruments: volunteer.instruments || [],
      phase: volunteer.phase,
      status: volunteer.status,
      ministries: volunteer.ministries || ["Red Music"],
    });
    setEditDialogOpen(true);
  };

  const toggleEditInstrument = (instrument) => {
    setEditForm((prev) => ({
      ...prev,
      instruments: prev.instruments.includes(instrument)
        ? prev.instruments.filter((i) => i !== instrument)
        : [...prev.instruments, instrument],
    }));
  };

  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!editForm.ministries?.length) {
      toast.error("Selecione ao menos um ministério");
      return;
    }
    try {
      await axios.put(`${API}/volunteers/${id}`, editForm, {
        withCredentials: true,
      });
      toast.success("Voluntário atualizado com sucesso");
      setEditDialogOpen(false);
      loadVolunteer();
    } catch (error) {
      toast.error(apiErrorMessage(error, "Erro ao atualizar voluntário"));
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast.error("Foto muito grande. Máximo 3 MB.");
      return;
    }
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const { data } = await axios.post(
        `${API}/volunteers/${id}/upload-photo`,
        formData,
        {
          withCredentials: true,
          headers: { "Content-Type": "multipart/form-data" },
        },
      );
      setVolunteer({ ...volunteer, photo_url: data.photo_url });
      toast.success("Foto atualizada com sucesso");
    } catch (error) {
      toast.error(apiErrorMessage(error, "Erro ao fazer upload da foto"));
    } finally {
      setUploading(false);
    }
  };

  const addUnavailability = async () => {
    if (!unavailDate) return;
    try {
      await axios.post(
        `${API}/volunteers/${id}/unavailability`,
        { date: unavailDate, reason: unavailReason },
        { withCredentials: true },
      );
      toast.success("Indisponibilidade adicionada");
      setUnavailDialogOpen(false);
      setUnavailDate("");
      setUnavailReason("");
      loadVolunteer();
    } catch (error) {
      toast.error(
        apiErrorMessage(error, "Erro ao adicionar indisponibilidade"),
      );
    }
  };

  const removeUnavailability = async (date) => {
    try {
      await axios.delete(`${API}/volunteers/${id}/unavailability/${date}`, {
        withCredentials: true,
      });
      toast.success("Indisponibilidade removida");
      loadVolunteer();
    } catch (error) {
      toast.error("Erro ao remover indisponibilidade");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-[#c72137] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="volunteer-detail-page">
      {isAdmin && volunteer && <ConfirmRemoval label="Excluir voluntário" title={`Excluir ${volunteer.name}?`} description="O voluntário será arquivado e sairá das seleções. O acesso da conta vinculada será bloqueado. As participações e registros anteriores serão preservados." onConfirm={async()=>{await axios.delete(`${API}/volunteers/${id}`,{withCredentials:true});toast.success('Voluntário arquivado');navigate('/volunteers');}}/>}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => navigate("/volunteers")}
            data-testid="back-button"
            className="hover:bg-[#f7e1e1]"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-[#111111] tracking-tight">
              {volunteer?.name}
            </h1>
            <p className="text-base text-[#6b7280]">{volunteer?.age} anos</p>
          </div>
        </div>
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={openEditDialog}
              className="bg-[#c72137] hover:bg-[#cf3f57]"
              data-testid="edit-volunteer-button"
            >
              <Edit className="w-4 h-4 mr-2" />
              Editar Perfil
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Editar Voluntário</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={handleSaveEdit}
              className="space-y-4"
              data-testid="edit-volunteer-form"
            >
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Nome completo</Label>
                  <Input
                    value={editForm.name || ""}
                    onChange={(e) =>
                      setEditForm({ ...editForm, name: e.target.value })
                    }
                    required
                    data-testid="edit-name-input"
                  />
                </div>
                <div>
                  <Label>Data de Nascimento</Label>
                  <Input
                    type="date"
                    value={editForm.birth_date || ""}
                    onChange={(e) =>
                      setEditForm({ ...editForm, birth_date: e.target.value })
                    }
                    data-testid="edit-birthdate-input"
                  />
                </div>
                <div>
                  <Label>E-mail</Label>
                  <Input
                    type="email"
                    value={editForm.email || ""}
                    onChange={(e) =>
                      setEditForm({ ...editForm, email: e.target.value })
                    }
                    required
                    data-testid="edit-email-input"
                  />
                </div>
                <div>
                  <Label>Celular (WhatsApp)</Label>
                  <Input
                    value={editForm.phone || ""}
                    onChange={(e) =>
                      setEditForm({ ...editForm, phone: e.target.value })
                    }
                    placeholder="(00) 00000-0000"
                    data-testid="edit-phone-input"
                  />
                </div>
                <div>
                  <Label>Fase</Label>
                  <Select
                    value={editForm.phase}
                    onValueChange={(v) =>
                      setEditForm({ ...editForm, phase: v })
                    }
                  >
                    <SelectTrigger data-testid="edit-phase-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Em Teste">Em Teste</SelectItem>
                      <SelectItem value="Efetivado">Efetivado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select
                    value={editForm.status}
                    onValueChange={(v) =>
                      setEditForm({ ...editForm, status: v })
                    }
                  >
                    <SelectTrigger data-testid="edit-status-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pendente">Pendente</SelectItem>
                      <SelectItem value="Ativo">Ativo</SelectItem>
                      <SelectItem value="Inativo">Inativo</SelectItem>
                      <SelectItem value="Afastado">Afastado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="pt-2 border-t border-[#e28b95]/20">
                <Label className="text-base font-semibold text-[#111111] mb-3 block">
                  Instrumentos / Funções
                </Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {INSTRUMENT_OPTIONS.map((instrument) => (
                    <label
                      key={instrument}
                      className="flex items-center gap-2 p-3 border border-[#e28b95]/30 rounded-lg cursor-pointer hover:bg-[#fcf7f6]"
                      data-testid={`edit-instrument-${instrument}`}
                    >
                      <Checkbox
                        checked={
                          editForm.instruments?.includes(instrument) || false
                        }
                        onCheckedChange={() => toggleEditInstrument(instrument)}
                      />
                      <span className="text-sm font-medium text-[#111111]">
                        {instrument}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
              <MinistryPicker
                value={editForm.ministries}
                onChange={(ministries) =>
                  setEditForm((previous) => ({ ...previous, ministries }))
                }
              />
              <Button
                type="submit"
                className="w-full bg-[#c72137] hover:bg-[#cf3f57]"
                data-testid="save-edit-button"
              >
                Salvar Alterações
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="border-[#e28b95]/20">
          <CardHeader>
            <CardTitle className="text-lg">Perfil</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col items-center">
              {volunteer?.photo_url ? (
                <img
                  src={volunteer.photo_url}
                  alt={volunteer.name}
                  className="w-32 h-32 rounded-full object-cover border-4 border-[#f7e1e1]"
                />
              ) : (
                <div className="w-32 h-32 rounded-full bg-[#f7e1e1] flex items-center justify-center text-[#c72137] text-5xl font-bold">
                  {volunteer?.name?.charAt(0)}
                </div>
              )}
              <label
                htmlFor="photo-upload"
                className="mt-4 cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-[#f7e1e1] text-[#c72137] hover:bg-[#ecb7bb] rounded-md font-medium transition-colors"
              >
                <Upload className="w-4 h-4" />
                {uploading ? "Enviando..." : "Alterar Foto"}
                <input
                  id="photo-upload"
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handlePhotoUpload}
                  className="hidden"
                  disabled={uploading}
                  data-testid="photo-upload-input"
                />
              </label>
              <p className="text-xs text-gray-500 mt-2 text-center">
                JPEG, PNG ou WebP · até 3 MB e 16 megapixels
              </p>
            </div>

            <div className="space-y-3 pt-4 border-t border-[#e28b95]/20">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-[#6b7280]" />
                <span className="text-[#111111]">{volunteer?.email}</span>
              </div>
              <p className="text-sm text-[#c72137]">
                {(volunteer?.ministries || ["Red Music"]).join(" · ")}
              </p>
              {volunteer?.phone && (
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-[#6b7280]" />
                  <span className="text-[#111111]">{volunteer.phone}</span>
                </div>
              )}
              {volunteer?.birth_date && (
                <div className="flex items-center gap-3 text-sm">
                  <Cake className="w-4 h-4 text-[#6b7280]" />
                  <span className="text-[#111111]">
                    {new Date(
                      volunteer.birth_date + "T00:00:00",
                    ).toLocaleDateString("pt-BR")}
                  </span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2 pt-4 border-t border-[#e28b95]/20">
              <Badge
                className={
                  volunteer?.status === "Ativo"
                    ? "bg-green-100 text-green-800 hover:bg-green-100"
                    : volunteer?.status === "Inativo"
                      ? "bg-gray-100 text-gray-800 hover:bg-gray-100"
                      : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                }
              >
                {volunteer?.status}
              </Badge>
              <Badge className="bg-[#f7e1e1] text-[#c72137] hover:bg-[#f7e1e1]">
                {volunteer?.phase}
              </Badge>
            </div>
            {isAdmin && (
              <div
                className="space-y-3 pt-4 border-t border-[#e28b95]/20"
                data-testid="volunteer-account-link"
              >
                {volunteer?.status === "Pendente" && linkedEmail && (
                  <section
                    className="space-y-3"
                    data-testid="approve-registration"
                  >
                    <h3 className="font-semibold">Aprovar cadastro</h3>
                    <p className="text-sm text-gray-600">
                      A conta já foi criada com o cadastro. Selecione a fase
                      para liberar o acesso.
                    </p>
                    <label className="block text-sm">
                      Fase do voluntário
                      <select
                        aria-label="Fase para aprovação"
                        className="block w-full border rounded-md p-2 mt-1 bg-white"
                        value={approvalPhase}
                        disabled={approving}
                        onChange={(event) =>
                          setApprovalPhase(event.target.value)
                        }
                      >
                        <option value="" disabled>
                          Selecione a fase
                        </option>
                        <option value="Em Teste">Em teste</option>
                        <option value="Efetivado">Efetivado</option>
                      </select>
                    </label>
                    <Button
                      className="bg-[#c72137] hover:bg-[#cf3f57] w-full"
                      disabled={approving || !approvalPhase || !accountReady}
                      onClick={approveRegistration}
                    >
                      {approving ? "Aprovando..." : "Aprovar cadastro"}
                    </Button>
                  </section>
                )}
                <details>
                  <summary className="cursor-pointer text-sm font-medium">
                    Opções de conta
                  </summary>
                  <div className="mt-3 space-y-3">
                    {!accountReady ? (
                      <p className="text-sm text-[#6b7280]">
                        Carregando vínculo...
                      </p>
                    ) : linkedEmail ? (
                      <>
                        <p className="text-sm break-all">
                          Conta vinculada: {linkedEmail}
                        </p>
                        <Button
                          variant="outline"
                          onClick={removeAccountLink}
                          disabled={savingAccount}
                        >
                          Remover vínculo
                        </Button>
                      </>
                    ) : (
                      <form onSubmit={saveAccountLink} className="space-y-3">
                        <p className="text-sm text-[#6b7280]">
                          Use esta opção para cadastros antigos ou criados
                          manualmente. Confira com a pessoa o e-mail da conta
                          existente. Nos novos cadastros públicos, o vínculo é
                          automático e a aprovação é feita pelo botão Aprovar
                          cadastro.
                        </p>
                        <Label htmlFor="account-email">
                          E-mail da conta do voluntário
                        </Label>
                        <Input
                          id="account-email"
                          type="email"
                          value={accountEmail}
                          onChange={(event) =>
                            setAccountEmail(event.target.value)
                          }
                          required
                          disabled={savingAccount}
                        />
                        <Button
                          type="submit"
                          disabled={savingAccount}
                          className="bg-[#c72137] hover:bg-[#cf3f57]"
                        >
                          {savingAccount
                            ? "Vinculando..."
                            : volunteer?.status === "Pendente" &&
                                volunteer?.registration_source !== "public"
                              ? "Vincular e aprovar cadastro antigo"
                              : "Vincular conta"}
                        </Button>
                      </form>
                    )}
                  </div>
                </details>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="lg:col-span-2">
          <Tabs defaultValue="info" className="w-full">
            <TabsList>
              <TabsTrigger value="info" data-testid="tab-info">
                Informações
              </TabsTrigger>
              <TabsTrigger
                value="unavailability"
                data-testid="tab-unavailability"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Indisponibilidade
              </TabsTrigger>
              <TabsTrigger value="history" data-testid="tab-history">
                Histórico
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="mt-6">
              <Card className="border-[#e28b95]/20">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Instrumentos e Funções
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {!volunteer?.instruments ||
                  volunteer.instruments.length === 0 ? (
                    <p className="text-[#6b7280] text-sm">
                      Nenhum instrumento ou função cadastrado
                    </p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {volunteer.instruments.map((inst, idx) => (
                        <Badge
                          key={idx}
                          className="bg-[#f7e1e1] text-[#c72137] hover:bg-[#f7e1e1] text-sm px-3 py-1"
                        >
                          {inst}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="unavailability" className="mt-6">
              <Card className="border-[#e28b95]/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0">
                  <CardTitle className="text-lg">
                    Agenda de Indisponibilidade
                  </CardTitle>
                  <Dialog
                    open={unavailDialogOpen}
                    onOpenChange={setUnavailDialogOpen}
                  >
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        className="bg-[#c72137] hover:bg-[#cf3f57]"
                        data-testid="add-unavailability-button"
                      >
                        Adicionar
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Adicionar Indisponibilidade</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Data</Label>
                          <Input
                            type="date"
                            value={unavailDate}
                            onChange={(e) => setUnavailDate(e.target.value)}
                            data-testid="unavail-date-input"
                          />
                        </div>
                        <div>
                          <Label>Motivo (opcional)</Label>
                          <Textarea
                            value={unavailReason}
                            onChange={(e) => setUnavailReason(e.target.value)}
                            placeholder="Ex: Viagem, compromisso pessoal..."
                            data-testid="unavail-reason-input"
                          />
                        </div>
                        <Button
                          onClick={addUnavailability}
                          className="w-full bg-[#c72137] hover:bg-[#cf3f57]"
                          data-testid="confirm-add-unavailability"
                        >
                          Adicionar
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardHeader>
                <CardContent>
                  {!volunteer?.unavailability_dates ||
                  volunteer.unavailability_dates.length === 0 ? (
                    <p className="text-[#6b7280] text-sm text-center py-8">
                      Nenhuma data de indisponibilidade cadastrada
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {volunteer.unavailability_dates.map((unavail, idx) => (
                        <div
                          key={idx}
                          className="flex items-start justify-between p-3 bg-[#fcf7f6] rounded-lg"
                          data-testid={`unavailability-${idx}`}
                        >
                          <div>
                            <p className="font-medium text-[#111111]">
                              {new Date(
                                unavail.date + "T00:00:00",
                              ).toLocaleDateString("pt-BR", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                            {unavail.reason && (
                              <p className="text-sm text-[#6b7280] mt-1">
                                {unavail.reason}
                              </p>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeUnavailability(unavail.date)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            data-testid={`remove-unavailability-${idx}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history" className="mt-6">
              <Card className="border-[#e28b95]/20">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Histórico de Participação
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {participationHistory.length === 0 ? (
                    <p className="text-[#6b7280] text-sm text-center py-8">
                      Nenhuma participação registrada ainda
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {participationHistory.map((item, idx) => (
                        <div
                          key={idx}
                          className="p-4 bg-[#fcf7f6] rounded-lg border border-[#e28b95]/20"
                          data-testid={`history-item-${idx}`}
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <p className="font-semibold text-[#111111]">
                                {item.schedule_name}
                              </p>
                              <p className="text-sm text-[#6b7280] mt-1">
                                {new Date(
                                  item.schedule_date + "T00:00:00",
                                ).toLocaleDateString("pt-BR")}{" "}
                                às {item.schedule_time}
                              </p>
                              <p className="text-sm text-[#6b7280]">
                                Função: {item.function}
                              </p>
                            </div>
                            <Badge
                              className={
                                item.confirmation_status === "Confirmado"
                                  ? "bg-green-100 text-green-800 hover:bg-green-100"
                                  : item.confirmation_status ===
                                      "Preciso de Substituto"
                                    ? "bg-red-100 text-red-800 hover:bg-red-100"
                                    : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                              }
                            >
                              {item.confirmation_status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};
