import { useCallback, useEffect, useRef, useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { apiErrorMessage } from '@/lib/apiError';
import { toast } from 'sonner';
const API = `${process.env.REACT_APP_BACKEND_URL || ''}/api`;

export function UserAccountsPage() {
  const [users, setUsers] = useState([]);
  const [choices, setChoices] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const active = useRef(false);
  const pending = useRef(false);
  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API}/users`, { withCredentials: true });
      if (!active.current) return;
      setUsers(data); setChoices({}); setError('');
    } catch (err) {
      if (active.current) setError(apiErrorMessage(err, 'Não foi possível carregar as contas.'));
    } finally {
      if (active.current) setLoading(false);
    }
  }, []);
  useEffect(() => { active.current = true; reload(); return () => { active.current = false; }; }, [reload]);
  const save = async (account) => {
    if (pending.current || loading) return;
    pending.current = true; setBusy(true);
    try {
      await axios.put(`${API}/users/${account.id}/role`, { role: choices[account.id] }, { withCredentials: true });
      if (!active.current) return;
      toast.success('Tipo de acesso atualizado'); await reload();
    } catch (err) {
      if (active.current) toast.error(apiErrorMessage(err));
    } finally {
      pending.current = false; if (active.current) setBusy(false);
    }
  };
  return <div className="space-y-5" data-testid="user-accounts-page">
    <h1 className="text-3xl font-bold">Usuários e acessos</h1>
    <p className="text-gray-600">O Gestor ajuda na montagem das escalas e nos repertórios. O líder da banda é definido separadamente em cada programação.</p>
    <p className="text-sm bg-amber-50 rounded p-3">A conta Administrador é exclusiva para administração e não responde como voluntário. Aprove os novos cadastros antes de conceder acesso de Gestor.</p>
    {loading ? <p role="status">Carregando contas...</p> : error ? <div role="alert">{error} <Button variant="outline" onClick={reload}>Tentar novamente</Button></div> : <div className="space-y-3">
      {users.map(account => <div key={account.id} className="border rounded-lg p-4 flex flex-wrap items-center gap-4">
        <div className="flex-1 min-w-48"><p className="font-semibold">{account.name || account.email}</p><p className="text-sm text-gray-600">{account.email}</p><p className="text-xs text-gray-500">{account.role === 'Administrador' ? 'Administração exclusiva' : account.volunteer_name || 'Sem voluntário vinculado'}</p></div>
        {account.role === 'Administrador' ? <span className="font-medium">Administrador</span> : <>
          <label className="text-sm">Tipo de acesso
            <select aria-label={`Tipo de acesso de ${account.email}`} value={choices[account.id] || account.role} disabled={busy || !account.can_change_role} onChange={event => setChoices(previous => ({ ...previous, [account.id]: event.target.value }))} className="block bg-white border rounded p-2 mt-1">
              <option value="Voluntário">Voluntário</option><option value="Gestor">Gestor</option>
            </select>
          </label>
          <Button disabled={busy || !account.can_change_role || !choices[account.id] || choices[account.id] === account.role} onClick={() => save(account)}>Salvar acesso</Button>
          {!account.can_change_role && <p className="text-xs text-gray-500 w-full">Aguardando aprovação e vínculo com um voluntário ativo.</p>}
        </>}
      </div>)}
    </div>}
  </div>;
}
