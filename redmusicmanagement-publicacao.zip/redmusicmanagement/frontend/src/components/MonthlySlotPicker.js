import { useEffect, useLayoutEffect, useRef, useState } from "react";
import axios from "axios";
import { apiErrorMessage } from "@/lib/apiError";

const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api`;
const functionKey = (value) =>
  String(value || "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();
const vocal = (value) => ["vocal", "backing vocal"].includes(value);
const canServe = (person, func) =>
  [...(person.instruments || []), ...(person.functions || [])].some((value) => {
    const key = functionKey(value),
      target = functionKey(func);
    return key === target || (vocal(key) && vocal(target));
  });

export function MonthlySlotPicker({
  schedule,
  func,
  members,
  version,
  busy,
  onSelect,
  onClose,
}) {
  const [exceptions, setExceptions] = useState(false);
  const [reason, setReason] = useState("");
  const [attempt, setAttempt] = useState(0);
  const [result, setResult] = useState(null);
  const [selecting, setSelecting] = useState(false);
  const pending = useRef(false);
  const mounted = useRef(false);
  const root = useRef(null);
  const requestKey = `${schedule.id}:${exceptions}:${version}:${attempt}`;
  const current = result?.key === requestKey;
  const loading = !current;
  useLayoutEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    axios
      .get(
        `${API}/schedules/${schedule.id}/available-volunteers?include_exceptions=${exceptions}`,
        { withCredentials: true, signal: controller.signal },
      )
      .then(({ data }) => {
        if (active) setResult({ key: requestKey, people: data });
      })
      .catch((error) => {
        if (active)
          setResult({
            key: requestKey,
            people: [],
            error: apiErrorMessage(
              error,
              "Não foi possível carregar as pessoas.",
            ),
          });
      });
    return () => {
      active = false;
      controller.abort();
    };
  }, [schedule.id, exceptions, requestKey]);
  useEffect(() => {
    const dismiss = (event) => {
      if (
        !root.current?.contains(event.target) &&
        !event.target.closest?.("[data-slot-toggle]") &&
        !pending.current
      )
        onClose();
    };
    document.addEventListener("pointerdown", dismiss);
    return () => document.removeEventListener("pointerdown", dismiss);
  }, [onClose]);
  const people = current
    ? result.people
        .filter(
          (person) =>
            canServe(person, func) &&
            (exceptions || person.explicitly_available),
        )
        .sort(
          (a, b) =>
            a.monthly_schedule_count - b.monthly_schedule_count ||
            a.name.localeCompare(b.name, "pt-BR"),
        )
    : [];
  const select = async (person) => {
    if (
      busy ||
      loading ||
      pending.current ||
      person.day_conflict ||
      (!person.explicitly_available && !reason.trim())
    )
      return;
    pending.current = true;
    setSelecting(true);
    try {
      await onSelect({
        ...person,
        reason: person.explicitly_available ? "" : reason.trim(),
      });
    } finally {
      pending.current = false;
      if (mounted.current) setSelecting(false);
    }
  };
  return (
    <div
      ref={root}
      role="region"
      aria-label={`Pessoas para ${func} ${schedule.location} ${schedule.date}`}
      className="border rounded-md bg-white shadow-sm mt-1 p-2 space-y-2"
      onKeyDown={(event) => {
        if (event.key === "Escape" && !pending.current) {
          event.stopPropagation();
          onClose();
        }
      }}
      data-testid="monthly-slot-picker"
    >
      <div className="flex justify-between items-start gap-2">
        <p className="text-xs text-gray-500">
          Red + Pulse ·{" "}
          {schedule.date.slice(0, 7).split("-").reverse().join("/")}
        </p>
        <button
          type="button"
          className="text-xs underline text-gray-500"
          disabled={busy || selecting}
          onClick={onClose}
        >
          Fechar lista
        </button>
      </div>
      <label className="flex gap-2 items-center text-xs text-gray-600">
        <input
          type="checkbox"
          checked={exceptions}
          disabled={busy || selecting}
          onChange={(event) => {
            setExceptions(event.target.checked);
            setReason("");
          }}
        />
        Incluir fora da disponibilidade
      </label>
      {exceptions && (
        <textarea
          aria-label="Justificativa da exceção"
          placeholder="Justifique a inclusão fora da disponibilidade"
          maxLength={500}
          className="border rounded p-2 w-full text-xs"
          value={reason}
          disabled={busy || selecting}
          onChange={(event) => setReason(event.target.value)}
        />
      )}
      {loading ? (
        <p role="status" className="text-xs py-2">
          Carregando pessoas...
        </p>
      ) : result.error ? (
        <p role="alert" className="text-xs text-red-700">
          {result.error}{" "}
          <button
            type="button"
            className="underline"
            onClick={() => setAttempt((value) => value + 1)}
          >
            Tentar novamente
          </button>
        </p>
      ) : (
        <>
          {!people.length && (
            <p className="text-xs text-gray-500 py-2">
              Ninguém disponível para esta função e data. Você pode consultar as
              exceções acima.
            </p>
          )}
          <ul
            className="max-h-64 overflow-y-auto space-y-1"
            aria-label="Voluntários para esta vaga"
          >
            {people.map((person) => {
              const added = members.some(
                (member) =>
                  member.schedule_id === schedule.id &&
                  member.volunteer_id === person.id &&
                  functionKey(member.function) === functionKey(func),
              );
              const disabled =
                busy ||
                selecting ||
                added ||
                person.day_conflict ||
                (!person.explicitly_available && !reason.trim());
              const count = person.monthly_schedule_count || 0;
              return (
                <li key={person.id}>
                  <button
                    type="button"
                    className="w-full text-left rounded p-2 text-sm hover:bg-gray-50 border border-transparent hover:border-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={disabled}
                    onClick={() => select(person)}
                  >
                    <span className="block font-medium">{person.name}</span>
                    <span className="block text-xs text-gray-500">
                      {count} {count === 1 ? "escala" : "escalas"} no mês
                    </span>
                    {added && (
                      <span className="block text-xs text-gray-500">
                        Já nesta vaga
                      </span>
                    )}
                    {!person.explicitly_available && (
                      <span className="block text-xs text-amber-800">
                        {person.availability_status}
                      </span>
                    )}
                    {person.day_conflict && (
                      <span className="block text-xs text-red-700">
                        Outra equipe neste dia
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
}
