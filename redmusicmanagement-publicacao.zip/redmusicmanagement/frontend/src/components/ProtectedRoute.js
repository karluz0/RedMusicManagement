import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

export const ProtectedRoute = ({ children }) => {
  const { user, loading, checkAuth, logout } = useAuth();
  const [checking, setChecking] = useState(false);

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-white" data-testid="loading-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#c72137] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-[#4b5563] font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!user.access_approved) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-[#faf7f7] px-6" data-testid="pending-approval">
        <div className="max-w-md rounded-2xl bg-white p-8 shadow-sm space-y-5 text-center">
          <h1 className="text-2xl font-bold text-[#c72137]">Aguardando liberação</h1>
          <p className="text-gray-600">Sua conta está cadastrada. Peça à liderança para conferir seu e-mail, aprovar seu cadastro e vincular sua conta a um voluntário ativo.</p>
          <p className="text-sm break-all">{user.email}</p>
          <Button disabled={checking} className="w-full bg-[#c72137] hover:bg-[#cf3f57]" onClick={async () => {
            setChecking(true);
            try { await checkAuth(); } finally { setChecking(false); }
          }}>{checking ? 'Verificando...' : 'Verificar liberação'}</Button>
          <Button variant="outline" className="w-full" onClick={logout}>Sair</Button>
        </div>
      </main>
    );
  }

  return children;
};
