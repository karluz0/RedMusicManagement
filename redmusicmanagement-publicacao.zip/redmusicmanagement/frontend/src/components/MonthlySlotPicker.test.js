import React, { act } from "react";
import { createRoot } from "react-dom/client";
import axios from "axios";
import { MonthlySlotPicker } from "./MonthlySlotPicker";
jest.mock("axios");
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
};
const person = (id, count = 0, extra = {}) => ({
  id,
  name: id,
  monthly_schedule_count: count,
  instruments: ["Vocal", "Violão"],
  functions: [],
  explicitly_available: true,
  day_conflict: false,
  ...extra,
});
let root, container, props;
const button = (name) =>
  [...container.querySelectorAll("button")].find((item) =>
    item.textContent.includes(name),
  );
async function render(changes = {}) {
  props = { ...props, ...changes };
  await act(async () => root.render(<MonthlySlotPicker {...props} />));
}
async function click(item) {
  expect(item).toBeDefined();
  await act(async () => item.click());
}
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  jest.clearAllMocks();
  props = {
    schedule: { id: "red", date: "2099-11-15", location: "Indaiatuba" },
    func: "Vocal",
    members: [],
    version: 0,
    busy: false,
    onSelect: jest.fn(),
    onClose: jest.fn(),
  };
  axios.get.mockResolvedValue({ data: [] });
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});
afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("inline list filters availability and function and orders the combined monthly counts", async () => {
  axios.get.mockResolvedValue({
    data: [
      person("Ana", 3),
      person("Clara", 1),
      person("Bruno", 1),
      person("Guitarrista", 0, { instruments: ["Guitarra"] }),
      person("Sem resposta", 0, { explicitly_available: false }),
    ],
  });
  await render();
  expect(
    [...container.querySelectorAll("li button")].map(
      (item) => item.textContent,
    ),
  ).toEqual([
    "Bruno1 escala no mês",
    "Clara1 escala no mês",
    "Ana3 escalas no mês",
  ]);
  expect(container.textContent).toContain("Red + Pulse · 11/2099");
  expect(document.querySelector('[role="dialog"]')).toBeNull();
  await click(button("Ana"));
  expect(props.onSelect).toHaveBeenCalledWith(
    expect.objectContaining({ id: "Ana", reason: "" }),
  );
});

test("exceptions require a justification and never enable a day conflict", async () => {
  axios.get.mockResolvedValue({
    data: [
      person("Sem resposta", 2, {
        explicitly_available: false,
        availability_status: "Sem resposta",
      }),
      person("Conflito", 4, { day_conflict: true }),
    ],
  });
  await render();
  await click(container.querySelector('input[type="checkbox"]'));
  expect(axios.get.mock.calls.at(-1)[0]).toContain("include_exceptions=true");
  expect(button("Sem resposta").disabled).toBe(true);
  expect(button("Conflito").disabled).toBe(true);
  const textarea = container.querySelector("textarea");
  await act(async () => {
    Object.getOwnPropertyDescriptor(
      HTMLTextAreaElement.prototype,
      "value",
    ).set.call(textarea, "  Alinhado com a pessoa  ");
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
  });
  expect(button("Sem resposta").disabled).toBe(false);
  expect(button("Conflito").disabled).toBe(true);
  await click(button("Sem resposta"));
  expect(props.onSelect).toHaveBeenCalledWith(
    expect.objectContaining({
      id: "Sem resposta",
      reason: "Alinhado com a pessoa",
    }),
  );
});

test("duplicate slot is disabled while a second function on the same schedule remains selectable", async () => {
  axios.get.mockResolvedValue({ data: [person("Ana", 2)] });
  await render({
    members: [{ schedule_id: "red", volunteer_id: "Ana", function: "Vocal" }],
  });
  expect(button("Ana").disabled).toBe(true);
  expect(container.textContent).toContain("Já nesta vaga");
  await render({ func: "Violão" });
  expect(button("Ana").disabled).toBe(false);
});

test("vocal volunteers can be selected for backing vocals", async () => {
  axios.get.mockResolvedValue({
    data: [person("Ana", 2, { instruments: ["Vocal"] })],
  });
  await render({ func: "Backing Vocal" });
  expect(button("Ana").disabled).toBe(false);
});

test("newer schedule wins even if an old transport ignores cancellation", async () => {
  const first = deferred(),
    second = deferred();
  axios.get
    .mockReturnValueOnce(first.promise)
    .mockReturnValueOnce(second.promise);
  await render();
  const signal = axios.get.mock.calls[0][1].signal;
  await render({
    schedule: { id: "pulse", date: "2099-11-16", location: "Equipe única" },
  });
  expect(signal.aborted).toBe(true);
  expect(container.querySelector("li")).toBeNull();
  await act(async () => second.resolve({ data: [person("Bruno", 2)] }));
  await act(async () => first.resolve({ data: [person("Ana", 4)] }));
  expect(container.textContent).toContain("Bruno");
  expect(container.textContent).not.toContain("Ana");
});

test("refresh version replaces counts and prevents selection while loading", async () => {
  axios.get.mockResolvedValueOnce({ data: [person("Ana", 1)] });
  await render();
  const refresh = deferred();
  axios.get.mockReturnValueOnce(refresh.promise);
  await render({ version: 1 });
  expect(container.querySelector("li")).toBeNull();
  expect(container.querySelector('[role="status"]')).not.toBeNull();
  await act(async () => refresh.resolve({ data: [person("Ana", 2)] }));
  expect(container.textContent).toContain("2 escalas no mês");
});

test("failed load can be retried without opening a popup", async () => {
  axios.get.mockRejectedValueOnce(new Error("network"));
  await render();
  expect(container.querySelector('[role="alert"]')).not.toBeNull();
  axios.get.mockResolvedValueOnce({ data: [person("Ana", 1)] });
  await click(button("Tentar novamente"));
  expect(button("Ana")).toBeDefined();
});

test("one selection is sent while a write is pending and busy prevents writes", async () => {
  axios.get.mockResolvedValue({ data: [person("Ana", 1)] });
  const write = deferred();
  props.onSelect.mockReturnValue(write.promise);
  await render();
  const candidate = button("Ana");
  await act(async () => {
    candidate.click();
    candidate.click();
  });
  expect(props.onSelect).toHaveBeenCalledTimes(1);
  await act(async () => write.resolve());
  await render({ busy: true });
  expect(button("Ana").disabled).toBe(true);
});

test("escape and clicks outside dismiss the inline selector", async () => {
  await render();
  await act(async () =>
    container.firstChild.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Escape", bubbles: true }),
    ),
  );
  expect(props.onClose).toHaveBeenCalledTimes(1);
  await act(async () =>
    document.body.dispatchEvent(new Event("pointerdown", { bubbles: true })),
  );
  expect(props.onClose).toHaveBeenCalledTimes(2);
});
