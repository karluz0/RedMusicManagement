export const MINISTRIES = ["Red Music", "Pulse Music"];

export function MinistryPicker({ value = ["Red Music"], onChange }) {
  return (
    <fieldset className="space-y-2">
      <legend className="text-sm font-medium">Ministérios onde serve</legend>
      <div className="flex flex-wrap gap-4">
        {MINISTRIES.map((ministry) => (
          <label className="flex items-center gap-2 text-sm" key={ministry}>
            <input
              type="checkbox"
              checked={value.includes(ministry)}
              onChange={() =>
                onChange(
                  value.includes(ministry)
                    ? value.filter((item) => item !== ministry)
                    : [...value, ministry],
                )
              }
            />
            {ministry}
          </label>
        ))}
      </div>
      <p className="text-xs text-gray-500">
        Selecione ao menos um. Servir nos dois ministérios não permite
        participar de duas equipes no mesmo dia.
      </p>
    </fieldset>
  );
}
