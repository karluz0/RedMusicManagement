import { Trash2 } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { apiErrorMessage } from "@/lib/apiError";
const API = `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

export function ConfirmRemoval({
  title,
  description,
  onConfirm,
  label = "Excluir",
  className = "",
  iconOnly = false,
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const pending = useRef(false);
  return (
    <>
      <Button
        variant={iconOnly ? "ghost" : "outline"}
        size={iconOnly ? "icon" : "default"}
        aria-label={label}
        title={label}
        className={`text-red-700 ${className}`}
        onClick={() => setOpen(true)}
      >
        {iconOnly ? <Trash2 className="w-4 h-4" aria-hidden="true" /> : label}
      </Button>
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!pending.current) setOpen(value);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600">{description}</p>
          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              disabled={busy}
              onClick={() => setOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              className="bg-red-700 hover:bg-red-800 text-white"
              disabled={busy}
              onClick={async () => {
                if (pending.current) return;
                pending.current = true;
                setBusy(true);
                try {
                  await onConfirm();
                  setOpen(false);
                } catch (error) {
                  toast.error(apiErrorMessage(error));
                } finally {
                  pending.current = false;
                  setBusy(false);
                }
              }}
            >
              {busy ? "Excluindo..." : "Confirmar exclusão"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function BandLeader({ schedule, reload, editable = true }) {
  const { user } = useAuth();
  const admin = editable && ["Administrador", "Líder"].includes(user?.role);
  const [open, setOpen] = useState(false);
  const [people, setPeople] = useState([]);
  const [person, setPerson] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const pending = useRef(false);
  useEffect(() => {
    if (!open || !admin) return;
    let active = true;
    setPeople([]);
    setError("");
    axios
      .get(`${API}/volunteers`, { withCredentials: true })
      .then(({ data }) => {
        if (active) setPeople(data.filter((row) => row.status === "Ativo"));
      })
      .catch((err) => {
        if (active) setError(apiErrorMessage(err));
      });
    return () => {
      active = false;
    };
  }, [open, admin]);
  if (!schedule?.band_leader_name && !admin) return null;
  return (
    <div
      className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-left text-gray-900 my-2"
      data-testid={`band-leader-${schedule.id}`}
    >
      <p className="text-xs uppercase tracking-wide text-amber-800 font-semibold">
        Líder da banda
      </p>
      <p className="font-semibold text-sm mt-1">
        {schedule.band_leader_name || "A definir"}
      </p>
      {admin && (
        <Button
          size="sm"
          variant="ghost"
          className="text-amber-900 h-7 px-0 text-xs"
          onClick={() => {
            setPerson(schedule.band_leader_id || "external");
            setName(schedule.band_leader_name || "");
            setOpen(true);
          }}
        >
          Definir ou alterar líder
        </Button>
      )}
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!pending.current) setOpen(value);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Líder da banda · {schedule.date}</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600">
            Definição interna, sem nova validação ou mudança nas permissões da
            conta.
          </p>
          <label className="text-sm">
            Pessoa
            <select
              aria-label="Líder da banda"
              className="block border rounded p-2 w-full mt-1 bg-white"
              value={person}
              disabled={busy}
              onChange={(event) => setPerson(event.target.value)}
            >
              <option value="external">Informar nome externo</option>
              <option value="">Sem líder definido</option>
              {schedule.band_leader_id &&
                !people.some((row) => row.id === schedule.band_leader_id) && (
                  <option value={schedule.band_leader_id}>
                    {schedule.band_leader_name}
                  </option>
                )}
              {people.map((row) => (
                <option key={row.id} value={row.id}>
                  {row.name}
                </option>
              ))}
            </select>
          </label>
          {person === "external" && (
            <label className="text-sm">
              Nome do líder
              <Input
                aria-label="Nome do líder externo"
                maxLength={120}
                value={name}
                onChange={(event) => setName(event.target.value)}
                disabled={busy}
              />
            </label>
          )}
          {error && (
            <p role="alert" className="text-red-700 text-sm">
              {error}
            </p>
          )}
          <Button
            disabled={busy || (person === "external" && !name.trim())}
            onClick={async () => {
              if (pending.current) return;
              pending.current = true;
              setBusy(true);
              try {
                await axios.put(
                  `${API}/schedules/${schedule.id}/band-leader`,
                  {
                    volunteer_id: person && person !== "external" ? person : "",
                    name: person === "external" ? name : "",
                  },
                  { withCredentials: true },
                );
                await reload();
                setOpen(false);
                toast.success("Líder da banda atualizado");
              } catch (err) {
                toast.error(apiErrorMessage(err));
              } finally {
                pending.current = false;
                setBusy(false);
              }
            }}
          >
            {busy ? "Salvando..." : "Salvar líder"}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
