import { ExternalLink, Music, FileMusic } from "lucide-react";
export function SongResourceLinks({ song }) {
  const links = [
    ["link_original", "Original", Music],
    ["link_pt_br", "PT-BR", Music],
    ["link_intro_arrangement", "Arranjo", ExternalLink],
    ["sheet_music_url", "Cifra / partitura", FileMusic],
  ];
  return (
    <div className="flex gap-2 mt-3 flex-wrap" aria-label="Links da música">
      {links
        .filter(([key]) => /^https?:\/\//i.test(String(song[key] || "").trim()))
        .map(([key, label, Icon]) => (
          <a
            key={key}
            href={song[key].trim()}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`${label}: ${song.name || song.song_name || "música"}`}
            title={label}
            className="inline-flex items-center gap-1 rounded border px-3 py-2 text-xs font-medium text-[#c72137] hover:bg-gray-100"
          >
            <Icon className="w-4 h-4" aria-hidden="true" />
            {label}
          </a>
        ))}
    </div>
  );
}
